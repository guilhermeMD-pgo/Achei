import assert from "node:assert/strict";
import test from "node:test";
import Database from "better-sqlite3";
import {
  findActivePromotionInDatabase,
  listActivePromotionsInDatabase,
} from "../lib/promotion-queries";

test("consulta pública inclui apenas promoções vigentes e relacionadas a itens ativos", () => {
  const database = new Database(":memory:");
  database.exec(`
    CREATE TABLE stores (
      id TEXT PRIMARY KEY, name TEXT, floor TEXT, unit TEXT, active INTEGER
    );
    CREATE TABLE products (
      id TEXT PRIMARY KEY, store_id TEXT, name TEXT, active INTEGER
    );
    CREATE TABLE promotions (
      id TEXT PRIMARY KEY, store_id TEXT, product_id TEXT, title TEXT,
      description TEXT, discount_percent REAL, promotional_price_cents INTEGER,
      starts_at TEXT, ends_at TEXT, active INTEGER, is_demo INTEGER
    );
  `);
  database
    .prepare("INSERT INTO stores VALUES (?, ?, ?, ?, ?)")
    .run("store-a", "Loja A", "Piso 1", "Unidade 1", 1);
  database
    .prepare("INSERT INTO stores VALUES (?, ?, ?, ?, ?)")
    .run("store-off", "Loja inativa", "Piso 1", "Unidade 2", 0);
  database
    .prepare("INSERT INTO products VALUES (?, ?, ?, ?)")
    .run("product-active", "store-a", "Produto ativo", 1);
  database
    .prepare("INSERT INTO products VALUES (?, ?, ?, ?)")
    .run("product-off", "store-a", "Produto inativo", 0);

  const now = "2026-11-13T12:00:00.000Z";
  const insertPromotion = database.prepare(
    `INSERT INTO promotions
     VALUES (?, ?, ?, ?, ?, 10, NULL, ?, ?, ?, 0)`,
  );
  insertPromotion.run(
    "current",
    "store-a",
    "product-active",
    "Vigente",
    "Condições",
    "2026-11-13T11:00:00.000Z",
    "2026-11-13T13:00:00.000Z",
    1,
  );
  insertPromotion.run(
    "future",
    "store-a",
    null,
    "Futura",
    "Condições",
    "2026-11-13T13:00:00.000Z",
    "2026-11-13T14:00:00.000Z",
    1,
  );
  insertPromotion.run(
    "expired",
    "store-a",
    null,
    "Expirada",
    "Condições",
    "2026-11-13T10:00:00.000Z",
    "2026-11-13T11:00:00.000Z",
    1,
  );
  insertPromotion.run(
    "disabled",
    "store-a",
    null,
    "Desativada",
    "Condições",
    "2026-11-13T11:00:00.000Z",
    "2026-11-13T13:00:00.000Z",
    0,
  );
  insertPromotion.run(
    "store-disabled",
    "store-off",
    null,
    "Loja inativa",
    "Condições",
    "2026-11-13T11:00:00.000Z",
    "2026-11-13T13:00:00.000Z",
    1,
  );
  insertPromotion.run(
    "product-disabled",
    "store-a",
    "product-off",
    "Produto inativo",
    "Condições",
    "2026-11-13T11:00:00.000Z",
    "2026-11-13T13:00:00.000Z",
    1,
  );

  const items = listActivePromotionsInDatabase(database, now);
  assert.deepEqual(items.map((item) => item.id), ["current"]);
  assert.equal(findActivePromotionInDatabase(database, "current", now)?.productName, "Produto ativo");
  assert.equal(findActivePromotionInDatabase(database, "future", now), null);
  database.close();
});
