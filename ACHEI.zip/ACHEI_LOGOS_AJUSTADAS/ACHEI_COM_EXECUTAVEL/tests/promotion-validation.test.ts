import assert from "node:assert/strict";
import test from "node:test";
import {
  validateProductInput,
  validatePromotionInput,
} from "../lib/promotion-validation";

test("promoção exige desconto ou preço promocional e datas em ordem", () => {
  const valid = validatePromotionInput({
    title: "Oferta",
    description: "Condições da oferta",
    startsAt: "2026-11-01T10:00:00.000Z",
    endsAt: "2026-11-02T10:00:00.000Z",
    discountPercent: 10,
  });
  assert.equal(valid.valid, true);

  const missingOfferValue = validatePromotionInput({
    title: "Oferta",
    description: "Condições da oferta",
    startsAt: "2026-11-01T10:00:00.000Z",
    endsAt: "2026-11-02T10:00:00.000Z",
  });
  assert.equal(missingOfferValue.valid, false);

  const reversedDates = validatePromotionInput({
    title: "Oferta",
    description: "Condições da oferta",
    startsAt: "2026-11-02T10:00:00.000Z",
    endsAt: "2026-11-01T10:00:00.000Z",
    promotionalPrice: 12.5,
  });
  assert.equal(reversedDates.valid, false);
});

test("promoção rejeita descontos fora de faixa e preços com fração de centavo", () => {
  const base = {
    title: "Oferta",
    description: "Condições da oferta",
    startsAt: "2026-11-01T10:00:00.000Z",
    endsAt: "2026-11-02T10:00:00.000Z",
  };
  assert.equal(
    validatePromotionInput({ ...base, discountPercent: 100.1 }).valid,
    false,
  );
  assert.equal(
    validatePromotionInput({ ...base, promotionalPrice: 2.001 }).valid,
    false,
  );
});

test("produto permite preço nulo e rejeita preço inválido", () => {
  const product = validateProductInput({
    name: "Produto",
    category: "Categoria",
    price: null,
  });
  assert.equal(product.valid, true);

  const invalid = validateProductInput({
    name: "Produto",
    category: "Categoria",
    price: -0.01,
  });
  assert.equal(invalid.valid, false);
});
