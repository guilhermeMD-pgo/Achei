import assert from "node:assert/strict";
import test from "node:test";
import { searchItems, type Searchable } from "../lib/search";

const items: Searchable[] = [
  { id: "a", name: "Camiseta básica de algodão", description: "Camiseta unissex.", category: "Vestuário", storeName: "Renner" },
  { id: "b", name: "Camisa social slim", description: "Camisa social de algodão.", category: "Vestuário", storeName: "C&A" },
  { id: "c", name: "Bola de futebol", description: "Bola oficial.", category: "Esportes", storeName: "Centauro" },
  { id: "d", name: "Tênis de corrida", description: "Amortecimento.", category: "Esportes", storeName: "Centauro" },
  { id: "e", name: "Combo hambúrguer duplo", description: "Com batata.", category: "Alimentação", storeName: "McDonald's" },
];
const ids = (q: string) => searchItems(items, q).exact.map((i) => i.id).sort();

test("camisa encontra camiseta e camisa em lojas diferentes", () => {
  assert.deepEqual(ids("camisa"), ["a", "b"]);
});
test("tolera erros de digitação, acentos e plural", () => {
  assert.deepEqual(ids("camizas"), ["a", "b"]);
  assert.deepEqual(ids("TENIS"), ["d"]);
  assert.deepEqual(ids("hamburger"), ["e"]);
  assert.deepEqual(ids("futbol"), ["c"]);
});
test("sinônimos: comida encontra o combo de hambúrguer", () => {
  assert.deepEqual(ids("comida"), ["e"]);
});
test("sem correspondência devolve sugestões, não lista vazia quando há algo parecido", () => {
  const r = searchItems(items, "cmiseta");
  assert.ok(r.exact.length + r.suggestions.length > 0);
  assert.equal(searchItems(items, "xyzqk").exact.length, 0);
});
