import assert from "node:assert/strict";
import test from "node:test";
import { mallMapStores } from "../lib/mall-map-data";
import { computeRoutes, originsForFloor, pathData } from "../lib/mall-routes";

test("cada loja recebe uma rota por ponto de partida do seu pavimento", () => {
  for (const store of mallMapStores) {
    const routes = computeRoutes({ x: store.x, y: store.y }, store.floor);
    assert.equal(routes.length, originsForFloor(store.floor).length, store.name);
    assert.ok(routes.some((r) => r.shortest), `${store.name}: sem rota mais curta`);
    for (const route of routes) {
      assert.ok(route.points.length >= 2);
      assert.ok(route.length > 0);
      assert.match(pathData(route.points), /^M /);
    }
  }
});

test("entrada principal só existe no térreo", () => {
  assert.ok(originsForFloor("Térreo").some((o) => o.id === "entrada"));
  assert.ok(!originsForFloor("2º pavimento").some((o) => o.id === "entrada"));
});

test("rotas seguem corredores (segmentos horizontais ou verticais, exceto as pontas)", () => {
  const routes = computeRoutes({ x: 49.7, y: 55.2 }, "Térreo");
  for (const route of routes) {
    const inner = route.points.slice(1, -1);
    for (let i = 1; i < inner.length; i++) {
      const dx = Math.abs(inner[i].x - inner[i - 1].x);
      const dy = Math.abs(inner[i].y - inner[i - 1].y);
      assert.ok(dx < 1e-6 || dy < 1e-6, "trecho diagonal dentro do corredor");
    }
  }
});

test("no 2º pavimento as rotas saem apenas da escada e do elevador", () => {
  assert.deepEqual(
    originsForFloor("2º pavimento").map((o) => o.id).sort(),
    ["elevador", "escadas"],
  );
  const routes = computeRoutes({ x: 42, y: 26.2 }, "2º pavimento");
  assert.deepEqual(routes.map((r) => r.id).sort(), ["elevador", "escadas"]);
});
