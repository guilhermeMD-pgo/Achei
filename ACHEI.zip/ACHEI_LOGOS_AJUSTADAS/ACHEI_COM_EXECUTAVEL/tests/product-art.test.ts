import assert from "node:assert/strict";
import test from "node:test";
import { demoCatalog, demoProductId } from "../lib/demo-catalog";
import { productArt } from "../lib/product-art";

test("todo produto do catálogo tem imagem ilustrativa", () => {
  for (const [storeId, products] of Object.entries(demoCatalog)) {
    products.forEach((_, index) => {
      assert.ok(productArt[demoProductId(storeId, index)], `${storeId} #${index + 1} sem imagem`);
    });
  }
});
