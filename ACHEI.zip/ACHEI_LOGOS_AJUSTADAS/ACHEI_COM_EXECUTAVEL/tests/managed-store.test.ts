import assert from "node:assert/strict";
import test from "node:test";
import Database from "better-sqlite3";
import { findManagedStoreInDatabase } from "../lib/managed-store";

test("lojista permanece limitado à própria loja mesmo enviando outro ID", () => {
  const database = new Database(":memory:");
  database.exec(`
    CREATE TABLE stores (
      id TEXT PRIMARY KEY, name TEXT, category TEXT, description TEXT,
      floor TEXT, unit TEXT, phone TEXT, map_node_id TEXT,
      owner_user_id TEXT, active INTEGER, is_demo INTEGER
    );
    INSERT INTO stores
      VALUES ('store-a', 'Loja A', 'Moda', '', '1', 'A', NULL, NULL, 'user-a', 1, 0);
    INSERT INTO stores
      VALUES ('store-b', 'Loja B', 'Moda', '', '1', 'B', NULL, NULL, 'user-b', 1, 0);
  `);

  const result = findManagedStoreInDatabase(
    database,
    { id: "user-a", role: "merchant" },
    "store-b",
  );
  assert.equal(result instanceof Response, false);
  if (!(result instanceof Response)) assert.equal(result.id, "store-a");
  database.close();
});

test("admin pode operar em uma loja informada", () => {
  const database = new Database(":memory:");
  database.exec(`
    CREATE TABLE stores (
      id TEXT PRIMARY KEY, name TEXT, category TEXT, description TEXT,
      floor TEXT, unit TEXT, phone TEXT, map_node_id TEXT,
      owner_user_id TEXT, active INTEGER, is_demo INTEGER
    );
    INSERT INTO stores
      VALUES ('store-b', 'Loja B', 'Moda', '', '1', 'B', NULL, NULL, 'user-b', 1, 0);
  `);

  const result = findManagedStoreInDatabase(
    database,
    { id: "admin", role: "admin" },
    "store-b",
  );
  assert.equal(result instanceof Response, false);
  if (!(result instanceof Response)) assert.equal(result.id, "store-b");
  database.close();
});
