import assert from "node:assert/strict";
import test from "node:test";
import { demoCatalog } from "../lib/demo-catalog";
import { mallMapStores, removedMallStoreIds } from "../lib/mall-map-data";
import { storeLogos } from "../lib/store-logos";

test("restam 10 lojas, cada uma com 2 produtos e uma logo", () => {
  assert.equal(mallMapStores.length, 10);
  for (const store of mallMapStores) {
    assert.equal(demoCatalog[store.id]?.length, 2, `${store.name}: precisa de 2 produtos`);
    assert.ok(storeLogos[store.id], `${store.name}: sem logo`);
  }
  assert.equal(Object.keys(demoCatalog).length, mallMapStores.length);
});

test("lojas removidas não permanecem no mapa nem no catálogo", () => {
  assert.equal(removedMallStoreIds.length, 10);
  for (const id of removedMallStoreIds) {
    assert.ok(!mallMapStores.some((s) => s.id === id));
    assert.ok(!(id in demoCatalog));
  }
});
