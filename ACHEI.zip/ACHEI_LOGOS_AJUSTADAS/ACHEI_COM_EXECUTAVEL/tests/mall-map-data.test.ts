import assert from "node:assert/strict";
import test from "node:test";
import { mallMapStores } from "../lib/mall-map-data";

test("pontos da planta têm identificadores únicos e coordenadas percentuais válidas", () => {
  const ids = mallMapStores.map((store) => store.id);
  const nodeIds = mallMapStores.map((store) => store.nodeId);
  assert.equal(new Set(ids).size, ids.length);
  assert.equal(new Set(nodeIds).size, nodeIds.length);
  for (const store of mallMapStores) {
    assert.ok(store.x >= 0 && store.x <= 100, `${store.name}: x fora da planta`);
    assert.ok(store.y >= 0 && store.y <= 100, `${store.name}: y fora da planta`);
    assert.ok(store.name.length > 0);
  }
  assert.ok(mallMapStores.some((store) => store.floor === "Térreo"));
  assert.ok(mallMapStores.some((store) => store.floor === "2º pavimento"));
});
