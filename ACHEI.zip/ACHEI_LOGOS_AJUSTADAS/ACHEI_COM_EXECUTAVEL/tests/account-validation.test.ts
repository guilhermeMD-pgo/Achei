import assert from "node:assert/strict";
import test from "node:test";
import { validateProfile, validateRegistration } from "../lib/account-validation";

test("cadastro normaliza e valida nome, e-mail e senha", () => {
  const valid = validateRegistration({ name: "  Ana Silva ", email: " ANA@EXEMPLO.COM ", password: "senha-segura-123" });
  assert.deepEqual(valid, { valid: true, value: { name: "Ana Silva", email: "ana@exemplo.com", password: "senha-segura-123" } });
  assert.equal(validateRegistration({ name: "A", email: "email-invalido", password: "1234567" }).valid, false);
});

test("edição de perfil exige nome e e-mail válidos", () => {
  assert.deepEqual(validateProfile({ name: "Ana Silva", email: "ANA@EXEMPLO.COM" }), {
    valid: true, value: { name: "Ana Silva", email: "ana@exemplo.com" },
  });
  assert.equal(validateProfile({ name: "", email: "ana@exemplo.com" }).valid, false);
});
