# Plano de implementação — TechSpec 03: Promoções e gestão do lojista

## Problema e abordagem

A aplicação já possui a fundação Next.js/SQLite, os modelos `Store`, `Product` e `Promotion`, as tabelas correspondentes e uma rota que lista promoções vigentes. A página pública de promoções ainda é um placeholder; não há rota de detalhe, autenticação/sessão nem área ou API de gestão do lojista.

Implementar a TechSpec 03 sobre os contratos do módulo 01 e os modelos/catálogos do módulo 02, sem duplicar persistência ou autorização. As promoções públicas serão calculadas no servidor pela ativação e validade temporal. Todas as operações privadas validarão papel e propriedade dos registros no servidor, inclusive quando a requisição trouxer IDs de produto ou promoção.

## Plano de trabalho

1. **Alinhar dependências e contratos**
   - Conferir a entrega efetiva de autenticação, sessão e helpers de papel do módulo 01 antes de criar rotas de lojista; reutilizar esses helpers e bloquear operações privadas se a fundação ainda não estiver pronta.
   - Confirmar com o módulo 02 os campos e identificadores de loja/produto e reutilizar os mesmos registros nas promoções, busca e catálogo.
   - Revisar os dados de demonstração e garantir uma conta `merchant` associada a uma loja própria para validar o fluxo, sem adicionar autoinscrição de lojistas.
   - Preservar o formato comum de erros e respostas `{ "items": [...] }` / `{ "error": { "code": "...", "message": "..." } }`.

2. **Completar a API pública de promoções**
   - Manter `GET /api/promotions` restrito a ofertas habilitadas, dentro da validade calculada usando o relógio do servidor, e com resumos da loja e do produto relacionado.
   - Implementar `GET /api/promotions/:id` com os mesmos critérios de visibilidade da listagem; itens inexistentes, desativados, futuros ou expirados não devem ser expostos como ofertas vigentes.
   - Preservar os dados opcionais sem fabricar preço original, preço promocional ou percentual; incluir período, condições e identificação de conteúdo demonstrativo.

3. **Implementar gestão autenticada de loja, produtos e promoções**
   - Criar as rotas sob `/api/merchant/store`, `/api/merchant/products` e `/api/merchant/promotions` para consultar e manter a loja e seus registros associados.
   - Exigir sessão `merchant` ou `admin` e conferir no servidor a loja associada à sessão em cada leitura/escrita, também ao resolver IDs de produto e promoção. Não confiar em IDs, papéis ou vínculos enviados pelo cliente.
   - Validar campos obrigatórios, formatos/tamanhos, preço/desconto e datas; exigir `endsAt > startsAt`, e assegurar que o produto relacionado pertença à loja autorizada.
   - Fazer gravações relacionadas de forma atômica; editar e desativar por exclusão lógica, mantendo referências históricas e removendo imediatamente itens desativados das consultas públicas.
   - Reaproveitar as restrições existentes na migração inicial e criar migração adicional somente se a revisão encontrar uma regra de integridade ainda ausente.

4. **Entregar páginas públicas e área do lojista**
   - Substituir o placeholder de `/promotions` por lista de ofertas vigentes e criar página de detalhe com loja, produto opcional, preço/desconto, validade e aviso de confirmação com o estabelecimento.
   - Criar área autenticada do lojista para editar dados básicos da própria loja e listar/criar/editar/desativar produtos e promoções.
   - Implementar carregamento, listas vazias, erros recuperáveis, validação acionável, confirmação de sucesso e prevenção de envio duplicado.
   - Manter formulários e listas operáveis em telas pequenas, com rótulos, foco visível e mensagens compreensíveis; deixar claro quando dados forem demonstrativos.

5. **Validar critérios de aceite e integração**
   - Cobrir ofertas futuras, vigentes, expiradas e desativadas, detalhes públicos e registros sem dados opcionais.
   - Cobrir datas/preços/descontos inválidos, sessão ausente, papel inadequado e tentativas de acesso a outra loja manipulando IDs; confirmar ausência de gravação parcial em falha.
   - Validar que alterações do catálogo aparecem na busca do módulo 02 e que ofertas válidas aparecem na página inicial/listagem sem duplicar dados de produto ou loja.
   - Executar typecheck e build, além dos testes focados do módulo; documentar execução e contas de demonstração sem credenciais reais.

## Decisões e dependências

- **Autenticação:** depende da implementação de sessão e papéis do módulo 01. Não criar um mecanismo de sessão paralelo; até a dependência estar disponível, as rotas de escrita não devem aceitar acesso anônimo.
- **Propriedade:** a loja efetiva vem da sessão/associação persistida. `admin` pode operar conforme as regras acordadas na fundação; usuário `merchant` permanece restrito à própria loja.
- **Validade:** a API é a autoridade para ativação temporal. O cliente não define se uma promoção está vigente.
- **Persistência:** a tabela atual já tem `active`, datas, desconto/preço promocional e vínculo opcional ao produto. Revisar checks e vínculo loja-produto; não adicionar migração sem necessidade demonstrada.
- **Dados de demonstração:** usar valores sintéticos identificados como demonstração e nunca alegar vigência/preço físico confirmado. Não incluir portal de autoinscrição, cupons, pagamentos, integração de estoque ou aprovação de campanhas.
- **Destino acordado:** o arquivo de entrega deste plano é `.workflow/techspecs/03-promocoes-gestao-lojista/PLAN.md`.
