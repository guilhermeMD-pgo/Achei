# Plano de implementação — TechSpec 01: Plataforma, dados e contratos de API

## Problema e abordagem

O repositório atualmente contém o protótipo estático em `ACHEI!!`, documentação da proposta e as TechSpecs 01–04, mas ainda não possui uma aplicação Next.js na raiz. A TechSpec 01 deve entregar a fundação única, executável e compartilhada para os módulos 02–04: aplicação Next.js com App Router, persistência SQL no servidor, autenticação mínima, layout responsivo e contratos de dados/API consistentes.

O trabalho será feito em etapas, preservando o protótipo como referência visual/conteúdo e evitando manter duas aplicações concorrentes. Os módulos 02–04 continuam responsáveis pelas funcionalidades e endpoints próprios; o módulo 01 fornece modelos, infraestrutura e contratos comuns, coordenando previamente os campos e identificadores compartilhados.

## Plano de trabalho

1. **Preparar a aplicação e a estrutura compartilhada**
   - Inventariar o protótipo `ACHEI!!` e usá-lo como referência para migrar conteúdo e identidade visual, sem mantê-lo como segunda aplicação.
   - Criar a aplicação Next.js na raiz com App Router e Route Handlers, definindo estrutura de rotas, navegação global e estilos-base.
   - Implementar componentes compartilhados mínimos: cabeçalho, navegação para início/busca/promoções/lojas/mapa/conta e estados de carregamento, erro e vazio.
   - Garantir adaptação a celular e desktop e uso consistente desses componentes pelos demais módulos.

2. **Definir domínio e persistência**
   - Formalizar modelos e validação compartilhados para `User`, `Store`, `Product`, `Promotion`, `MapNode`/`MapEdge`, `Favorite`, `SearchHistory` e `UserSettings`, preservando campos, identificadores estáveis e regras da TechSpec 01.
   - Criar uma única configuração de acesso SQL exclusivamente no servidor, migrações versionadas e mecanismo de seed.
   - Planejar SQLite local como padrão de demonstração, sujeito à confirmação da equipe; manter como gate a verificação de banco provisionado e da persistência oferecida pelo ambiente de deploy antes da publicação.
   - Carregar dados sintéticos identificados como demonstração, incluindo contas/associações de lojista de teste, sem apresentar dados como oficiais.
   - Tornar erros de conexão/configuração explícitos; não usar dados falsos como fallback silencioso.

3. **Estabilizar contratos de API e integração**
   - Documentar convenções JSON: coleções em `{ "items": [...] }` e erros em `{ "error": { "code": "...", "message": "..." } }`, com status HTTP apropriado.
   - Definir modelos, validações, identificadores, filtros e campos opcionais esperados para lojas, produtos, promoções, serviços e mapa.
   - Disponibilizar os contratos públicos acordados (`GET /api/stores`, `/api/products`, `/api/promotions` e `/api/services`) e os helpers comuns necessários para que os módulos responsáveis implementem suas consultas e telas sem duplicar banco, navegação ou estilos globais.
   - Alinhar antes da estabilização os contratos dos módulos 02–04: campos de loja/produto, vínculo de promoções, identificadores de destino do mapa, histórico, favoritos e preferências.
   - Registrar mudanças incompatíveis e comunicá-las aos responsáveis afetados.

4. **Implementar autenticação e fronteiras de autorização**
   - Implementar cadastro público somente para consumidores, login, logout e sessão mínima por cookie `HttpOnly`, `SameSite` e `Secure` em produção.
   - Armazenar somente hash seguro de senha; não retornar nem registrar senha.
   - Criar helpers de sessão/papel para rotas privadas. Contas de lojista/admin devem vir de seed ou administração, não de cadastro público.
   - Definir verificações reutilizáveis para que operações de lojista exijam papel `merchant` ou `admin` e restrinjam a conta à loja associada; operações pessoais derivam o usuário da sessão, nunca de `userId` enviado pelo cliente.

5. **Documentar execução e preparar handoff**
   - Atualizar o README com pré-requisitos, instalação, configuração do banco, aplicação de migrações, carga de seed e inicialização.
   - Documentar variáveis/configuração, contratos compartilhados, dados sintéticos e gates pendentes (banco e persistência de deploy).
   - Fazer handoff aos módulos 02–04 com os modelos, contratos, helpers e decisões estabilizadas.

6. **Validar os critérios de aceite e a integração**
   - Verificar o fluxo documentado de instalação, migração, seed e inicialização em ambiente limpo.
   - Testar que interface e API usam a mesma configuração de banco e que falhas de configuração/conexão são visíveis.
   - Testar ausência de sessão em rotas privadas, papéis inadequados e isolamento do lojista para sua própria loja; confirmar que dados pessoais usam a identidade da sessão.
   - Verificar layout e navegação em larguras de celular e desktop, estados comuns e consistência dos contratos com as TechSpecs 02–04.
   - Confirmar que conteúdo de demonstração é identificado e que não há alegações de dados oficiais, disponibilidade em tempo real ou planta oficial.

## Decisões e dependências

- **Banco:** SQLite local é o padrão planejado para demonstração, condicionado à confirmação da equipe. Antes de publicar, confirmar que o deploy oferece persistência local; caso contrário, selecionar e configurar banco SQL hospedado.
- **Dados de demonstração:** usar somente dados sintéticos identificados. Definir com a equipe quais contas de lojista e lojas de demonstração serão semeadas.
- **Mapa:** coordenadas, grafo, acessibilidade e serviços devem ser acordados com o módulo 04; sem dados reais autorizados, usar planta fictícia explicitamente esquemática.
- **Integração:** módulos 02–04 dependem dos modelos, migrações, seed, sessão, papéis, layout e contratos do módulo 01; combinar campos/identificadores antes de estabilizar dependentes.
- **Limites do MVP:** não incluir OAuth, recuperação de senha por e-mail, gestão complexa de papéis, pagamentos, ERP/POS, sincronização de estoque ou administração geral completa.
