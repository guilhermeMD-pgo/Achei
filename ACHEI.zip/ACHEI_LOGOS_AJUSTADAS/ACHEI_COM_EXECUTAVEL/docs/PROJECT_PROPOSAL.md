# ACHEI

## Explore possibilidades e encontre novidades!

# Planejamento Técnico Inicial

### Aplicativo de localização, pesquisa de produtos e promoções

**Shopping Capim Dourado -- Palmas/TO**

------------------------------------------------------------------------

## 1. Apresentação do projeto

O Achei é um aplicativo desenvolvido com a finalidade de facilitar a
experiência dos consumidores dentro do Shopping Capim Dourado, em Palmas
-- TO, oferecendo uma plataforma digital que reúne localização de lojas,
pesquisa de produtos, divulgação de promoções e orientação sobre os
espaços disponíveis no estabelecimento.

A proposta é permitir que o consumidor encontre facilmente o que
procura, sem precisar percorrer diversos corredores ou entrar em várias
lojas para descobrir onde determinado produto está disponível.

Por meio do aplicativo, o usuário poderá visualizar as lojas existentes
no Shopping Capim Dourado, consultar promoções, acessar um mapa de
localização, encontrar espaços como praça de alimentação, banheiros,
estacionamentos e outros serviços, além de pesquisar produtos
específicos e descobrir quais lojas os comercializam.

O Achei pretende transformar a experiência de compras em algo mais
simples, rápido, organizado e acessível, conectando consumidores às
lojas e aos produtos que desejam encontrar.

## 2. Problema identificado

Ao frequentar o Shopping Capim Dourado, muitos consumidores enfrentam
dificuldades para encontrar determinadas lojas, localizar produtos
específicos e descobrir onde estão localizados serviços e espaços
importantes, como a praça de alimentação, banheiros e estacionamentos.

Outro problema é a falta de informações centralizadas sobre promoções e
produtos disponíveis nas lojas. Muitas vezes, o consumidor precisa
percorrer diferentes estabelecimentos para encontrar o que procura,
gastando tempo e, em alguns casos, deixando de aproveitar ofertas
interessantes.

Diante desse cenário, o Achei surge como uma solução tecnológica para
centralizar essas informações e facilitar a localização de produtos,
lojas e serviços dentro do Shopping Capim Dourado.

## 3. Objetivos do projeto

### Objetivo geral

Desenvolver um aplicativo que facilite a localização de lojas, produtos,
serviços e promoções dentro do Shopping Capim Dourado, proporcionando
aos consumidores uma experiência de compra mais prática, rápida e
eficiente.

### Objetivos específicos

-   Facilitar a localização dos consumidores dentro do shopping.
-   Disponibilizar um mapa com a identificação das lojas e dos
    principais espaços.
-   Apresentar as promoções disponíveis logo na página inicial.
-   Permitir a consulta de todas as lojas existentes no estabelecimento.
-   Disponibilizar uma ferramenta de pesquisa de produtos.
-   Informar em quais lojas determinado produto pode ser encontrado.
-   Apresentar informações sobre a localização da praça de alimentação,
    banheiros, estacionamentos e outros serviços.
-   Mostrar o caminho até a loja ou espaço desejado.
-   Aproximar consumidores e estabelecimentos comerciais.

## 4. Público-alvo

O aplicativo será destinado principalmente aos consumidores que
frequentam o Shopping Capim Dourado e desejam encontrar lojas, produtos,
serviços e promoções com maior facilidade.

Também atenderá aos lojistas do shopping, que poderão utilizar a
plataforma para divulgar seus produtos, atualizar informações comerciais
e apresentar promoções aos consumidores.

## 5. Proposta e estrutura inicial das telas

O aplicativo contará com uma interface simples, moderna e intuitiva,
organizada em abas para facilitar a navegação.

### Tela 1 -- Página inicial (Promoções)

-   Exibição das principais promoções do Shopping Capim Dourado.
-   Destaques de ofertas e descontos.
-   Divulgação de campanhas promocionais.
-   Acesso rápido à pesquisa de produtos.
-   Atalhos para lojas, mapa e serviços.

Será a primeira tela apresentada ao usuário ao abrir o aplicativo.

### Tela 2 -- Lojas

-   Lista de estabelecimentos.
-   Pesquisa pelo nome da loja.
-   Categorias como roupas, calçados, eletrônicos, alimentação e beleza.
-   Informações sobre cada estabelecimento.
-   Localização da loja no mapa.

Apresentará uma relação das lojas existentes no Shopping Capim Dourado,
organizadas por nome e categoria.

### Tela 3 -- Mapa do shopping

-   Mapa de localização do Shopping Capim Dourado.
-   Identificação das lojas.
-   Localização da praça de alimentação.
-   Localização dos banheiros.
-   Identificação de elevadores, escadas e estacionamentos.
-   Orientação sobre o caminho até o destino desejado.

Permitirá que o consumidor visualize a estrutura do Shopping Capim
Dourado e identifique onde está localizado cada estabelecimento ou
serviço.

### Tela 4 -- Pesquisa de produtos

Será uma das principais funcionalidades do Achei e seu grande
diferencial. O consumidor poderá pesquisar o nome de um produto e o
aplicativo apresentará as lojas que comercializam aquele item.

**Exemplo:** caso o consumidor procure um tênis, o aplicativo poderá
apresentar as lojas do Shopping Capim Dourado que possuem esse produto,
suas localizações e, quando disponibilizadas pelos estabelecimentos,
informações de preço e disponibilidade.

-   Campo de pesquisa por nome do produto.
-   Pesquisa por categorias.
-   Exibição das lojas que comercializam o produto.
-   Informações sobre preços, quando cadastrados.
-   Indicação da localização de cada loja.
-   Acesso ao mapa para encontrar o estabelecimento.

### Tela 5 -- Perfil do usuário

-   Cadastro e informações pessoais.
-   Histórico de pesquisas.
-   Lojas favoritas.
-   Promoções favoritas.
-   Configurações do aplicativo.

Apresentará as informações e preferências do consumidor.

## 6. Diferencial do aplicativo

O principal diferencial do Achei está na possibilidade de localizar não
apenas lojas, mas também produtos específicos dentro do Shopping Capim
Dourado.

Diferentemente de plataformas que apresentam somente uma lista de
estabelecimentos ou um mapa geral do shopping, o Achei pretende integrar
três funcionalidades principais: localização, pesquisa de produtos e
divulgação de promoções.

Por exemplo, imagine que um consumidor esteja procurando um perfume, um
tênis ou um acessório específico. Em vez de precisar entrar em diversas
lojas para descobrir onde encontrar o produto, ele poderá simplesmente
pesquisar o nome do item no Achei.

O aplicativo apresentará os estabelecimentos que comercializam o produto
e indicará sua localização dentro do shopping, facilitando o acesso ao
local desejado.

Além disso, o consumidor poderá visualizar promoções, encontrar serviços
e utilizar o mapa para se orientar dentro do estabelecimento.

> O grande diferencial é permitir que o consumidor encontre aquilo que
> procura, e não apenas descobrir onde ficam as lojas.

## 7. Tecnologias escolhidas

Para o desenvolvimento do Achei, serão utilizadas as quatro tecnologias
definidas para o projeto:

### Next.js

Framework utilizado no desenvolvimento da aplicação web, incluindo a
interface e o processamento das funcionalidades do sistema no servidor.

### HTML

Linguagem utilizada para estruturar as páginas, os conteúdos e os
elementos da interface.

### CSS

Linguagem utilizada para definir a aparência visual das páginas,
incluindo cores, fontes, espaçamentos e adaptação a diferentes tamanhos
de tela.

### SQL

Linguagem utilizada para criar, consultar, atualizar e organizar os
dados de usuários, lojas, produtos e promoções.

## 8. Arquitetura proposta

O Achei será desenvolvido como uma aplicação web, utilizando uma
arquitetura cliente-servidor organizada em três camadas:

### 1. Apresentação (front-end)

Desenvolvida com Next.js, HTML e CSS, será responsável pela estrutura
visual das páginas e pela interação do consumidor com o sistema.

### 2. Aplicação (back-end)

Desenvolvida com os recursos de servidor do Next.js, será responsável
por processar as pesquisas, aplicar as regras do sistema e fornecer as
informações solicitadas.

### 3. Dados

Utilizará SQL para armazenar, consultar e atualizar as informações de
usuários, lojas, produtos, preços, categorias e promoções.

Essa arquitetura permitirá que a interface solicite informações ao
sistema, que serão processadas pelo Next.js e consultadas no banco de
dados SQL, apresentando os resultados de maneira organizada ao
consumidor.

## 9. Plataforma e tecnologias adotadas

  -----------------------------------------------------------------------
  Tecnologia                          Finalidade
  ----------------------------------- -----------------------------------
  Next.js                             Desenvolvimento da interface e
                                      processamento das funcionalidades e
                                      regras do sistema (front-end e
                                      back-end).

  HTML                                Estruturação das páginas e dos
                                      elementos da interface (front-end).

  CSS                                 Estilização da interface e
                                      adaptação para diferentes tamanhos
                                      de tela.

  SQL                                 Armazenamento, consulta e
                                      atualização dos dados do sistema.
  -----------------------------------------------------------------------

O Achei será desenvolvido como uma aplicação web responsiva, podendo ser
acessado pelo navegador de celulares, tablets e computadores. A
interface e o processamento das funcionalidades serão desenvolvidos com
Next.js, com HTML para estruturar os conteúdos e CSS para estilizar a
interface. O SQL será utilizado para armazenar os dados.

## 10. Tecnologia incorporada à solução

### Gerenciamento de estado da interface (front-end)

O gerenciamento de estado será aplicado na parte visual do Achei para
manter as informações e condições da interface organizadas durante a
utilização do sistema. Ele permitirá controlar, por exemplo, os termos
digitados na pesquisa, os filtros selecionados, a categoria escolhida e
os resultados que devem ser apresentados ao consumidor.

Dessa forma, quando o usuário realizar uma pesquisa de produto,
selecionar uma categoria ou acessar uma loja, a interface poderá
apresentar as informações correspondentes de maneira consistente e
organizada.

Na prática, o funcionamento previsto será:

1.  O consumidor acessa o Achei e abre a página de pesquisa ou de lojas.
2.  A interface apresenta os campos, filtros e informações disponíveis.
3.  O usuário digita um produto ou seleciona uma categoria.
4.  O sistema atualiza as informações exibidas de acordo com a ação
    realizada.
5.  Os resultados são apresentados de forma organizada, permitindo que o
    consumidor consulte as lojas que comercializam o produto.

O objetivo é evitar que as informações exibidas fiquem desorganizadas ou
desatualizadas durante a navegação entre as funcionalidades. O
gerenciamento de estado será tratado como parte da organização do
front-end, sem acrescentar outras linguagens ou tecnologias à lista
definida para o projeto.

## 11. Resultados esperados

Espera-se que o Achei proporcione uma experiência de compra mais prática
e eficiente, reduzindo as dificuldades encontradas pelos consumidores
durante a procura por lojas, produtos e serviços no Shopping Capim
Dourado.

### Para os consumidores

O aplicativo oferecerá economia de tempo, facilidade de localização e
maior acesso às promoções.

### Para os lojistas

Representará uma oportunidade de divulgação de produtos, aumento da
visibilidade e aproximação com potenciais clientes.

## 12. Considerações finais

O Achei apresenta uma proposta de integração entre tecnologia e
experiência de compra, buscando solucionar dificuldades comuns
enfrentadas pelos consumidores dentro do Shopping Capim Dourado.

Seu principal objetivo é permitir que as pessoas encontrem facilmente
aquilo que procuram, seja uma loja, um produto, uma promoção ou um
serviço.

Com a integração de pesquisa de produtos, mapas de localização e
divulgação de ofertas, o aplicativo pretende transformar a maneira como
os consumidores exploram e aproveitam os espaços do Shopping Capim
Dourado.

------------------------------------------------------------------------

**ACHEI: Explore possibilidades e encontre novidades!**
