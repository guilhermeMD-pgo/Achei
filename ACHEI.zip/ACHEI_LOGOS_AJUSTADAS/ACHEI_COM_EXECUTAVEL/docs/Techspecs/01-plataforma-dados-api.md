# Tech spec 01 — Plataforma, dados e contratos de API

**Responsável:** Integrante 1 — fundação técnica  
**Objetivo:** entregar a base executável que os outros três integrantes possam usar em paralelo: aplicação Next.js, persistência SQL, autenticação, layout compartilhado e contratos estáveis entre módulos.

## Escopo

- Criar uma única aplicação Next.js na raiz do repositório. Migrar o protótipo em `ACHEI!!` como referência visual/conteúdo; não manter duas aplicações concorrentes.
- Definir rotas, navegação global, estrutura responsiva, estilos-base e componentes compartilhados mínimos (cabeçalho, navegação, mensagens de carregamento/erro/vazio).
- Configurar acesso SQL apenas no servidor, migrações versionadas, dados de demonstração e instruções para iniciar o projeto.
- Implementar cadastro, login, logout e sessão mínima para consumidores e lojistas. Armazenar senha somente com hash seguro; nunca retornar ou registrar senha. Contas de lojista são criadas/associadas por seed ou administração, não por cadastro público.
- Definir modelos e validação compartilhados. Os módulos 02–04 implementam seus próprios endpoints e telas usando esses modelos e a infraestrutura entregue aqui.

## Decisões de MVP

- Usar Next.js com App Router e seus Route Handlers para interface e API. Não criar um segundo servidor Python nem expor acesso SQL ao navegador.
- A proposta define SQL, mas não escolhe um banco. Na ausência de banco já provisionado, usar SQLite local para a demonstração; confirmar essa decisão com a equipe antes de implementar o adaptador. Se o deploy escolhido não oferecer armazenamento persistente local, usar um banco SQL hospedado antes de publicar.
- Usar dados sintéticos claramente identificados como demonstração. Não apresentar lojas, preços, promoções, mapa ou disponibilidade como dados oficiais do shopping sem validação do shopping/lojistas.
- Não incluir OAuth, recuperação de senha por e-mail ou gestão complexa de papéis no MVP.

## Modelo de dados mínimo

Todos os identificadores são estáveis; valores monetários são números decimais em reais; datas de validade são armazenadas em ISO 8601 e comparadas no servidor.

- `User`: `id`, `name`, `email` único, `passwordHash`, `role` (`consumer`, `merchant` ou `admin`).
- `Store`: `id`, `name`, `category`, `description`, `floor`, `unit`, `phone` opcional, `ownerUserId` opcional e `active`.
- `Product`: `id`, `storeId`, `name`, `description`, `category`, `price` opcional e `availability` (`available`, `unconfirmed` ou `unavailable`).
- `Promotion`: `id`, `storeId`, `productId` opcional, `title`, `description`, `discountPercent` ou preço promocional, `startsAt`, `endsAt` e `active`.
- `MapNode` / `MapEdge`: pontos e conexões para a planta esquemática; o contrato do módulo 04 define coordenadas e acessibilidade.
- `Favorite`: `userId`, `targetType` (`store`, `product`, `promotion`) e `targetId`, com unicidade por usuário e alvo.
- `SearchHistory`: `userId`, `query` e `createdAt`.
- `UserSettings`: `userId` e preferências simples definidas pelo módulo 04. Não armazenar dados pessoais que não sejam necessários ao MVP.

## Contratos compartilhados

- API com JSON. Respostas de coleção usam `{ "items": [...] }`; erros usam `{ "error": { "code": "...", "message": "..." } }` com status HTTP apropriado.
- Rotas públicas: `GET /api/stores`, `GET /api/products`, `GET /api/promotions`, `GET /api/services`.
- Conta: `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`; sessão baseada em cookie `HttpOnly`, `Secure` em produção e `SameSite`.
- Rotas de lojista exigem sessão com papel `merchant` ou `admin`; cada lojista só pode alterar a loja associada à própria conta.
- Rotas pessoais exigem sessão de consumidor. Nenhuma consulta ou alteração pessoal pode confiar em `userId` enviado pelo cliente; identificar o usuário pela sessão.
- Não duplicar navegação, estilos globais ou cliente de banco nos módulos. Mudanças em contratos compartilhados devem ser combinadas com os responsáveis afetados.

## Fora de escopo

- Pagamentos, carrinho, integração com ERP/POS, sincronização de estoque, geolocalização indoor e dados reais sem autorização.
- Sistema de administração geral completo. O acesso `admin` existe apenas para seed/demonstração, salvo necessidade acordada.

## Critérios de aceite

- Um integrante novo consegue instalar dependências, configurar o banco, aplicar migrações, carregar dados de demonstração e iniciar a aplicação seguindo o README atualizado.
- A aplicação e a API usam a mesma configuração de banco; erros de conexão/configuração são visíveis, sem dados falsos como fallback silencioso.
- Rotas privadas rejeitam requisições sem sessão; um lojista não consegue alterar dados de outra loja.
- O layout compartilhado funciona em celular e desktop e fornece navegação para início, busca, promoções, lojas, mapa e conta.
- Os contratos acima e os modelos estão documentados e não divergem entre módulos.

## Dependências e handoff

Entregar primeiro: esquema/migrações, seed, sessão, layout e contratos. Avisar os integrantes 02–04 sobre qualquer alteração incompatível. Cada integrante é responsável pelos testes do próprio módulo; a integração final é feita em conjunto.
