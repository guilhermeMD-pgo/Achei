# Tech spec 03 — Promoções e gestão do lojista

**Responsável:** Integrante 3 — ofertas e atualização do catálogo  
**Objetivo:** tornar promoções visíveis ao consumidor e permitir que cada lojista autorizado mantenha os dados de sua loja, produtos e ofertas atualizados.

## Escopo funcional

- Seção de promoções em destaque na página inicial e página com todas as ofertas ativas.
- Detalhe da oferta com loja, produto relacionado quando houver, preço/desconto e período de validade.
- Área do lojista para consultar e editar informações básicas da própria loja, criar/editar/desativar produtos e criar/editar/desativar promoções.
- Validar os dados no servidor: campos obrigatórios, preço/desconto válido e data final posterior à inicial.
- Promoções públicas só aparecem como ativas quando habilitadas e dentro do período de validade, calculado no servidor.
- Apresentar condições e período da promoção. Não inventar preço original, preço promocional ou percentual se os dados não foram informados.

## API sob responsabilidade deste módulo

- `GET /api/promotions?active=true`: ofertas vigentes, incluindo dados resumidos da loja e do produto relacionado.
- `GET /api/promotions/:id`: detalhes públicos de uma oferta.
- Rotas autenticadas sob `/api/merchant/store`, `/api/merchant/products` e `/api/merchant/promotions` para consultar e manter dados da loja associada à sessão.
- Operações de escrita exigem papel `merchant` ou `admin`; verificar propriedade da loja no servidor em toda operação, inclusive por identificador de produto/oferta. Não confiar apenas em controles da interface.
- `active=false` ou exclusão lógica remove item das consultas públicas sem apagar referências históricas necessárias.

## Interface e estados

- Consumidores veem uma mensagem clara quando não há ofertas vigentes.
- Lojista vê confirmação de sucesso e erro de validação, além de formulário preenchido com os dados existentes ao editar.
- Mostrar estados vazios e carregamento; impedir envio duplicado enquanto uma operação estiver em andamento.
- Em telas pequenas, formulário e lista de produtos/ofertas devem permanecer operáveis.

## Fora de escopo e limites de confiança

- Portal de autoinscrição de lojistas, aprovação de campanhas pelo shopping, cupons, pagamento, integração de estoque e notificações.
- A demonstração não comprova que uma oferta está vigente na loja física; incluir aviso de que preço e disponibilidade devem ser confirmados com o estabelecimento.
- Não publicar conteúdo ou imagens de lojas reais sem autorização. Usar material e dados de demonstração fornecidos pela equipe.

## Critérios de aceite

- Um consumidor vê apenas promoções habilitadas e dentro do período; promoções futuras, expiradas ou desativadas não aparecem como vigentes.
- Um lojista autenticado consegue manter produtos e promoções da própria loja, e não consegue ler/alterar registros de outra loja manipulando IDs ou requisições.
- Dados inválidos são rejeitados no servidor com mensagem acionável e não deixam registros parcialmente alterados.
- Alterações no catálogo aparecem na busca e as promoções válidas aparecem na página inicial sem duplicar dados do produto/loja.
- Testes cobrem validade temporal, desconto/preço inválido, usuário sem papel e tentativa de acesso a outra loja.

## Dependências

- Requer modelos, banco, sessão, papéis, seed e layout do módulo 01.
- Produtos e lojas devem obedecer ao contrato do módulo 02; coordenadas/localização usadas em loja devem ser acordadas com o módulo 04.
- Combinar com o integrante 1 quais contas de lojista e lojas de demonstração serão carregadas no seed.
