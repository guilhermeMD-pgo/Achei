# Tech spec 02 — Lojas, catálogo e pesquisa de produtos

**Responsável:** Integrante 2 — descoberta de lojas e produtos  
**Objetivo:** permitir que o consumidor encontre lojas e descubra quais delas comercializam um produto, com resultados úteis, localizações e encaminhamento para o mapa.

## Escopo funcional

- Tela de lojas com listagem, busca por nome e filtro por categoria.
- Tela de detalhes da loja com nome, categoria, descrição, piso/unidade, contato quando disponível e produtos cadastrados.
- Pesquisa de produtos por nome, categoria e loja; exibir nome, loja, categoria, preço quando informado e disponibilidade com indicação clara de dado não confirmado.
- Tela de detalhes do produto com loja e localização, além de ação para abrir o mapa no destino selecionado.
- Pesquisa acessível também a partir da página inicial, preservando o termo digitado ao navegar para os resultados.
- Registrar no histórico do usuário autenticado as consultas válidas, integrando com o contrato de histórico do módulo 04. Para visitante, busca funciona sem cadastro.

## API sob responsabilidade deste módulo

- `GET /api/stores?q=&category=`: lojas ativas, filtráveis por texto/categoria.
- `GET /api/stores/:id`: detalhes de uma loja e seus produtos.
- `GET /api/products?q=&category=&storeId=`: produtos de lojas ativas; busca textual sem distinção entre maiúsculas e minúsculas.
- `GET /api/products/:id`: detalhes do produto e da loja relacionada.
- Se houver usuário autenticado, registrar a consulta pelo endpoint acordado de histórico; erro ao salvar histórico não deve ocultar os resultados da busca.

Parâmetros ausentes não devem causar erro. Consultas sem termo retornam o catálogo filtrado; consultas sem resultado retornam lista vazia, não erro. Limitar tamanho de texto e parâmetros de paginação se a quantidade de seed puder crescer.

## Interface e estados

- Incluir estados de carregamento, erro recuperável, lista vazia e resultado sem preço/localização cadastrados.
- Não exibir preço zero como se fosse preço real. Exibir “Preço não informado” quando nulo.
- Não afirmar disponibilidade em tempo real. Mostrar “Disponibilidade não confirmada” quando essa informação não for validada pelo lojista.
- Em telas pequenas, busca, filtros, cartões e detalhes permanecem utilizáveis sem rolagem horizontal.
- Usar HTML semântico, rótulos associados aos campos, foco visível e botões/links com nomes compreensíveis.

## Fora de escopo

- Cadastro/edição de lojas e produtos por lojistas (módulo 03).
- Promoções e preços promocionais (módulo 03).
- Implementar planta ou cálculo de rota; este módulo apenas encaminha o identificador da loja ao mapa (módulo 04).
- Busca fuzzy, recomendação personalizada ou consulta de estoque em tempo real.

## Critérios de aceite

- É possível procurar por nome de produto e obter todas as lojas correspondentes, com localização e preço apenas quando cadastrados.
- Busca por nome de loja e filtro de categoria funcionam em conjunto e ignoram diferenças de caixa/espaços periféricos.
- Abrir um resultado mostra detalhes coerentes com a listagem; a ação “Ver no mapa” leva ao módulo 04 com o destino correto.
- Catálogo vazio, produto sem preço, erro de API e busca sem resultados têm mensagens distintas e compreensíveis.
- Testes cobrem filtros combinados, busca vazia, ausência de resultados e dados opcionais ausentes.

## Dependências

- Requer os modelos, migrações, seed, layout e padrão de resposta do módulo 01.
- Alinhar com os módulos 03 e 04 os campos de produto/loja e os identificadores usados pelas promoções e pelo mapa antes de estabilizar os componentes.
