# Tech spec 04 — Mapa, perfil e jornada integrada

**Responsável:** Integrante 4 — orientação no shopping e recursos do consumidor  
**Objetivo:** permitir que o consumidor localize lojas e serviços em uma planta demonstrativa, consulte um caminho simples e mantenha perfil, favoritos, histórico e preferências.

## Escopo funcional

### Mapa e serviços

- Exibir planta esquemática do shopping com lojas, praça de alimentação, banheiros, elevadores, escadas e estacionamento cadastrados.
- Permitir selecionar um ponto de origem manual (por exemplo, entrada) e um destino de loja ou serviço.
- Apresentar caminho entre pontos conectados na planta e destacar o percurso; oferecer filtro/alternativa acessível somente se os dados das rotas identificarem claramente esse atributo.
- Receber o identificador da loja a partir dos detalhes de loja/produto e abrir o destino correto.
- A planta deve indicar piso e identificação textual dos pontos; não depender exclusivamente de cor, ícone ou posicionamento visual.

### Perfil e preferências

- Telas de cadastro, login e logout usando os endpoints do módulo 01; não reimplementar autenticação.
- Consultar/editar informações básicas do perfil autenticado e preferências simples.
- Exibir histórico de pesquisas e permitir limpar o histórico do próprio usuário.
- Adicionar/remover lojas, produtos e promoções aos favoritos; exibir a lista consolidada e permitir navegar para os detalhes correspondentes.
- Visitantes podem navegar e pesquisar; ações pessoais solicitam login e preservam a navegação de retorno quando viável.

## API sob responsabilidade deste módulo

- `GET /api/services`: lista de serviços e posição/piso.
- `GET /api/map/route?fromId=&toId=&accessible=`: caminho da planta esquemática; retornar erro de domínio compreensível quando não houver caminho.
- Rotas autenticadas `/api/me` e `/api/me/settings` para perfil e preferências.
- Rotas autenticadas `/api/me/favorites` para listar/adicionar/remover alvos permitidos e `/api/me/search-history` para listar/limpar histórico.
- Cada consulta ou mutação de perfil, favorito ou histórico usa exclusivamente o usuário obtido da sessão, nunca um `userId` fornecido pelo navegador.

## Limites críticos do mapa

- Não há no material da proposta planta oficial, coordenadas, grafo de corredores, posição atual do usuário ou dados de acessibilidade. Solicitar esses dados à equipe/organização; enquanto não existirem, usar planta fictícia claramente identificada como esquemática.
- Sem hardware ou integração de localização, não prometer “você está aqui”, navegação em tempo real ou rota oficial. O consumidor escolhe a origem manualmente.
- O caminho só é válido dentro do grafo cadastrado. Não sugerir rota quando os dados não conectam origem e destino.

## Critérios de aceite

- Selecionar uma loja em busca/detalhes e escolher origem e destino no mapa destaca o percurso correspondente; destino inexistente ou sem rota mostra mensagem explícita.
- Serviços e lojas exibem nome e piso em formato acessível, inclusive em dispositivos móveis.
- Usuário autenticado consegue editar o próprio perfil, consultar/limpar o próprio histórico e gerenciar favoritos; outro usuário não acessa esses dados.
- Favoritos de lojas, produtos e promoções levam aos detalhes corretos; remover um favorito o retira da lista sem apagar a entidade original.
- Fluxo de demonstração ponta a ponta: encontrar produto → abrir loja → ver no mapa; abrir promoção → favoritar → localizar loja; pesquisar → ver histórico no perfil.
- Testes cobrem rota sem conexão, origem igual ao destino, visitante sem sessão e isolamento de dados pessoais.

## Dependências e integração

- Requer contratos, sessão, modelos e layout do módulo 01; identificadores e campos de loja/produto dos módulos 02 e 03.
- Acordar com os módulos 01 e 03 a origem dos dados de mapa por loja e quem fornece os dados iniciais de serviços.
- Realizar smoke test dos fluxos integrados com dados de demonstração; cada módulo continua responsável por seus testes unitários/de integração.
