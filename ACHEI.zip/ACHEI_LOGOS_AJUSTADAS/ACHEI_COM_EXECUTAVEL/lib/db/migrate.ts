import { readFileSync, readdirSync } from "node:fs";
import path from "node:path";
import type Database from "better-sqlite3";

export function migrateDatabase(database: Database.Database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      name TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    )
  `);

  const migrationDirectory = path.join(process.cwd(), "migrations");
  const migrationFiles = readdirSync(migrationDirectory)
    .filter((name) => /^\d{3}_[a-z0-9_]+\.sql$/.test(name))
    .sort();
  const hasMigration = database.prepare(
    "SELECT 1 FROM schema_migrations WHERE name = ?",
  );
  const recordMigration = database.prepare(
    "INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)",
  );

  for (const name of migrationFiles) {
    if (hasMigration.get(name)) {
      continue;
    }

    const sql = readFileSync(path.join(migrationDirectory, name), "utf8");
    database.transaction(() => {
      database.exec(sql);
      recordMigration.run(name, new Date().toISOString());
    })();
  }
}
