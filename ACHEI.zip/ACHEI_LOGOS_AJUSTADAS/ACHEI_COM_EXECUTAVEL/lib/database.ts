import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import path from "node:path";

const configuredPath = process.env.DATABASE_PATH ?? ".data/achei.sqlite";
const databasePath = path.resolve(process.cwd(), configuredPath);

mkdirSync(path.dirname(databasePath), { recursive: true });

export const database = new Database(databasePath);

database.pragma("foreign_keys = ON");
database.pragma("journal_mode = WAL");
database.function(
  "unicode_lower",
  { deterministic: true },
  (value: string) => value.toLocaleLowerCase("pt-BR"),
);
