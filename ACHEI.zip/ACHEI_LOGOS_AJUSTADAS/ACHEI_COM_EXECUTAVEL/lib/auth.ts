import "server-only";

import {
  createHash,
  randomBytes,
} from "node:crypto";
import { cookies } from "next/headers";
import { database } from "@/lib/db";
import type { UserRole } from "@/lib/models";
import { verifyPassword } from "@/lib/password";

export const SESSION_COOKIE = "achei_session";
const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;

export type AuthenticatedUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
};

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function getAuthenticatedUser(): Promise<AuthenticatedUser | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || !/^[A-Za-z0-9_-]{43}$/.test(token)) {
    return null;
  }

  const now = new Date().toISOString();
  return (
    database
      .prepare<[string, string], AuthenticatedUser>(
        `SELECT u.id, u.name, u.email, u.role
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token_hash = ? AND s.expires_at > ?`,
      )
      .get(hashToken(token), now) ?? null
  );
}

export function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const createdAt = new Date();
  const expiresAt = new Date(
    createdAt.getTime() + SESSION_LIFETIME_MS,
  ).toISOString();

  database
    .prepare(
      `INSERT INTO sessions (token_hash, user_id, created_at, expires_at)
       VALUES (?, ?, ?, ?)`,
    )
    .run(hashToken(token), userId, createdAt.toISOString(), expiresAt);

  return { token, expiresAt };
}

export async function revokeCurrentSession() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (token && /^[A-Za-z0-9_-]{43}$/.test(token)) {
    database
      .prepare("DELETE FROM sessions WHERE token_hash = ?")
      .run(hashToken(token));
  }
}
