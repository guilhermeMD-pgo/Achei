/** Logos oficiais obtidas de arquivos públicos de referência. O fallback tipográfico
 * permanece disponível caso o provedor externo esteja indisponível.
 */
export type StoreLogoSpec = {
  text: string;
  background: string;
  color: string;
  image?: string;
  round?: boolean;
};

const commons = (file: string) => `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(file)}`;

export const storeLogos: Record<string, StoreLogoSpec> = {
  "cds-renner": { text: "RENNER", background: "#c8102e", color: "#ffffff", image: commons("Logotipo das Lojas Renner.svg") },
  "cds-ca": { text: "C&A", background: "#0b3a8c", color: "#ffffff", image: commons("Logo-cea-muito.svg") },
  "cds-riachuelo": { text: "riachuelo", background: "#ffffff", color: "#d6002a", image: commons("Logotipo da Riachuelo (2026).svg") },
  "cds-centauro": { text: "CENTAURO", background: "#ffffff", color: "#101010", image: commons("Logo-lojas-centauro.jpg") },
  "cds-outback": { text: "OUTBACK", background: "#ffffff", color: "#28231b", image: commons("OutbackLogo.png") },
  "cds-cinemark": { text: "CINEMARK", background: "#ffffff", color: "#292d49", image: commons("Cinemark Logo.svg") },
  // A logo oficial da Leitura não foi localizada em fonte pública confiável nesta revisão.
  "cds-leitura": { text: "LEITURA", background: "#0f6b5c", color: "#ffffff" },
  "cds-mcdonalds": { text: "M", background: "#ffffff", color: "#ffc72c", image: commons("McDonald's.svg"), round: true },
  "cds-giraffas": { text: "GIRAFFAS", background: "#ffffff", color: "#3b2814", image: commons("Giraffas (fast food).svg") },
  "cds-subway": { text: "SUBWAY", background: "#ffffff", color: "#176a42", image: commons("Subway 2016 logo.svg") },
};

export function logoFor(storeId: string, storeName: string): StoreLogoSpec {
  return storeLogos[storeId] ?? {
    text: storeName.slice(0, 2).toUpperCase(),
    background: "#3b2d16",
    color: "#f0d58d",
  };
}
