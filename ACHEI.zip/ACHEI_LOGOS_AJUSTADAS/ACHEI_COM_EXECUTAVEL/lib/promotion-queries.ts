import type Database from "better-sqlite3";

export type PublicPromotion = {
  id: string;
  storeId: string;
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPrice: number | null;
  startsAt: string;
  endsAt: string;
  isDemo: boolean;
  storeName: string;
  floor: string;
  unit: string;
  productName: string | null;
};

type PromotionRow = Omit<PublicPromotion, "isDemo"> & { isDemo: number };

const publicPromotionSelect = `
  SELECT p.id, p.store_id AS storeId, p.product_id AS productId, p.title,
         p.description, p.discount_percent AS discountPercent,
         p.promotional_price_cents / 100.0 AS promotionalPrice,
         p.starts_at AS startsAt, p.ends_at AS endsAt,
         p.is_demo AS isDemo, s.name AS storeName, s.floor, s.unit,
         pr.name AS productName
  FROM promotions p
  JOIN stores s ON s.id = p.store_id
  LEFT JOIN products pr
    ON pr.id = p.product_id AND pr.store_id = p.store_id AND pr.active = 1
  WHERE p.active = 1 AND s.active = 1
    AND (p.product_id IS NULL OR pr.id IS NOT NULL)
    AND p.starts_at <= ? AND p.ends_at >= ?
`;

function mapPromotion(row: PromotionRow): PublicPromotion {
  return { ...row, isDemo: Boolean(row.isDemo) };
}

export function listActivePromotionsInDatabase(
  database: Database.Database,
  now: string,
  limit = 100,
) {
  const rows = database
    .prepare<[string, string, number], PromotionRow>(
      `${publicPromotionSelect}
       ORDER BY p.ends_at, p.title
       LIMIT ?`,
    )
    .all(now, now, limit);
  return rows.map(mapPromotion);
}

export function findActivePromotionInDatabase(
  database: Database.Database,
  id: string,
  now: string,
) {
  const row = database
    .prepare<[string, string, string], PromotionRow>(
      `${publicPromotionSelect} AND p.id = ?`,
    )
    .get(now, now, id);
  return row ? mapPromotion(row) : null;
}
