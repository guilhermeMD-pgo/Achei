/**
 * Rotas esquemáticas do mapa ilustrativo. Os corredores seguem o desenho vetorial
 * (linhas horizontais y=29/51/73 e verticais x=27/50/73, em % da imagem).
 * Não é um grafo oficial de circulação: serve para demonstração.
 */
export type Point = { x: number; y: number };
export type MapFloor = "Térreo" | "2º pavimento";

export type RouteOrigin = {
  id: string;
  label: string;
  color: string;
  floor: MapFloor | "all";
  x: number;
  y: number;
};

export type MallRoute = {
  id: string;
  label: string;
  color: string;
  length: number;
  shortest: boolean;
  points: Point[];
};

type Segment = { a: Point; b: Point };

const H = [29, 51, 73];
const V = [27, 50, 73];
export const corridorSegments: Segment[] = [
  ...H.map((y) => ({ a: { x: 4, y }, b: { x: 96, y } })),
  ...V.map((x) => ({ a: { x, y: 5 }, b: { x, y: 95 } })),
];

export const routeOrigins: RouteOrigin[] = [
  { id: "entrada", label: "Entrada principal", color: "#2f7a54", floor: "Térreo", x: 50, y: 91 },
  { id: "elevador", label: "Elevador", color: "#2b5fa8", floor: "all", x: 84, y: 22 },
  { id: "escadas", label: "Escadas", color: "#8a4fa8", floor: "all", x: 16, y: 79 },
  { id: "banheiros", label: "Banheiros", color: "#2f8f9d", floor: "Térreo", x: 14, y: 22 },
];

const EPS = 1e-6;
const dist = (p: Point, q: Point) => Math.hypot(p.x - q.x, p.y - q.y);
const key = (p: Point) => `${p.x.toFixed(4)},${p.y.toFixed(4)}`;

function snapToSegment(p: Point, s: Segment): Point {
  const dx = s.b.x - s.a.x;
  const dy = s.b.y - s.a.y;
  const t = Math.max(0, Math.min(1, ((p.x - s.a.x) * dx + (p.y - s.a.y) * dy) / (dx * dx + dy * dy)));
  return { x: s.a.x + t * dx, y: s.a.y + t * dy };
}

export function snapToCorridor(p: Point): Point {
  let best = snapToSegment(p, corridorSegments[0]);
  for (const s of corridorSegments) {
    const q = snapToSegment(p, s);
    if (dist(p, q) < dist(p, best)) best = q;
  }
  return best;
}

function onSegment(p: Point, s: Segment) {
  return dist(snapToSegment(p, s), p) < EPS;
}

function buildGraph(extra: Point[]) {
  const nodes = new Map<string, Point>();
  const add = (p: Point) => nodes.set(key(p), p);
  for (const s of corridorSegments) {
    add(s.a);
    add(s.b);
  }
  for (const h of corridorSegments.slice(0, H.length)) {
    for (const v of corridorSegments.slice(H.length)) add({ x: v.a.x, y: h.a.y });
  }
  extra.forEach(add);

  const adjacency = new Map<string, { to: string; w: number }[]>();
  const link = (p: Point, q: Point) => {
    const w = dist(p, q);
    if (w < EPS) return;
    (adjacency.get(key(p)) ?? adjacency.set(key(p), []).get(key(p))!).push({ to: key(q), w });
    (adjacency.get(key(q)) ?? adjacency.set(key(q), []).get(key(q))!).push({ to: key(p), w });
  };
  for (const s of corridorSegments) {
    const onIt = [...nodes.values()]
      .filter((p) => onSegment(p, s))
      .sort((p, q) => dist(s.a, p) - dist(s.a, q));
    for (let i = 1; i < onIt.length; i++) link(onIt[i - 1], onIt[i]);
  }
  return { nodes, adjacency };
}

function shortestPath(from: Point, to: Point): { points: Point[]; length: number } {
  const { nodes, adjacency } = buildGraph([from, to]);
  const start = key(from);
  const goal = key(to);
  const best = new Map<string, number>([[start, 0]]);
  const previous = new Map<string, string>();
  const open = new Set<string>([start]);
  while (open.size) {
    let current = "";
    let currentCost = Infinity;
    for (const id of open) {
      const cost = best.get(id) ?? Infinity;
      if (cost < currentCost) {
        current = id;
        currentCost = cost;
      }
    }
    open.delete(current);
    if (current === goal) break;
    for (const edge of adjacency.get(current) ?? []) {
      const next = currentCost + edge.w;
      if (next < (best.get(edge.to) ?? Infinity)) {
        best.set(edge.to, next);
        previous.set(edge.to, current);
        open.add(edge.to);
      }
    }
  }
  if (!best.has(goal)) return { points: [from, to], length: dist(from, to) };
  const ids = [goal];
  while (ids[0] !== start) ids.unshift(previous.get(ids[0])!);
  return { points: ids.map((id) => nodes.get(id)!), length: best.get(goal)! };
}

function simplify(points: Point[]) {
  const out: Point[] = [];
  for (const p of points) {
    const last = out[out.length - 1];
    if (last && dist(last, p) < EPS) continue;
    const before = out[out.length - 2];
    if (before && last) {
      const cross = (last.x - before.x) * (p.y - last.y) - (last.y - before.y) * (p.x - last.x);
      if (Math.abs(cross) < EPS) {
        out[out.length - 1] = p;
        continue;
      }
    }
    out.push(p);
  }
  return out;
}

export function originsForFloor(floor: MapFloor) {
  return routeOrigins.filter((o) => o.floor === "all" || o.floor === floor);
}

/** Calcula uma rota para cada ponto de partida disponível no pavimento da loja. */
export function computeRoutes(destination: Point, floor: MapFloor): MallRoute[] {
  const destinationSnap = snapToCorridor(destination);
  const routes = originsForFloor(floor).map((origin) => {
    const originSnap = snapToCorridor(origin);
    const walk = shortestPath(originSnap, destinationSnap);
    const points = simplify([origin, originSnap, ...walk.points, destinationSnap, destination]);
    const length =
      dist(origin, originSnap) + walk.length + dist(destinationSnap, destination);
    return { id: origin.id, label: origin.label, color: origin.color, length, shortest: false, points };
  });
  const min = Math.min(...routes.map((r) => r.length));
  return routes
    .map((r) => ({ ...r, shortest: Math.abs(r.length - min) < EPS }))
    .sort((a, b) => a.length - b.length);
}

export function pathData(points: Point[]) {
  return points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" ");
}
