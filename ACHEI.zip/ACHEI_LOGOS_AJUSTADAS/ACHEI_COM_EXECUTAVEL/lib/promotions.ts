import "server-only";

import { database } from "@/lib/db";
import {
  findActivePromotionInDatabase,
  listActivePromotionsInDatabase,
} from "@/lib/promotion-queries";

export type { PublicPromotion } from "@/lib/promotion-queries";

export function listActivePromotions(limit = 100) {
  const now = new Date().toISOString();
  return listActivePromotionsInDatabase(database, now, limit);
}

export function findActivePromotion(id: string) {
  const now = new Date().toISOString();
  return findActivePromotionInDatabase(database, id, now);
}
