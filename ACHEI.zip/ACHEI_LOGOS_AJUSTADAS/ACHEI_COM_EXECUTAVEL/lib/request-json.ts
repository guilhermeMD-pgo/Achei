import { errorResponse } from "@/lib/api-response";

export async function readRequestJson(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (Number.isFinite(contentLength) && contentLength > 32_768) {
    return {
      ok: false as const,
      response: errorResponse("request_too_large", "A requisição excede o limite permitido.", 413),
    };
  }

  try {
    return { ok: true as const, value: (await request.json()) as unknown };
  } catch (error) {
    if (error instanceof SyntaxError) {
      return {
        ok: false as const,
        response: errorResponse("invalid_json", "O corpo da requisição não é um JSON válido.", 400),
      };
    }
    throw error;
  }
}
