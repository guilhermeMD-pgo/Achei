/**
 * Pontos de referência transcritos da planta operacional enviada pelo usuário
 * (Capim Dourado Shopping, novembro/2026). x/y são percentuais sobre a imagem
 * de cada pavimento. As posições são marcadores de localização, não polígonos
 * cadastrais nem um grafo oficial de rotas.
 */
export type MallMapStore = {
  id: string;
  name: string;
  category: string;
  description: string;
  floor: "Térreo" | "2º pavimento";
  unit: string;
  nodeId: string;
  x: number;
  y: number;
};

export const mallMapStores: MallMapStore[] = [
  { id: "cds-renner", name: "Renner", category: "Vestuário", description: "Loja identificada na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-renner", x: 24.5, y: 65.2 },
  { id: "cds-ca", name: "C&A", category: "Vestuário", description: "Loja identificada na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-ca", x: 48.2, y: 35.1 },
  { id: "cds-riachuelo", name: "Riachuelo", category: "Vestuário", description: "Identificada pelo logotipo RCHLO na planta.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-riachuelo", x: 49.7, y: 55.2 },
  { id: "cds-centauro", name: "Centauro", category: "Esportes", description: "Loja identificada na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-centauro", x: 39.1, y: 69.5 },
  { id: "cds-outback", name: "Outback", category: "Alimentação", description: "Restaurante identificado na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-outback", x: 54.0, y: 67.8 },
  { id: "cds-cinemark", name: "Cinemark", category: "Lazer", description: "Cinema identificado na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-cinemark", x: 72.8, y: 64.8 },
  { id: "cds-leitura", name: "Leitura", category: "Livraria", description: "Loja identificada na planta do térreo.", floor: "Térreo", unit: "Não informada na planta", nodeId: "cds-node-leitura", x: 55.7, y: 45.1 },
  { id: "cds-giraffas", name: "Giraffas", category: "Alimentação", description: "Estabelecimento identificado na planta da praça de alimentação.", floor: "2º pavimento", unit: "Loja 202", nodeId: "cds-node-giraffas", x: 41.3, y: 69.4 },
  { id: "cds-subway", name: "Subway", category: "Alimentação", description: "Estabelecimento identificado na planta da praça de alimentação.", floor: "2º pavimento", unit: "Loja 205", nodeId: "cds-node-subway", x: 60.0, y: 69.1 },
  { id: "cds-mcdonalds", name: "McDonald's", category: "Alimentação", description: "Estabelecimento identificado na planta da praça de alimentação.", floor: "2º pavimento", unit: "Loja 214", nodeId: "cds-node-mcdonalds", x: 42.0, y: 26.2 },
];

/** Lojas retiradas do catálogo (metade da planta). O seed desativa estes ids em bancos já existentes. */
export const removedMallStoreIds = ["cds-marisa", "cds-stz", "cds-big-lar", "cds-pernambucanas", "cds-kin-sui", "cds-express", "cds-divino-fogao", "cds-pizza-21", "cds-spoleto", "cds-mundo-imersivo"];
