import "server-only";

export { database } from "@/lib/database";
