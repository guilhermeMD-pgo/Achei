export function itemsResponse<T>(items: T[]) {
  return Response.json({ items });
}

export function errorResponse(
  code: string,
  message: string,
  status: number,
) {
  return Response.json({ error: { code, message } }, { status });
}

export function queryError(error: unknown) {
  if (error instanceof Error && error.message === "query_too_long") {
    return errorResponse(
      "invalid_query",
      "O texto de busca deve ter no máximo 100 caracteres.",
      400,
    );
  }

  console.error("Falha ao consultar dados da API.", error);
  return errorResponse(
    "internal_error",
    "Não foi possível consultar os dados agora.",
    500,
  );
}

export function queryText(value: string | null) {
  const query = value?.trim() ?? "";
  if (query.length > 100) {
    throw new Error("query_too_long");
  }
  return query;
}

export function likePattern(value: string) {
  return `%${value.replace(/[\\%_]/g, "\\$&")}%`;
}
