/**
 * Busca tolerante a erros: ignora acentos e maiúsculas, aceita plural, erros de digitação
 * (distância de edição) e sinônimos (ex.: "camisa" encontra "camiseta").
 */
export function normalize(text: string) {
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

export function tokenize(text: string) {
  return normalize(text)
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length > 1)
    .map(stem);
}

function stem(token: string) {
  return token.length > 3 && token.endsWith("s") ? token.slice(0, -1) : token;
}

export function editDistance(a: string, b: string) {
  if (a === b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diagonal = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const above = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diagonal + (a[i - 1] === b[j - 1] ? 0 : 1));
      diagonal = above;
    }
  }
  return prev[b.length];
}

const synonymGroups = [
  "camisa camiseta camisao blusa regata polo social tshirt roupa",
  "jaqueta casaco blusao jeans agasalho",
  "vestido saia roupa",
  "tenis sapato calcado sapatenis chuteira corrida caminhada",
  "bolsa mochila acessorio carteira",
  "bola futebol",
  "comida comer almoco jantar refeicao restaurante fome prato lanche alimentacao combo",
  "hamburguer burger lanche sanduiche sanduba",
  "sobremesa doce sorvete chocolate",
  "cinema filme ingresso pipoca sessao",
  "livro leitura romance ficcao manga hq quadrinho",
  "suco bebida refrigerante",
].map((g) => g.split(" ").map(stem));

function allowedDistance(word: string) {
  return word.length <= 3 ? 0 : word.length <= 6 ? 1 : 2;
}

function wordMatches(queryWord: string, word: string) {
  if (queryWord === word) return true;
  if (queryWord.length >= 4 && (word.startsWith(queryWord) || queryWord.startsWith(word)) && word.length >= 4) return true;
  return editDistance(queryWord, word) <= allowedDistance(queryWord);
}

function synonymsOf(queryWord: string) {
  const found = new Set<string>();
  for (const group of synonymGroups) {
    if (group.some((w) => wordMatches(queryWord, w))) group.forEach((w) => found.add(w));
  }
  found.delete(queryWord);
  return [...found];
}

export type Searchable = { id: string; name: string; description: string; category: string; storeName: string };

/** Pontuação de um item para a busca; 0 = sem correspondência. */
export function scoreItem(item: Searchable, query: string) {
  const queryWords = tokenize(query);
  if (queryWords.length === 0) return 0;
  const nameWords = tokenize(item.name);
  const otherWords = tokenize(`${item.description} ${item.category} ${item.storeName}`);
  let total = 0;
  for (const q of queryWords) {
    const synonyms = synonymsOf(q);
    let best = 0;
    for (const [words, weight] of [[nameWords, 2], [otherWords, 1]] as const) {
      for (const w of words) {
        if (wordMatches(q, w)) best = Math.max(best, 3 * weight);
        else if (synonyms.some((s) => wordMatches(s, w) && (s === w || s.length >= 4))) best = Math.max(best, 1.5 * weight);
      }
    }
    if (best === 0) return 0; // todas as palavras da busca precisam de alguma correspondência
    total += best;
  }
  return total;
}

function bigrams(text: string) {
  const t = ` ${normalize(text)} `;
  const set = new Set<string>();
  for (let i = 0; i < t.length - 1; i++) set.add(t.slice(i, i + 2));
  return set;
}

/** Similaridade aproximada (0–1), usada só para sugerir itens quando nada é encontrado. */
export function looseSimilarity(item: Searchable, query: string) {
  const q = bigrams(query);
  const words = `${item.name} ${item.category} ${item.storeName}`;
  const best = tokenize(words).reduce((max, w) => {
    const b = bigrams(w);
    const shared = [...q].filter((x) => b.has(x)).length;
    return Math.max(max, (2 * shared) / (q.size + b.size));
  }, 0);
  return best;
}

export function searchItems<T extends Searchable>(items: T[], query: string) {
  const matches = items
    .map((item) => ({ item, score: scoreItem(item, query) }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name, "pt-BR"));
  if (matches.length > 0) return { exact: matches.map((m) => m.item), suggestions: [] as T[] };
  const suggestions = items
    .map((item) => ({ item, sim: looseSimilarity(item, query) }))
    .filter((r) => r.sim >= 0.3)
    .sort((a, b) => b.sim - a.sim)
    .slice(0, 6)
    .map((r) => r.item);
  return { exact: [] as T[], suggestions };
}
