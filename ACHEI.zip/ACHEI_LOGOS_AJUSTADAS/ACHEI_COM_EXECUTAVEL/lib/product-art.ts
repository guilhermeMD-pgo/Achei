/**
 * Imagem de cada produto do catálogo demonstrativo. São ilustrações, não fotos reais.
 * Para usar uma foto real, salve public/products/<id-do-produto>.jpg (ex.: prod-cds-renner-1.jpg):
 * o componente ProductImage passa a mostrá-la automaticamente.
 */
export type ArtKind =
  | "tshirt" | "jacket" | "dress" | "shirt" | "sneaker" | "bag" | "ball" | "plate"
  | "dessert" | "ticket" | "popcorn" | "book" | "burger" | "icecream" | "juice" | "sub";

export type ProductArt = { kind: ArtKind; color: string };

export const productArt: Record<string, ProductArt> = {
  "prod-cds-renner-1": { kind: "tshirt", color: "#c8102e" },
  "prod-cds-renner-2": { kind: "jacket", color: "#3d6aa6" },
  "prod-cds-ca-1": { kind: "dress", color: "#d9527a" },
  "prod-cds-ca-2": { kind: "shirt", color: "#4a6fb0" },
  "prod-cds-riachuelo-1": { kind: "sneaker", color: "#e8e2d4" },
  "prod-cds-riachuelo-2": { kind: "bag", color: "#8a4fa8" },
  "prod-cds-centauro-1": { kind: "sneaker", color: "#2b8f6b" },
  "prod-cds-centauro-2": { kind: "ball", color: "#f2f2f2" },
  "prod-cds-outback-1": { kind: "plate", color: "#a5522d" },
  "prod-cds-outback-2": { kind: "dessert", color: "#5a3420" },
  "prod-cds-cinemark-1": { kind: "ticket", color: "#292d49" },
  "prod-cds-cinemark-2": { kind: "popcorn", color: "#d62a1f" },
  "prod-cds-leitura-1": { kind: "book", color: "#0f6b5c" },
  "prod-cds-leitura-2": { kind: "book", color: "#c0392b" },
  "prod-cds-mcdonalds-1": { kind: "burger", color: "#d9942b" },
  "prod-cds-mcdonalds-2": { kind: "icecream", color: "#f0a3b8" },
  "prod-cds-giraffas-1": { kind: "plate", color: "#d9a441" },
  "prod-cds-giraffas-2": { kind: "juice", color: "#f08a24" },
  "prod-cds-subway-1": { kind: "sub", color: "#176a42" },
  "prod-cds-subway-2": { kind: "sub", color: "#c9a227" },
};

export function artFor(productId: string): ProductArt {
  return productArt[productId] ?? { kind: "bag", color: "#8a7a52" };
}
