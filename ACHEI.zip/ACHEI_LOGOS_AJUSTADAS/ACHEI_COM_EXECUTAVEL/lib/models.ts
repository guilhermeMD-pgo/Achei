export type UserRole = "consumer" | "merchant" | "admin";
export type ProductAvailability =
  | "available"
  | "unconfirmed"
  | "unavailable";
export type FavoriteTarget = "store" | "product" | "promotion";

export type User = {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  createdAt: string;
};

export type Store = {
  id: string;
  name: string;
  category: string;
  description: string;
  floor: string;
  unit: string;
  phone: string | null;
  mapNodeId: string | null;
  ownerUserId: string | null;
  active: boolean;
  isDemo: boolean;
};

export type Product = {
  id: string;
  storeId: string;
  name: string;
  description: string;
  category: string;
  price: number | null;
  availability: ProductAvailability;
  active: boolean;
  isDemo: boolean;
};

export type Promotion = {
  id: string;
  storeId: string;
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPrice: number | null;
  startsAt: string;
  endsAt: string;
  active: boolean;
  isDemo: boolean;
};

export type MapNode = {
  id: string;
  name: string;
  floor: string;
  nodeType: string;
  x: number;
  y: number;
  accessible: boolean;
  isDemo: boolean;
};

export type MapEdge = {
  fromNodeId: string;
  toNodeId: string;
  distance: number;
  accessible: boolean;
};

export type Favorite = {
  userId: string;
  targetType: FavoriteTarget;
  targetId: string;
  createdAt: string;
};

export type SearchHistory = {
  id: string;
  userId: string;
  query: string;
  createdAt: string;
};

export type UserSettings = {
  userId: string;
  preferences: Record<string, unknown>;
};

export type Service = {
  id: string;
  name: string;
  description: string;
  floor: string;
  mapNodeId: string | null;
  active: boolean;
  isDemo: boolean;
};
