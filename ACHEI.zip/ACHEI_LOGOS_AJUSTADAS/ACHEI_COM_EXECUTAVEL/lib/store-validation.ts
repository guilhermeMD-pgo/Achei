type StoreUpdate = Partial<{
  name: string;
  category: string;
  description: string;
  floor: string;
  unit: string;
  phone: string | null;
}>;

type Validation =
  | { valid: true; value: StoreUpdate }
  | { valid: false; message: string };

const fieldLimits: Record<keyof StoreUpdate, number> = {
  name: 120,
  category: 80,
  description: 1000,
  floor: 80,
  unit: 80,
  phone: 40,
};

export function validateStoreUpdate(input: unknown): Validation {
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    return { valid: false, message: "O corpo deve ser um objeto JSON." };
  }

  const data: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input)) {
    data[key] = value;
  }
  const value: StoreUpdate = {};
  const fields: (keyof StoreUpdate)[] = [
    "name",
    "category",
    "description",
    "floor",
    "unit",
    "phone",
  ];

  for (const field of fields) {
    if (!Object.prototype.hasOwnProperty.call(data, field)) continue;
    const raw = data[field];
    if (field === "phone" && (raw === null || raw === "")) {
      value.phone = null;
      continue;
    }
    if (typeof raw !== "string") {
      return { valid: false, message: `${field} deve ser um texto válido.` };
    }
    const trimmed = raw.trim();
    if (trimmed.length === 0 || trimmed.length > fieldLimits[field]) {
      return {
        valid: false,
        message: `${field} deve ter entre 1 e ${fieldLimits[field]} caracteres.`,
      };
    }
    value[field] = trimmed;
  }

  if (Object.keys(value).length === 0) {
    return { valid: false, message: "Informe ao menos um campo para atualizar." };
  }
  return { valid: true, value };
}
