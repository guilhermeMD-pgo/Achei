export type RegistrationInput = { name: string; email: string; password: string };
export type ProfileInput = { name: string; email: string };

type Validation<T> = { valid: true; value: T } | { valid: false; message: string };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const email = value.trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}

export function validateRegistration(input: unknown): Validation<RegistrationInput> {
  if (!isRecord(input)) return { valid: false, message: "Informe os dados da conta." };
  const name = typeof input.name === "string" ? input.name.trim() : "";
  const email = normalizeEmail(input.email);
  if (name.length < 2 || name.length > 100) {
    return { valid: false, message: "O nome deve ter entre 2 e 100 caracteres." };
  }
  if (!email) return { valid: false, message: "Informe um e-mail válido." };
  if (typeof input.password !== "string" || input.password.length < 8 || input.password.length > 128) {
    return { valid: false, message: "A senha deve ter entre 8 e 128 caracteres." };
  }
  return { valid: true, value: { name, email, password: input.password } };
}

export function validateProfile(input: unknown): Validation<ProfileInput> {
  if (!isRecord(input)) return { valid: false, message: "Informe os dados do perfil." };
  const name = typeof input.name === "string" ? input.name.trim() : "";
  const email = normalizeEmail(input.email);
  if (name.length < 2 || name.length > 100) {
    return { valid: false, message: "O nome deve ter entre 2 e 100 caracteres." };
  }
  if (!email) return { valid: false, message: "Informe um e-mail válido." };
  return { valid: true, value: { name, email } };
}
