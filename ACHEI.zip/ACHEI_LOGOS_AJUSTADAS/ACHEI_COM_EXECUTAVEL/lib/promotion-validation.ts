import type { ProductAvailability } from "@/lib/models";

type Validation<T> =
  | { valid: true; value: T }
  | { valid: false; message: string };

export type ProductInput = {
  name: string;
  description: string;
  category: string;
  priceCents: number | null;
  availability: ProductAvailability;
};

export type PromotionInput = {
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPriceCents: number | null;
  startsAt: string;
  endsAt: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function requiredText(value: unknown, label: string, maximumLength = 200) {
  if (typeof value !== "string" || value.trim().length === 0) {
    return { valid: false as const, message: `${label} é obrigatório.` };
  }
  if (value.trim().length > maximumLength) {
    return {
      valid: false as const,
      message: `${label} deve ter no máximo ${maximumLength} caracteres.`,
    };
  }
  return { valid: true as const, value: value.trim() };
}

function optionalMoney(value: unknown, label: string) {
  if (value === undefined || value === null || value === "") {
    return { valid: true as const, value: null };
  }
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
    return {
      valid: false as const,
      message: `${label} deve ser um valor numérico igual ou maior que zero.`,
    };
  }
  const cents = Math.round(value * 100);
  if (Math.abs(value * 100 - cents) > 1e-8 || cents > Number.MAX_SAFE_INTEGER) {
    return { valid: false as const, message: `${label} deve ter no máximo duas casas decimais.` };
  }
  return { valid: true as const, value: cents };
}

function validDate(value: unknown, label: string) {
  if (typeof value !== "string" || value.length > 40) {
    return { valid: false as const, message: `${label} deve ser uma data válida.` };
  }
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) {
    return { valid: false as const, message: `${label} deve ser uma data válida.` };
  }
  return { valid: true as const, value: new Date(timestamp).toISOString() };
}

export function validateProductInput(input: unknown): Validation<ProductInput> {
  if (!isRecord(input)) {
    return { valid: false, message: "O corpo deve ser um objeto JSON." };
  }

  const name = requiredText(input.name, "Nome do produto", 120);
  const category = requiredText(input.category, "Categoria", 80);
  if (!name.valid) return name;
  if (!category.valid) return category;

  const description =
    input.description === undefined ? "" : input.description;
  if (typeof description !== "string" || description.trim().length > 1000) {
    return {
      valid: false,
      message: "A descrição deve ter no máximo 1000 caracteres.",
    };
  }

  const price = optionalMoney(input.price, "Preço");
  if (!price.valid) return price;
  const availability = input.availability ?? "unconfirmed";
  if (
    availability !== "available" &&
    availability !== "unconfirmed" &&
    availability !== "unavailable"
  ) {
    return { valid: false, message: "Disponibilidade inválida." };
  }

  return {
    valid: true,
    value: {
      name: name.value,
      category: category.value,
      description: description.trim(),
      priceCents: price.value,
      availability,
    },
  };
}

export function validatePromotionInput(
  input: unknown,
): Validation<PromotionInput> {
  if (!isRecord(input)) {
    return { valid: false, message: "O corpo deve ser um objeto JSON." };
  }

  const title = requiredText(input.title, "Título", 120);
  const description = requiredText(input.description, "Descrição", 2000);
  const startsAt = validDate(input.startsAt, "Data inicial");
  const endsAt = validDate(input.endsAt, "Data final");
  if (!title.valid) return title;
  if (!description.valid) return description;
  if (!startsAt.valid) return startsAt;
  if (!endsAt.valid) return endsAt;
  if (Date.parse(endsAt.value) <= Date.parse(startsAt.value)) {
    return {
      valid: false,
      message: "A data final deve ser posterior à data inicial.",
    };
  }

  const discountPercent =
    input.discountPercent === undefined || input.discountPercent === null || input.discountPercent === ""
      ? null
      : input.discountPercent;
  if (
    discountPercent !== null &&
    (typeof discountPercent !== "number" ||
      !Number.isFinite(discountPercent) ||
      discountPercent <= 0 ||
      discountPercent > 100)
  ) {
    return {
      valid: false,
      message: "O desconto deve ser maior que zero e menor ou igual a 100%.",
    };
  }

  const promotionalPrice = optionalMoney(
    input.promotionalPrice,
    "Preço promocional",
  );
  if (!promotionalPrice.valid) return promotionalPrice;
  if (discountPercent === null && promotionalPrice.value === null) {
    return {
      valid: false,
      message: "Informe um desconto ou um preço promocional.",
    };
  }

  let productId: string | null = null;
  if (input.productId !== undefined && input.productId !== null && input.productId !== "") {
    const parsedProductId = requiredText(input.productId, "Produto", 100);
    if (!parsedProductId.valid) return parsedProductId;
    productId = parsedProductId.value;
  }

  return {
    valid: true,
    value: {
      title: title.value,
      description: description.value,
      startsAt: startsAt.value,
      endsAt: endsAt.value,
      discountPercent,
      promotionalPriceCents: promotionalPrice.value,
      productId,
    },
  };
}

export function readJsonObject(value: unknown) {
  return isRecord(value) ? value : null;
}
