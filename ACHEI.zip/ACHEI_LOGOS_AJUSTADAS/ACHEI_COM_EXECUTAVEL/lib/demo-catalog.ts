import type Database from "better-sqlite3";
import { removedMallStoreIds } from "./mall-map-data";

/**
 * Catálogo demonstrativo: 2 produtos e 2 promoções por loja que permaneceu no mapa.
 * Nomes são exemplos genéricos; preços não são informados (consulte a loja).
 */
export type DemoProduct = { name: string; category: string; description: string; discount: number };

export const demoCatalog: Record<string, [DemoProduct, DemoProduct]> = {
  "cds-renner": [
    { name: "Camiseta básica de algodão", category: "Vestuário", description: "Camiseta unissex de algodão em cores lisas.", discount: 20 },
    { name: "Jaqueta jeans", category: "Vestuário", description: "Jaqueta jeans clássica, modelagem reta.", discount: 15 },
  ],
  "cds-ca": [
    { name: "Vestido midi estampado", category: "Vestuário", description: "Vestido leve com estampa floral para o dia a dia.", discount: 25 },
    { name: "Camisa social slim", category: "Vestuário", description: "Camisa social de algodão com acabamento sem amassar.", discount: 15 },
  ],
  "cds-riachuelo": [
    { name: "Tênis casual", category: "Calçados", description: "Tênis casual confortável para uso diário.", discount: 20 },
    { name: "Bolsa transversal", category: "Acessórios", description: "Bolsa transversal com alça ajustável.", discount: 10 },
  ],
  "cds-centauro": [
    { name: "Tênis de corrida", category: "Esportes", description: "Tênis com amortecimento para corrida e caminhada.", discount: 20 },
    { name: "Bola de futebol", category: "Esportes", description: "Bola de futebol de campo tamanho oficial.", discount: 10 },
  ],
  "cds-outback": [
    { name: "Prato de costela ao molho barbecue", category: "Alimentação", description: "Costela suculenta com acompanhamentos da casa.", discount: 10 },
    { name: "Sobremesa de chocolate para dividir", category: "Alimentação", description: "Sobremesa quente de chocolate com sorvete.", discount: 15 },
  ],
  "cds-cinemark": [
    { name: "Ingresso de cinema 2D", category: "Lazer", description: "Ingresso para sessões 2D em dias selecionados.", discount: 30 },
    { name: "Combo pipoca grande e refrigerante", category: "Lazer", description: "Pipoca grande com refrigerante para curtir o filme.", discount: 20 },
  ],
  "cds-leitura": [
    { name: "Livro de ficção best-seller", category: "Livraria", description: "Seleção de romances e ficção em destaque.", discount: 15 },
    { name: "Mangá — volume inicial", category: "Livraria", description: "Primeiros volumes de séries populares de mangá.", discount: 10 },
  ],
  "cds-mcdonalds": [
    { name: "Combo hambúrguer duplo", category: "Alimentação", description: "Sanduíche duplo com batata e bebida.", discount: 15 },
    { name: "Sobremesa gelada", category: "Alimentação", description: "Sobremesa gelada cremosa com calda.", discount: 10 },
  ],
  "cds-giraffas": [
    { name: "Prato executivo de frango grelhado", category: "Alimentação", description: "Frango grelhado com arroz, feijão e batata.", discount: 15 },
    { name: "Suco natural 500 ml", category: "Alimentação", description: "Suco natural de frutas da estação.", discount: 10 },
  ],
  "cds-subway": [
    { name: "Sanduíche de 30 cm", category: "Alimentação", description: "Sanduíche de 30 cm com pão e recheios à escolha.", discount: 20 },
    { name: "Combo sanduíche de 15 cm e bebida", category: "Alimentação", description: "Sanduíche de 15 cm com bebida e cookie.", discount: 10 },
  ],
};

export function demoProductId(storeId: string, index: number) {
  return `prod-${storeId}-${index + 1}`;
}
export function demoPromotionId(storeId: string, index: number) {
  return `promo-${storeId}-${index + 1}`;
}

/** Remove da vitrine pública o que não faz mais parte do catálogo (sem apagar histórico). */
export function retireOldCatalog(database: Database.Database) {
  const retiredStores = removedMallStoreIds;
  const marks = retiredStores.map(() => "?").join(",");
  database.prepare(`UPDATE stores SET active = 0 WHERE id IN (${marks})`).run(...retiredStores);
  database.prepare(`UPDATE promotions SET active = 0 WHERE store_id IN (${marks})`).run(...retiredStores);
  database.prepare(`UPDATE products SET active = 0 WHERE store_id IN (${marks})`).run(...retiredStores);
  // Campanhas e produtos antigos, sem vínculo com produto, substituídos pelo catálogo atual.
  database.prepare("UPDATE promotions SET active = 0 WHERE id LIKE 'prototype-%'").run();
  database.prepare("UPDATE products SET active = 0 WHERE id LIKE 'sample-%'").run();
  // A promoção pública da loja fictícia de demonstração sai da lista; a loja fica para o painel do lojista.
  database.prepare("UPDATE promotions SET active = 0 WHERE id = 'demo-promotion-shirt'").run();
}

export function seedDemoCatalog(database: Database.Database, startsAt: string, endsAt: string) {
  const upsertProduct = database.prepare(
    `INSERT INTO products
       (id, store_id, name, description, category, price_cents, availability, active, is_demo)
     VALUES (?, ?, ?, ?, ?, NULL, 'unconfirmed', 1, 1)
     ON CONFLICT(id) DO UPDATE SET name = excluded.name, description = excluded.description,
       category = excluded.category, active = 1`,
  );
  const upsertPromotion = database.prepare(
    `INSERT INTO promotions
       (id, store_id, product_id, title, description, discount_percent,
        promotional_price_cents, starts_at, ends_at, active, is_demo)
     VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, 1, 1)
     ON CONFLICT(id) DO UPDATE SET product_id = excluded.product_id, title = excluded.title,
       description = excluded.description, discount_percent = excluded.discount_percent,
       ends_at = excluded.ends_at, active = 1`,
  );
  for (const [storeId, products] of Object.entries(demoCatalog)) {
    products.forEach((product, index) => {
      const productId = demoProductId(storeId, index);
      upsertProduct.run(productId, storeId, product.name, `${product.description} Item ilustrativo; confirme preço e disponibilidade na loja.`, product.category);
      upsertPromotion.run(
        demoPromotionId(storeId, index),
        storeId,
        productId,
        `${product.discount}% de desconto em ${product.name}`,
        "Oferta demonstrativa. Confirme condições, preço e disponibilidade com a loja.",
        product.discount,
        startsAt,
        endsAt,
      );
    });
  }
}
