import "server-only";

import { errorResponse } from "@/lib/api-response";
import { getAuthenticatedUser } from "@/lib/auth";
import { database } from "@/lib/db";
import { findManagedStoreInDatabase } from "@/lib/managed-store";
import type { Store } from "@/lib/models";

export async function requireMerchant() {
  const user = await getAuthenticatedUser();
  if (!user) {
    return {
      response: errorResponse("unauthorized", "Entre na sua conta para continuar.", 401),
    } as const;
  }

  if (user.role !== "merchant" && user.role !== "admin") {
    return {
      response: errorResponse("forbidden", "Esta operação é exclusiva para lojistas.", 403),
    } as const;
  }

  return { user } as const;
}

export function findManagedStore(
  user: { id: string; role: "consumer" | "merchant" | "admin" },
  requestedStoreId?: string | null,
): Store | Response {
  return findManagedStoreInDatabase(database, user, requestedStoreId);
}
