import { errorResponse } from "@/lib/api-response";
import type { Store, UserRole } from "@/lib/models";
import type Database from "better-sqlite3";

type StoreUser = {
  id: string;
  role: UserRole;
};

export function findManagedStoreInDatabase(
  database: Database.Database,
  user: StoreUser,
  requestedStoreId?: string | null,
): Store | Response {
  let store: Store | undefined;

  if (user.role === "admin" && requestedStoreId) {
    store = database
      .prepare<[string], Store>(
        `SELECT id, name, category, description, floor, unit, phone,
                map_node_id AS mapNodeId, owner_user_id AS ownerUserId,
                active, is_demo AS isDemo
         FROM stores WHERE id = ?`,
      )
      .get(requestedStoreId);
  } else {
    const stores = database
      .prepare<[string], Store>(
        `SELECT id, name, category, description, floor, unit, phone,
                map_node_id AS mapNodeId, owner_user_id AS ownerUserId,
                active, is_demo AS isDemo
         FROM stores WHERE owner_user_id = ? ORDER BY id LIMIT 2`,
      )
      .all(user.id);

    if (stores.length > 1) {
      return errorResponse(
        "ambiguous_store",
        "A conta está associada a mais de uma loja; solicite a revisão do vínculo.",
        409,
      );
    }
    store = stores[0];
  }

  if (!store) {
    return errorResponse("store_not_found", "Não há uma loja associada a esta conta.", 404);
  }

  return {
    ...store,
    active: Boolean(store.active),
    isDemo: Boolean(store.isDemo),
  };
}
