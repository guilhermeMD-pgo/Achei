CREATE TABLE users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('consumer', 'merchant', 'admin')),
  created_at TEXT NOT NULL
);

CREATE TABLE stores (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  floor TEXT NOT NULL,
  unit TEXT NOT NULL,
  phone TEXT,
  map_node_id TEXT UNIQUE REFERENCES map_nodes(id),
  owner_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1))
);

CREATE TABLE products (
  id TEXT PRIMARY KEY,
  store_id TEXT NOT NULL REFERENCES stores(id),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  price_cents INTEGER CHECK (price_cents IS NULL OR price_cents >= 0),
  availability TEXT NOT NULL CHECK (
    availability IN ('available', 'unconfirmed', 'unavailable')
  ),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1))
);

CREATE TABLE promotions (
  id TEXT PRIMARY KEY,
  store_id TEXT NOT NULL REFERENCES stores(id),
  product_id TEXT REFERENCES products(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  discount_percent REAL CHECK (
    discount_percent IS NULL OR (discount_percent > 0 AND discount_percent <= 100)
  ),
  promotional_price_cents INTEGER CHECK (
    promotional_price_cents IS NULL OR promotional_price_cents >= 0
  ),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
  CHECK (ends_at > starts_at),
  CHECK (
    discount_percent IS NOT NULL OR promotional_price_cents IS NOT NULL
  )
);

CREATE TABLE map_nodes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  floor TEXT NOT NULL,
  node_type TEXT NOT NULL,
  x REAL NOT NULL,
  y REAL NOT NULL,
  accessible INTEGER NOT NULL DEFAULT 0 CHECK (accessible IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1))
);

CREATE TABLE map_edges (
  from_node_id TEXT NOT NULL REFERENCES map_nodes(id),
  to_node_id TEXT NOT NULL REFERENCES map_nodes(id),
  distance REAL NOT NULL CHECK (distance > 0),
  accessible INTEGER NOT NULL DEFAULT 0 CHECK (accessible IN (0, 1)),
  PRIMARY KEY (from_node_id, to_node_id)
);

CREATE TABLE services (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  floor TEXT NOT NULL,
  map_node_id TEXT REFERENCES map_nodes(id),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1))
);

CREATE TABLE favorites (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (
    target_type IN ('store', 'product', 'promotion')
  ),
  target_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, target_type, target_id)
);

CREATE TABLE search_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE user_settings (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  preferences_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX stores_active_category_idx ON stores(active, category);
CREATE INDEX products_store_active_idx ON products(store_id, active);
CREATE INDEX products_category_idx ON products(category);
CREATE INDEX promotions_active_dates_idx ON promotions(active, starts_at, ends_at);
CREATE INDEX services_active_idx ON services(active);
CREATE INDEX search_history_user_created_idx ON search_history(user_id, created_at);
