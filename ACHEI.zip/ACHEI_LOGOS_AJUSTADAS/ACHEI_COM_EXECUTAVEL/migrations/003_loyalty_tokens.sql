CREATE TABLE IF NOT EXISTS token_wallets (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
 lifetime_earned INTEGER NOT NULL DEFAULT 0 CHECK(lifetime_earned >= 0),
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS token_transactions (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 promotion_id TEXT, amount INTEGER NOT NULL CHECK(amount > 0),
 reason TEXT NOT NULL, created_at TEXT NOT NULL,
 UNIQUE(user_id,promotion_id)
);
CREATE INDEX IF NOT EXISTS token_transactions_user_created_idx ON token_transactions(user_id,created_at);
