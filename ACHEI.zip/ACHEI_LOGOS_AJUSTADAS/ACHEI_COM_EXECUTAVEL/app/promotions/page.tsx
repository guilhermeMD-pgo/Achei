import type { Metadata } from "next";
import Link from "next/link";
import { StatusPanel } from "@/components/status-panel";
import { StoreLogo } from "@/components/store-logo";
import { ProductImage } from "@/components/product-image";
import { listActivePromotions } from "@/lib/promotions";

export const metadata: Metadata = { title: "Promoções" };
export const dynamic = "force-dynamic";

export default function PromotionsPage() {
  const promotions = listActivePromotions();

  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">OFERTAS</p>
        <h1>Promoções</h1>
        <p className="page-description">
          Ofertas cadastradas pelas lojas participantes, com período e condições.
        </p>
      </div>
      {promotions.length === 0 ? (
        <StatusPanel title="Nenhuma promoção vigente">
          Volte mais tarde para consultar novas ofertas.
        </StatusPanel>
      ) : (
        <div className="promotion-grid">
          {promotions.map((promotion) => (
            <article className="promotion-card" key={promotion.id}>
              <div className="promotion-store-row">
                <StoreLogo storeId={promotion.storeId} name={promotion.storeName} size="md" />
                <span>{promotion.storeName}</span>
              </div>
              <p className="eyebrow">
                {promotion.discountPercent !== null
                  ? `${promotion.discountPercent}% de desconto`
                  : "Oferta especial"}
              </p>
              <h2>
                <Link href={`/promotions/${encodeURIComponent(promotion.id)}`}>
                  {promotion.title}
                </Link>
              </h2>
              {promotion.productName && promotion.productId && (
                <div className="promo-product-row">
                  <ProductImage name={promotion.productName} productId={promotion.productId} size="md" />
                  <p className="promotion-product">Produto: <strong>{promotion.productName}</strong></p>
                </div>
              )}
              <p>{promotion.description}</p>
              <p className="promotion-meta">
                {promotion.storeName} · {promotion.floor}, {promotion.unit}
              </p>
              <Link
                className="text-link"
                href={`/promotions/${encodeURIComponent(promotion.id)}`}
              >
                Ver condições e período
              </Link>
            </article>
          ))}
        </div>
      )}
      <p className="demo-notice">
        Consulte diretamente cada estabelecimento para confirmar as condições e a disponibilidade das campanhas.
      </p>
    </>
  );
}

