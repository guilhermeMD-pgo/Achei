import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { findActivePromotion } from "@/lib/promotions";
import { ClaimPromotion } from "@/components/claim-promotion";
import { StoreLogo } from "@/components/store-logo";
import { ProductImage } from "@/components/product-image";

type PromotionDetailPageProps = {
  params: Promise<{ id: string }>;
};

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: PromotionDetailPageProps): Promise<Metadata> {
  const { id } = await params;
  const promotion = findActivePromotion(id);
  return { title: promotion?.title ?? "Promoção" };
}

export default async function PromotionDetailPage({
  params,
}: PromotionDetailPageProps) {
  const { id } = await params;
  const promotion = findActivePromotion(id);
  if (!promotion) notFound();

  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">PROMOÇÃO</p>
        <h1>{promotion.title}</h1>
        <p className="page-description promotion-store-row">
          <StoreLogo storeId={promotion.storeId} name={promotion.storeName} size="md" />
          <span>{promotion.storeName} · {promotion.floor}, {promotion.unit}</span>
        </p>
      </div>
      <article className="promotion-detail">
        <p>{promotion.description}</p>
        {promotion.productName && promotion.productId && (
          <div className="promo-product-row">
            <ProductImage name={promotion.productName} productId={promotion.productId} size="lg" />
            <p>
              <strong>Produto:</strong> {promotion.productName}
            </p>
          </div>
        )}
        {promotion.discountPercent !== null && (
          <p>
            <strong>Desconto informado:</strong> {promotion.discountPercent}%
          </p>
        )}
        <p>
          <strong>Vigência:</strong> {formatDate(promotion.startsAt)} até{" "}
          {formatDate(promotion.endsAt)}
        </p>
      </article>
      {promotion.isDemo && <ClaimPromotion promotionId={promotion.id} />}
    </>
  );
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}
