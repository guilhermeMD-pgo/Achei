import { StatusPanel } from "@/components/status-panel";

export default function Loading() {
  return (
    <StatusPanel title="Carregando" variant="loading">
      Aguarde enquanto o conteúdo é preparado.
    </StatusPanel>
  );
}
