import type { Metadata } from "next";
import { MerchantDashboard, MerchantLogin } from "@/components/merchant-dashboard";
import { getAuthenticatedUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Gestão da loja" };

export default async function MerchantPage() {
  const user = await getAuthenticatedUser();
  if (!user) return <MerchantLogin />;
  if (user.role !== "merchant" && user.role !== "admin") {
    return (
      <section className="status-panel status-error">
        <h1>Acesso restrito</h1>
        <p>Esta área é exclusiva para contas de lojista autorizadas.</p>
      </section>
    );
  }

  return <MerchantDashboard name={user.name} />;
}
