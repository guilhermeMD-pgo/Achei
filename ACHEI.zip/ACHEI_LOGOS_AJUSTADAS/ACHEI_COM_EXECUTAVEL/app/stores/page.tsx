import type { Metadata } from "next";
import { database } from "@/lib/db";
import { StoreCatalog } from "@/components/store-catalog";
export const metadata: Metadata = { title: "Lojas" };
export const dynamic = "force-dynamic";
export default function StoresPage() {
 const stores = database.prepare<[],{id:string;name:string;category:string;description:string;floor:string;unit:string;promotionCount:number}>(`SELECT s.id,s.name,s.category,s.description,s.floor,s.unit,COUNT(p.id) AS promotionCount FROM stores s LEFT JOIN promotions p ON p.store_id=s.id AND p.active=1 AND p.starts_at<=? AND p.ends_at>? WHERE s.active=1 AND s.is_demo=0 GROUP BY s.id ORDER BY s.name`).all(new Date().toISOString(),new Date().toISOString());
 return <><div className="page-heading"><p className="eyebrow">ESTABELECIMENTOS</p><h1>Lojas</h1><p className="page-description">Encontre lojas, consulte ofertas e abra a localização no mapa.</p></div><StoreCatalog stores={stores}/></>;
}
