import type { Metadata } from "next";
import { MallMap } from "@/components/mall-map";

export const metadata: Metadata = { title: "Mapa do Capim Dourado Shopping" };
export const dynamic = "force-dynamic";

export default function MapPage() {
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">ORIENTAÇÃO</p>
        <h1>Mapa do shopping</h1>
        <p className="page-description">
          Explore os pavimentos, selecione uma loja e consulte os produtos que ela cadastrou no Achei.
        </p>
      </div>
      <MallMap />
    </>
  );
}
