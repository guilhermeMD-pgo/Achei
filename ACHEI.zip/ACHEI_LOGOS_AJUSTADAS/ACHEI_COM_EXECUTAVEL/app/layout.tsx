import type { Metadata } from "next";
import { SiteNavigation } from "@/components/site-navigation";
import { ThemeToggle } from "@/components/theme-toggle";
import { SessionChip } from "@/components/session-chip";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Achei | Guia do Shopping",
    template: "%s | Achei",
  },
  description:
    "A base digital do Achei, guia de lojas, produtos, promoções e serviços do shopping.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: `try{var t=localStorage.getItem("achei-theme");if(t==="light"||t==="dark")document.documentElement.dataset.theme=t}catch(e){}` }} />
      </head>
      <body>
        <SiteNavigation />
        <div className="main-column">
          <header className="topbar">
            <p className="topbar-label">
              <span className="status-dot" aria-hidden="true" />
              GUIA DE COMPRAS DO SHOPPING
            </p>
            <div className="topbar-actions"><ThemeToggle /><SessionChip /></div>
          </header>
          <main className="main-content">{children}</main>
          <footer className="site-footer">
            ACHEI · PROJETO EM DESENVOLVIMENTO
          </footer>
        </div>
      </body>
    </html>
  );
}
