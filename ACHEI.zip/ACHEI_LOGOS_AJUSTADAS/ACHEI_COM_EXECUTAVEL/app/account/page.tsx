import type { Metadata } from "next";
import { AccountPanel } from "@/components/account-panel";

export const metadata: Metadata = { title: "Minha conta" };

export default function AccountPage() {
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">ÁREA PESSOAL</p>
        <h1>Minha conta</h1>
        <p className="page-description">Acesse ou crie sua conta para gerenciar seus dados pessoais no Achei.</p>
      </div>
      <AccountPanel />
    </>
  );
}
