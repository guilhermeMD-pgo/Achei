import type { Metadata } from "next";
import { SettingsPanel } from "@/components/settings-panel";
export const metadata:Metadata={title:"Configurações"};
export default function SettingsPage(){return <><section className="page-heading"><p className="eyebrow">PREFERÊNCIAS</p><h1>Configurações</h1><p className="page-description">Personalize sua experiência, notificações e visualização do Achei.</p></section><SettingsPanel/></>}
