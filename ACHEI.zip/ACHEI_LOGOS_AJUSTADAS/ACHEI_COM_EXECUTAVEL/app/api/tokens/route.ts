import { getAuthenticatedUser } from "@/lib/auth";
import { database } from "@/lib/db";
import { errorResponse } from "@/lib/api-response";
import { readRequestJson } from "@/lib/request-json";
import { randomUUID } from "node:crypto";

export async function GET() {
 const user=await getAuthenticatedUser(); if(!user) return errorResponse("unauthorized","Entre na sua conta para consultar seus Achei Tokens.",401);
 const wallet=database.prepare("SELECT balance,lifetime_earned FROM token_wallets WHERE user_id=?").get(user.id) as {balance:number;lifetime_earned:number}|undefined;
 const history=database.prepare("SELECT amount,reason,created_at FROM token_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 20").all(user.id);
 return Response.json({balance:wallet?.balance??0,lifetimeEarned:wallet?.lifetime_earned??0,history});
}
export async function POST(request:Request) {
 const user=await getAuthenticatedUser(); if(!user) return errorResponse("unauthorized","Entre na sua conta para ganhar tokens.",401);
 const parsed=await readRequestJson(request); if(!parsed.ok) return parsed.response;
 const body=parsed.value&&typeof parsed.value==="object"?parsed.value as Record<string,unknown>:{};
 const promotionId=typeof body.promotionId==="string"?body.promotionId:"";
 const promotion=database.prepare("SELECT id FROM promotions WHERE id=? AND active=1 AND is_demo=1 AND starts_at<=? AND ends_at>?").get(promotionId,new Date().toISOString(),new Date().toISOString()) as {id:string}|undefined;
 if(!promotion) return errorResponse("not_found","Campanha de demonstração indisponível.",404);
 const amount=10; const now=new Date().toISOString();
 try { database.transaction(()=>{database.prepare("INSERT INTO token_wallets(user_id,balance,lifetime_earned,updated_at) VALUES(?,0,0,?) ON CONFLICT(user_id) DO NOTHING").run(user.id,now); database.prepare("INSERT INTO token_transactions(id,user_id,promotion_id,amount,reason,created_at) VALUES(?,?,?,?,?,?)").run(randomUUID(),user.id,promotion.id,amount,"Recompensa por campanha demonstrativa",now); database.prepare("UPDATE token_wallets SET balance=balance+?,lifetime_earned=lifetime_earned+?,updated_at=? WHERE user_id=?").run(amount,amount,now,user.id);})(); } catch { return errorResponse("already_claimed","Você já recebeu tokens por esta campanha.",409); }
 const wallet=database.prepare("SELECT balance FROM token_wallets WHERE user_id=?").get(user.id) as {balance:number}; return Response.json({earned:amount,balance:wallet.balance});
}
