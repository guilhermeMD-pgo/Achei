import { database } from "@/lib/db";
import { errorResponse, itemsResponse, likePattern, queryError, queryText } from "@/lib/api-response";
import type { Product } from "@/lib/models";

export function GET(request: Request) {
  try {
    const parameters = new URL(request.url).searchParams;
    const query = queryText(parameters.get("q"));
    const category = queryText(parameters.get("category"));
    const storeId = queryText(parameters.get("storeId"));
    const items = database
      .prepare<
        [string, string, string, string, string, string, string],
        Omit<Product, "active" | "isDemo"> & {
          isDemo: number;
          storeName: string;
          floor: string;
          unit: string;
        }
      >(
        `SELECT p.id, p.store_id AS storeId, p.name, p.description, p.category,
                p.price_cents / 100.0 AS price, p.availability, p.is_demo AS isDemo,
                s.name AS storeName, s.floor, s.unit
         FROM products p
         JOIN stores s ON s.id = p.store_id
         WHERE p.active = 1 AND s.active = 1
           AND (? = '' OR unicode_lower(p.name) LIKE unicode_lower(?) ESCAPE '\\'
                OR unicode_lower(p.description) LIKE unicode_lower(?) ESCAPE '\\')
           AND (? = '' OR unicode_lower(p.category) = unicode_lower(?))
           AND (? = '' OR p.store_id = ?)
         ORDER BY p.name
         LIMIT 100`,
      )
      .all(
        query,
        likePattern(query),
        likePattern(query),
        category,
        category,
        storeId,
        storeId,
      );

    return itemsResponse(
      items.map((item) => ({ ...item, isDemo: Boolean(item.isDemo) })),
    );
  } catch (error) {
    if (error instanceof Error && error.message === "query_too_long") {
      return errorResponse(
        "invalid_query",
        "Os filtros de texto devem ter no máximo 100 caracteres.",
        400,
      );
    }
    return queryError(error);
  }
}
