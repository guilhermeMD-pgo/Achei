import { getAuthenticatedUser } from "@/lib/auth";
import { database } from "@/lib/db";
import { errorResponse } from "@/lib/api-response";
import { readRequestJson } from "@/lib/request-json";
import { validateProfile } from "@/lib/account-validation";

export async function GET() {
  const user = await getAuthenticatedUser();
  if (!user) return errorResponse("unauthorized", "Entre na sua conta para continuar.", 401);
  const settings = database.prepare<[string], { preferencesJson: string }>(
    "SELECT preferences_json AS preferencesJson FROM user_settings WHERE user_id = ?",
  ).get(user.id);
  let preferences: Record<string, unknown> = {};
  if (settings) {
    try {
      const parsed: unknown = JSON.parse(settings.preferencesJson);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) preferences = parsed as Record<string, unknown>;
    } catch { /* Mantém preferências vazias se um registro antigo estiver inválido. */ }
  }
  return Response.json({ user, preferences });
}

export async function PATCH(request: Request) {
  const user = await getAuthenticatedUser();
  if (!user) return errorResponse("unauthorized", "Entre na sua conta para continuar.", 401);
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const validation = validateProfile(parsed.value);
  if (!validation.valid) return errorResponse("invalid_profile", validation.message, 400);

  const { name, email } = validation.value;
  const duplicate = database.prepare<[string, string], { id: string }>(
    "SELECT id FROM users WHERE email = ? COLLATE NOCASE AND id <> ?",
  ).get(email, user.id);
  if (duplicate) return errorResponse("email_in_use", "Este e-mail já está sendo usado por outra conta.", 409);

  database.prepare("UPDATE users SET name = ?, email = ? WHERE id = ?").run(name, email, user.id);
  return Response.json({ user: { ...user, name, email } });
}
