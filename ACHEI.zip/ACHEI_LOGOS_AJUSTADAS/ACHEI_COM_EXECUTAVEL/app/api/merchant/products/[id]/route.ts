import { errorResponse, queryError } from "@/lib/api-response";
import { database } from "@/lib/db";
import { findManagedStore, requireMerchant } from "@/lib/merchant-auth";
import { readJsonObject, validateProductInput } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";

type ExistingProduct = {
  name: string;
  description: string;
  category: string;
  priceCents: number | null;
  availability: string;
};

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const data = readJsonObject(parsed.value);
  if (!data) return errorResponse("invalid_product", "O corpo deve ser um objeto JSON.", 400);

  const store = findManagedStore(
    access.user,
    typeof data.storeId === "string" ? data.storeId : null,
  );
  if (store instanceof Response) return store;
  const { id } = await context.params;

  try {
    const current = database
      .prepare<[string, string], ExistingProduct>(
        `SELECT name, description, category, price_cents AS priceCents, availability
         FROM products WHERE id = ? AND store_id = ?`,
      )
      .get(id, store.id);
    if (!current) {
      return errorResponse("not_found", "O produto não foi encontrado nesta loja.", 404);
    }

    const merged = {
      name: data.name ?? current.name,
      description: data.description ?? current.description,
      category: data.category ?? current.category,
      price:
        Object.prototype.hasOwnProperty.call(data, "price")
          ? data.price
          : current.priceCents === null
            ? null
            : current.priceCents / 100,
      availability: data.availability ?? current.availability,
    };
    const validation = validateProductInput(merged);
    if (!validation.valid) {
      return errorResponse("invalid_product", validation.message, 400);
    }

    database
      .prepare(
        `UPDATE products
         SET name = ?, description = ?, category = ?, price_cents = ?, availability = ?
         WHERE id = ? AND store_id = ?`,
      )
      .run(
        validation.value.name,
        validation.value.description,
        validation.value.category,
        validation.value.priceCents,
        validation.value.availability,
        id,
        store.id,
      );
    return Response.json({ updated: true });
  } catch (error) {
    return queryError(error);
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const requestedStoreId = new URL(request.url).searchParams.get("storeId");
  const store = findManagedStore(access.user, requestedStoreId);
  if (store instanceof Response) return store;
  const { id } = await context.params;

  try {
    const result = database
      .prepare("UPDATE products SET active = 0 WHERE id = ? AND store_id = ?")
      .run(id, store.id);
    if (result.changes === 0) {
      return errorResponse("not_found", "O produto não foi encontrado nesta loja.", 404);
    }
    return Response.json({ deactivated: true });
  } catch (error) {
    return queryError(error);
  }
}
