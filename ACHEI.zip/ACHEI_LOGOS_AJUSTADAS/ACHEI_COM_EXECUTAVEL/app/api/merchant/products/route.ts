import { randomUUID } from "node:crypto";
import { errorResponse, itemsResponse, queryError } from "@/lib/api-response";
import { database } from "@/lib/db";
import { findManagedStore, requireMerchant } from "@/lib/merchant-auth";
import { readJsonObject, validateProductInput } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";

type ProductRow = {
  id: string;
  storeId: string;
  name: string;
  description: string;
  category: string;
  price: number | null;
  availability: string;
  active: number;
  isDemo: number;
};

export async function GET(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const requestedStoreId = new URL(request.url).searchParams.get("storeId");
  const store = findManagedStore(access.user, requestedStoreId);
  if (store instanceof Response) return store;

  try {
    const items = database
      .prepare<[string], ProductRow>(
        `SELECT id, store_id AS storeId, name, description, category,
                price_cents / 100.0 AS price, availability, active,
                is_demo AS isDemo
         FROM products WHERE store_id = ? ORDER BY name`,
      )
      .all(store.id)
      .map((item) => ({
        ...item,
        active: Boolean(item.active),
        isDemo: Boolean(item.isDemo),
      }));
    return itemsResponse(items);
  } catch (error) {
    return queryError(error);
  }
}

export async function POST(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const data = readJsonObject(parsed.value);
  if (!data) return errorResponse("invalid_product", "O corpo deve ser um objeto JSON.", 400);

  const requestedStoreId = typeof data.storeId === "string" ? data.storeId : null;
  const store = findManagedStore(access.user, requestedStoreId);
  if (store instanceof Response) return store;
  const validation = validateProductInput(parsed.value);
  if (!validation.valid) {
    return errorResponse("invalid_product", validation.message, 400);
  }

  const id = randomUUID();
  try {
    database
      .prepare(
        `INSERT INTO products
         (id, store_id, name, description, category, price_cents, availability, active, is_demo)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0)`,
      )
      .run(
        id,
        store.id,
        validation.value.name,
        validation.value.description,
        validation.value.category,
        validation.value.priceCents,
        validation.value.availability,
      );
    return Response.json({ id }, { status: 201 });
  } catch (error) {
    return queryError(error);
  }
}
