import { errorResponse } from "@/lib/api-response";
import { database } from "@/lib/db";
import { findManagedStore, requireMerchant } from "@/lib/merchant-auth";
import { readJsonObject } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";
import { validateStoreUpdate } from "@/lib/store-validation";

export async function GET(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;

  const storeId = new URL(request.url).searchParams.get("storeId");
  const store = findManagedStore(access.user, storeId);
  if (store instanceof Response) return store;
  const { ownerUserId: _ownerUserId, ...storeData } = store;
  return Response.json({ store: storeData });
}

export async function PATCH(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;

  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const data = readJsonObject(parsed.value);
  if (!data) return errorResponse("invalid_store", "O corpo deve ser um objeto JSON.", 400);
  const storeId = typeof data.storeId === "string" ? data.storeId : null;
  const store = findManagedStore(access.user, storeId);
  if (store instanceof Response) return store;

  const validation = validateStoreUpdate(parsed.value);
  if (!validation.valid) {
    return errorResponse("invalid_store", validation.message, 400);
  }

  const columns: Record<string, string> = {
    name: "name",
    category: "category",
    description: "description",
    floor: "floor",
    unit: "unit",
    phone: "phone",
  };
  const entries = Object.entries(validation.value);
  database
    .prepare(
      `UPDATE stores SET ${entries.map(([key]) => `${columns[key]} = ?`).join(", ")}
       WHERE id = ?`,
    )
    .run(...entries.map(([, value]) => value), store.id);

  const updated = findManagedStore(access.user, store.id);
  if (updated instanceof Response) return updated;
  const { ownerUserId: _ownerUserId, ...storeData } = updated;
  return Response.json({ store: storeData });
}
