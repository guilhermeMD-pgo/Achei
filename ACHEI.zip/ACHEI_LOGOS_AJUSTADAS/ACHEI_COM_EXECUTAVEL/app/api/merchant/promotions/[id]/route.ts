import { errorResponse, queryError } from "@/lib/api-response";
import { database } from "@/lib/db";
import { findManagedStore, requireMerchant } from "@/lib/merchant-auth";
import { readJsonObject, validatePromotionInput } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";

type ExistingPromotion = {
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPriceCents: number | null;
  startsAt: string;
  endsAt: string;
};

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const data = readJsonObject(parsed.value);
  if (!data) return errorResponse("invalid_promotion", "O corpo deve ser um objeto JSON.", 400);

  const store = findManagedStore(
    access.user,
    typeof data.storeId === "string" ? data.storeId : null,
  );
  if (store instanceof Response) return store;
  const { id } = await context.params;

  try {
    const current = database
      .prepare<[string, string], ExistingPromotion>(
        `SELECT product_id AS productId, title, description,
                discount_percent AS discountPercent,
                promotional_price_cents AS promotionalPriceCents,
                starts_at AS startsAt, ends_at AS endsAt
         FROM promotions WHERE id = ? AND store_id = ?`,
      )
      .get(id, store.id);
    if (!current) {
      return errorResponse("not_found", "A promoção não foi encontrada nesta loja.", 404);
    }

    const merged = {
      productId: Object.prototype.hasOwnProperty.call(data, "productId")
        ? data.productId
        : current.productId,
      title: data.title ?? current.title,
      description: data.description ?? current.description,
      discountPercent: Object.prototype.hasOwnProperty.call(data, "discountPercent")
        ? data.discountPercent
        : current.discountPercent,
      promotionalPrice:
        Object.prototype.hasOwnProperty.call(data, "promotionalPrice")
          ? data.promotionalPrice
          : current.promotionalPriceCents === null
            ? null
            : current.promotionalPriceCents / 100,
      startsAt: data.startsAt ?? current.startsAt,
      endsAt: data.endsAt ?? current.endsAt,
    };
    const validation = validatePromotionInput(merged);
    if (!validation.valid) {
      return errorResponse("invalid_promotion", validation.message, 400);
    }

    if (validation.value.productId) {
      const product = database
        .prepare<[string, string], { id: string }>(
          `SELECT id FROM products
           WHERE id = ? AND store_id = ? AND active = 1`,
        )
        .get(validation.value.productId, store.id);
      if (!product) {
        return errorResponse(
          "invalid_product",
          "Selecione um produto ativo desta loja.",
          400,
        );
      }
    }

    database
      .prepare(
        `UPDATE promotions
         SET product_id = ?, title = ?, description = ?, discount_percent = ?,
             promotional_price_cents = ?, starts_at = ?, ends_at = ?
         WHERE id = ? AND store_id = ?`,
      )
      .run(
        validation.value.productId,
        validation.value.title,
        validation.value.description,
        validation.value.discountPercent,
        validation.value.promotionalPriceCents,
        validation.value.startsAt,
        validation.value.endsAt,
        id,
        store.id,
      );
    return Response.json({ updated: true });
  } catch (error) {
    return queryError(error);
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const requestedStoreId = new URL(request.url).searchParams.get("storeId");
  const store = findManagedStore(access.user, requestedStoreId);
  if (store instanceof Response) return store;
  const { id } = await context.params;

  try {
    const result = database
      .prepare("UPDATE promotions SET active = 0 WHERE id = ? AND store_id = ?")
      .run(id, store.id);
    if (result.changes === 0) {
      return errorResponse("not_found", "A promoção não foi encontrada nesta loja.", 404);
    }
    return Response.json({ deactivated: true });
  } catch (error) {
    return queryError(error);
  }
}
