import { randomUUID } from "node:crypto";
import { errorResponse, itemsResponse, queryError } from "@/lib/api-response";
import { database } from "@/lib/db";
import { findManagedStore, requireMerchant } from "@/lib/merchant-auth";
import { readJsonObject, validatePromotionInput } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";

type PromotionRow = {
  id: string;
  storeId: string;
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPrice: number | null;
  startsAt: string;
  endsAt: string;
  active: number;
  isDemo: number;
};

export async function GET(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const requestedStoreId = new URL(request.url).searchParams.get("storeId");
  const store = findManagedStore(access.user, requestedStoreId);
  if (store instanceof Response) return store;

  try {
    const items = database
      .prepare<[string], PromotionRow>(
        `SELECT id, store_id AS storeId, product_id AS productId, title,
                description, discount_percent AS discountPercent,
                promotional_price_cents / 100.0 AS promotionalPrice,
                starts_at AS startsAt, ends_at AS endsAt, active,
                is_demo AS isDemo
         FROM promotions WHERE store_id = ? ORDER BY starts_at DESC`,
      )
      .all(store.id)
      .map((item) => ({
        ...item,
        active: Boolean(item.active),
        isDemo: Boolean(item.isDemo),
      }));
    return itemsResponse(items);
  } catch (error) {
    return queryError(error);
  }
}

export async function POST(request: Request) {
  const access = await requireMerchant();
  if ("response" in access) return access.response;
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const data = readJsonObject(parsed.value);
  if (!data) return errorResponse("invalid_promotion", "O corpo deve ser um objeto JSON.", 400);

  const store = findManagedStore(
    access.user,
    typeof data.storeId === "string" ? data.storeId : null,
  );
  if (store instanceof Response) return store;
  const validation = validatePromotionInput(data);
  if (!validation.valid) {
    return errorResponse("invalid_promotion", validation.message, 400);
  }

  if (validation.value.productId) {
    const product = database
      .prepare<[string, string], { id: string }>(
        `SELECT id FROM products
         WHERE id = ? AND store_id = ? AND active = 1`,
      )
      .get(validation.value.productId, store.id);
    if (!product) {
      return errorResponse(
        "invalid_product",
        "Selecione um produto ativo desta loja.",
        400,
      );
    }
  }

  const id = randomUUID();
  try {
    database
      .prepare(
        `INSERT INTO promotions
         (id, store_id, product_id, title, description, discount_percent,
          promotional_price_cents, starts_at, ends_at, active, is_demo)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)`,
      )
      .run(
        id,
        store.id,
        validation.value.productId,
        validation.value.title,
        validation.value.description,
        validation.value.discountPercent,
        validation.value.promotionalPriceCents,
        validation.value.startsAt,
        validation.value.endsAt,
      );
    return Response.json({ id }, { status: 201 });
  } catch (error) {
    return queryError(error);
  }
}
