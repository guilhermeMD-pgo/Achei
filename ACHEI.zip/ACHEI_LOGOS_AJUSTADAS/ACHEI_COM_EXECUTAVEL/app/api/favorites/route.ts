import { getAuthenticatedUser } from "@/lib/auth";
import { database } from "@/lib/db";
import { errorResponse, itemsResponse } from "@/lib/api-response";
import { readRequestJson } from "@/lib/request-json";

export async function GET() {
  const user = await getAuthenticatedUser();
  if (!user) return errorResponse("unauthorized", "Entre na sua conta para ver suas lojas favoritas.", 401);
  const items = database.prepare<[string], {id:string;name:string;category:string}>(`SELECT s.id,s.name,s.category FROM favorites f JOIN stores s ON f.target_id=s.id WHERE f.user_id=? AND f.target_type='store' AND s.active=1 ORDER BY f.created_at DESC`).all(user.id);
  return itemsResponse(items);
}
export async function POST(request: Request) {
  const user = await getAuthenticatedUser();
  if (!user) return errorResponse("unauthorized", "Entre na sua conta para favoritar lojas.", 401);
  const parsed = await readRequestJson(request); if (!parsed.ok) return parsed.response;
  const data = parsed.value && typeof parsed.value === "object" ? parsed.value as Record<string, unknown> : {};
  const id = typeof data.id === "string" ? data.id : "";
  const store = database.prepare<[string],{id:string}>("SELECT id FROM stores WHERE id=? AND active=1").get(id);
  if (!store) return errorResponse("not_found", "Loja não encontrada.", 404);
  database.prepare("INSERT OR IGNORE INTO favorites(user_id,target_type,target_id,created_at) VALUES(?,'store',?,?)").run(user.id,id,new Date().toISOString());
  return Response.json({ saved: true });
}
export async function DELETE(request: Request) {
  const user = await getAuthenticatedUser();
  if (!user) return errorResponse("unauthorized", "Entre na sua conta para alterar favoritos.", 401);
  const parsed = await readRequestJson(request); if (!parsed.ok) return parsed.response;
  const data = parsed.value && typeof parsed.value === "object" ? parsed.value as Record<string, unknown> : {};
  const id = typeof data.id === "string" ? data.id : "";
  database.prepare("DELETE FROM favorites WHERE user_id=? AND target_type='store' AND target_id=?").run(user.id,id);
  return Response.json({ saved: false });
}
