import { database } from "@/lib/db";
import { itemsResponse, queryError } from "@/lib/api-response";
import type { Service } from "@/lib/models";

export function GET() {
  try {
    const items = database
      .prepare<[], Omit<Service, "active" | "isDemo"> & { isDemo: number }>(
        `SELECT id, name, description, floor, map_node_id AS mapNodeId,
                is_demo AS isDemo
         FROM services
         WHERE active = 1
         ORDER BY name
         LIMIT 100`,
      )
      .all();

    return itemsResponse(
      items.map((item) => ({ ...item, isDemo: Boolean(item.isDemo) })),
    );
  } catch (error) {
    return queryError(error);
  }
}
