import { NextResponse } from "next/server";
import { createSession, SESSION_COOKIE } from "@/lib/auth";
import { database } from "@/lib/db";
import { errorResponse } from "@/lib/api-response";
import { verifyPassword } from "@/lib/password";
import { readJsonObject } from "@/lib/promotion-validation";
import { readRequestJson } from "@/lib/request-json";

export async function POST(request: Request) {
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const body = readJsonObject(parsed.value);
  if (!body) {
    return errorResponse("invalid_credentials", "E-mail ou senha inválidos.", 400);
  }
  if (
    typeof body.email !== "string" ||
    typeof body.password !== "string" ||
    body.email.length > 254 ||
    body.password.length > 1024
  ) {
    return errorResponse("invalid_credentials", "E-mail ou senha inválidos.", 400);
  }

  const user = database
    .prepare<[string], { id: string; passwordHash: string }>(
      `SELECT id, password_hash AS passwordHash
       FROM users WHERE email = ? COLLATE NOCASE`,
    )
    .get(body.email.trim());

  if (!user || !verifyPassword(body.password, user.passwordHash)) {
    return errorResponse("invalid_credentials", "E-mail ou senha inválidos.", 401);
  }

  const session = createSession(user.id);
  const response = NextResponse.json({ authenticated: true });
  response.cookies.set(SESSION_COOKIE, session.token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: new Date(session.expiresAt),
  });
  return response;
}
