import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { createSession, SESSION_COOKIE } from "@/lib/auth";
import { database } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { validateRegistration } from "@/lib/account-validation";
import { readRequestJson } from "@/lib/request-json";
import { errorResponse } from "@/lib/api-response";

export async function POST(request: Request) {
  const parsed = await readRequestJson(request);
  if (!parsed.ok) return parsed.response;
  const validation = validateRegistration(parsed.value);
  if (!validation.valid) return errorResponse("invalid_registration", validation.message, 400);

  const { name, email, password } = validation.value;
  const existing = database.prepare("SELECT 1 FROM users WHERE email = ? COLLATE NOCASE").get(email);
  if (existing) return errorResponse("email_in_use", "Este e-mail já está cadastrado.", 409);

  const userId = randomUUID();
  try {
    database.prepare(
      `INSERT INTO users (id, name, email, password_hash, role, created_at)
       VALUES (?, ?, ?, ?, 'consumer', ?)`,
    ).run(userId, name, email, hashPassword(password), new Date().toISOString());
  } catch {
    return errorResponse("registration_failed", "Não foi possível criar a conta. Tente novamente.", 500);
  }

  const session = createSession(userId);
  const response = NextResponse.json({ authenticated: true }, { status: 201 });
  response.cookies.set(SESSION_COOKIE, session.token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: new Date(session.expiresAt),
  });
  return response;
}
