import { itemsResponse, queryError } from "@/lib/api-response";
import { listActivePromotions } from "@/lib/promotions";

export function GET() {
  try {
    return itemsResponse(listActivePromotions());
  } catch (error) {
    return queryError(error);
  }
}
