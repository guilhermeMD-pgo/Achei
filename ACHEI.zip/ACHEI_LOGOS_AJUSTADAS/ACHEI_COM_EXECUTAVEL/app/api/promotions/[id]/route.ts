import { errorResponse, queryError } from "@/lib/api-response";
import { findActivePromotion } from "@/lib/promotions";

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await context.params;
    const promotion = findActivePromotion(id);
    if (!promotion) {
      return errorResponse("not_found", "A promoção vigente não foi encontrada.", 404);
    }

    return Response.json(promotion);
  } catch (error) {
    return queryError(error);
  }
}
