import { database } from "@/lib/db";
import { errorResponse, itemsResponse, likePattern, queryError, queryText } from "@/lib/api-response";
import type { Store } from "@/lib/models";

export function GET(request: Request) {
  try {
    const parameters = new URL(request.url).searchParams;
    const query = queryText(parameters.get("q"));
    const category = queryText(parameters.get("category"));
    const items = database
      .prepare<
        [string, string, string, string, string],
        Omit<Store, "active" | "ownerUserId" | "isDemo"> & { isDemo: number }
      >(
        `SELECT id, name, category, description, floor, unit, phone,
                map_node_id AS mapNodeId,
                is_demo AS isDemo
         FROM stores
         WHERE active = 1
           AND (? = '' OR unicode_lower(name) LIKE unicode_lower(?) ESCAPE '\\'
                OR unicode_lower(category) LIKE unicode_lower(?) ESCAPE '\\')
           AND (? = '' OR unicode_lower(category) = unicode_lower(?))
         ORDER BY name
         LIMIT 100`,
      )
      .all(
        query,
        likePattern(query),
        likePattern(query),
        category,
        category,
      );

    return itemsResponse(
      items.map((item) => ({ ...item, isDemo: Boolean(item.isDemo) })),
    );
  } catch (error) {
    if (error instanceof Error && error.message === "query_too_long") {
      return errorResponse(
        "invalid_query",
        "Os filtros de texto devem ter no máximo 100 caracteres.",
        400,
      );
    }
    return queryError(error);
  }
}
