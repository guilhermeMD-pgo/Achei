import { database } from "@/lib/db";
import { itemsResponse, queryError } from "@/lib/api-response";

export function GET() {
  try {
    const items = database
      .prepare<[], {
        id: string;
        name: string;
        category: string;
        description: string;
        floor: string;
        unit: string;
        mapNodeId: string;
        x: number;
        y: number;
        isDemo: number;
      }>(
        `SELECT s.id, s.name, s.category, s.description, s.floor, s.unit,
                n.id AS mapNodeId, n.x, n.y, s.is_demo AS isDemo
         FROM stores s
         INNER JOIN map_nodes n ON n.id = s.map_node_id
         WHERE s.active = 1 AND s.is_demo = 0
         ORDER BY s.floor, s.name`,
      )
      .all()
      .map((item) => ({ ...item, isDemo: Boolean(item.isDemo) }));

    return itemsResponse(items);
  } catch (error) {
    return queryError(error);
  }
}
