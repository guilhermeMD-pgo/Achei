import type { Metadata } from "next";
import Link from "next/link";
import { database } from "@/lib/db";
import { ProductImage } from "@/components/product-image";
import { StoreLogo } from "@/components/store-logo";
import { searchItems } from "@/lib/search";

export const metadata: Metadata = { title: "Pesquisar" };
export const dynamic = "force-dynamic";

type Row = {
  id: string;
  name: string;
  description: string;
  category: string;
  storeId: string;
  storeName: string;
  floor: string;
  unit: string;
  discount: number | null;
};

const quickSearches = ["camisa", "tênis", "comida", "livro", "cinema", "sobremesa"];

function ProductCard({ item }: { item: Row }) {
  return (
    <article className="product-card">
      <ProductImage name={item.name} productId={item.id} size="lg" />
      <div className="product-card-body">
        {item.discount !== null && <span className="discount-badge">{item.discount}% off</span>}
        <p className="eyebrow">{item.category}</p>
        <h3>{item.name}</h3>
        <p className="product-card-store">
          <StoreLogo name={item.storeName} size="sm" storeId={item.storeId} />
          <span>{item.storeName} · {item.floor}{item.unit && !item.unit.startsWith("Não") ? `, ${item.unit}` : ""}</span>
        </p>
        <Link className="text-link" href={`/map?store=${encodeURIComponent(item.storeId)}`}>Ver no mapa e rotas →</Link>
      </div>
    </article>
  );
}

function StoreChips({ items }: { items: Row[] }) {
  const stores = [...new Map(items.map((i) => [i.storeId, i])).values()];
  return (
    <div className="search-store-chips">
      {stores.map((s) => (
        <Link className="search-store-chip" href={`/stores/${encodeURIComponent(s.storeId)}`} key={s.storeId}>
          <StoreLogo name={s.storeName} size="sm" storeId={s.storeId} />
          <span>{s.storeName}<small>{s.floor}</small></span>
        </Link>
      ))}
    </div>
  );
}

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const query = q.trim().slice(0, 100);
  const now = new Date().toISOString();
  const rows = database
    .prepare<[string, string], Row>(
      `SELECT p.id, p.name, p.description, p.category, s.id AS storeId, s.name AS storeName,
              s.floor, s.unit,
              (SELECT MAX(pr.discount_percent) FROM promotions pr
                WHERE pr.product_id = p.id AND pr.active = 1
                  AND pr.starts_at <= ? AND pr.ends_at >= ?) AS discount
       FROM products p JOIN stores s ON s.id = p.store_id
       WHERE p.active = 1 AND s.active = 1 AND s.is_demo = 0
       ORDER BY p.name`,
    )
    .all(now, now);
  const result = query ? searchItems(rows, query) : { exact: rows, suggestions: [] as Row[] };

  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">BUSCA DE PRODUTOS</p>
        <h1>Pesquisar</h1>
        <p className="page-description">
          Encontre produtos e veja todas as lojas que vendem. Pode digitar sem acento ou até errar a escrita.
        </p>
      </div>
      <form action="/search" className="search-form" role="search">
        <label className="visually-hidden" htmlFor="search-query">Produto ou loja</label>
        <input autoComplete="off" defaultValue={query} id="search-query" name="q" placeholder="Produto ou loja" type="search" />
        <button className="primary-button" type="submit">Pesquisar</button>
      </form>
      <div className="quick-searches">
        {quickSearches.map((term) => (
          <Link className="quick-chip" href={`/search?q=${encodeURIComponent(term)}`} key={term}>{term}</Link>
        ))}
      </div>

      {query && result.exact.length > 0 && (
        <section className="home-section">
          <div className="section-heading">
            <p className="eyebrow">LOJAS COM “{query.toUpperCase()}”</p>
            <h2>{new Set(result.exact.map((i) => i.storeId)).size} loja(s) · {result.exact.length} produto(s)</h2>
          </div>
          <StoreChips items={result.exact} />
        </section>
      )}

      {query && result.exact.length === 0 && (
        <section className="home-section">
          <div className="section-heading">
            <p className="eyebrow">SEM RESULTADO EXATO</p>
            <h2>Não encontramos “{query}”</h2>
          </div>
          <p className="page-description">
            {result.suggestions.length > 0
              ? "Veja se algum destes itens parecidos é o que você procura:"
              : "Tente outra palavra, como camisa, tênis, comida ou livro."}
          </p>
        </section>
      )}

      {(result.exact.length > 0 || result.suggestions.length > 0) && (
        <div className="product-grid">
          {(result.exact.length > 0 ? result.exact : result.suggestions).map((item) => (
            <ProductCard item={item} key={item.id} />
          ))}
        </div>
      )}
      <p className="demo-notice">Catálogo demonstrativo: imagens ilustrativas. Confirme preço e disponibilidade na loja.</p>
    </>
  );
}
