import Link from "next/link";
import { StoreLogo } from "@/components/store-logo";
import { ProductImage } from "@/components/product-image";
import { listActivePromotions } from "@/lib/promotions";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const promotions = listActivePromotions(3);

  return (
    <>
      <section className="hero">
        <p className="eyebrow">ACHEI · GUIA DO SHOPPING</p>
        <h1>
          Encontre o que procura,
          <br />
          em um só lugar.
        </h1>
        <p className="hero-description">
          Pesquise produtos, explore lojas e encontre serviços. A plataforma
          está sendo preparada para reunir essas informações.
        </p>
        <form action="/search" className="search-form" role="search">
          <label className="visually-hidden" htmlFor="home-query">
            Produto ou loja
          </label>
          <input
            autoComplete="off"
            id="home-query"
            name="q"
            placeholder="O que você está procurando?"
            type="search"
          />
          <button className="primary-button" type="submit">
            Pesquisar
          </button>
        </form>
      </section>

      <section aria-labelledby="explore-heading" className="home-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">EXPLORE</p>
            <h2 id="explore-heading">O que você precisa encontrar?</h2>
          </div>
        </div>
        <div className="category-grid">
          <Link className="category-card" href="/search">
            <span aria-hidden="true">⌕</span>
            <span>Produtos</span>
          </Link>
          <Link className="category-card" href="/stores">
            <span aria-hidden="true">▦</span>
            <span>Lojas</span>
          </Link>
          <Link className="category-card" href="/promotions">
            <span aria-hidden="true">％</span>
            <span>Promoções</span>
          </Link>
          <Link className="category-card" href="/map">
            <span aria-hidden="true">⌖</span>
            <span>Mapa e serviços</span>
          </Link>
        </div>
      </section>

      <section aria-labelledby="featured-promotions-heading" className="home-section">
        <div className="section-heading">
          <p className="eyebrow">OFERTAS</p>
          <h2 id="featured-promotions-heading">Promoções em destaque</h2>
        </div>
        {promotions.length === 0 ? (
          <p className="page-description">Nenhuma promoção vigente no momento.</p>
        ) : (
          <div className="promotion-grid promotion-grid-compact">
            {promotions.map((promotion) => (
              <article className="promotion-card" key={promotion.id}>
                <h3>
                  <Link href={`/promotions/${encodeURIComponent(promotion.id)}`}>
                    {promotion.title}
                  </Link>
                </h3>
                <div className="promotion-store-row">
                  <StoreLogo storeId={promotion.storeId} name={promotion.storeName} size="sm" />
                  <span>{promotion.storeName}</span>
                </div>
                {promotion.productName && promotion.productId && (
                  <div className="promo-product-row">
                    <ProductImage name={promotion.productName} productId={promotion.productId} size="sm" />
                    <p className="promotion-product">{promotion.productName}</p>
                  </div>
                )}
                <Link
                  className="text-link"
                  href={`/promotions/${encodeURIComponent(promotion.id)}`}
                >
                  Consultar oferta
                </Link>
              </article>
            ))}
          </div>
        )}
      </section>

      <p className="demo-notice">
        Consulte diretamente os estabelecimentos para confirmar as condições das campanhas.
      </p>
    </>
  );
}
