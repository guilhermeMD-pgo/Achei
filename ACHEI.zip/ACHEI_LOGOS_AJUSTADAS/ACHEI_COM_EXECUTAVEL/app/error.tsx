"use client";

import { useEffect } from "react";

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <section className="status-panel status-error" role="alert">
      <h1>Não foi possível carregar esta página</h1>
      <p>Tente novamente. Se o problema continuar, procure a equipe responsável.</p>
      <button className="primary-button" onClick={reset} type="button">
        Tentar novamente
      </button>
    </section>
  );
}
