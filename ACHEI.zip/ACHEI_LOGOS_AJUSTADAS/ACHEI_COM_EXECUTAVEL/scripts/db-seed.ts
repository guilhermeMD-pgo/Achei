import { randomUUID } from "node:crypto";
import { database } from "../lib/database";
import { migrateDatabase } from "../lib/db/migrate";
import { hashPassword } from "../lib/password";
import { mallMapStores } from "../lib/mall-map-data";

migrateDatabase(database);

const now = new Date();
const startsAt = now.toISOString();
const endsAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
const merchantEmail =
  process.env.DEMO_MERCHANT_EMAIL?.trim() || "lojista-demo@example.invalid";
const merchantPassword = process.env.DEMO_MERCHANT_PASSWORD;

if (merchantPassword && merchantPassword.length < 12) {
  throw new Error("DEMO_MERCHANT_PASSWORD deve ter pelo menos 12 caracteres.");
}

const seed = database.transaction(() => {
  // Lojas e posições de referência transcritas da planta operacional enviada.
  // Os produtos não são semeados: cada lojista deverá cadastrá-los e validá-los.
  const insertMallNode = database.prepare(
    `INSERT OR IGNORE INTO map_nodes
      (id, name, floor, node_type, x, y, accessible, is_demo)
     VALUES (?, ?, ?, 'store', ?, ?, 0, 0)`,
  );
  const insertMallStore = database.prepare(
    `INSERT OR IGNORE INTO stores
      (id, name, category, description, floor, unit, map_node_id, active, is_demo)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0)`,
  );
  for (const store of mallMapStores) {
    insertMallNode.run(store.nodeId, store.name, store.floor, store.x, store.y);
    insertMallStore.run(
      store.id,
      store.name,
      store.category,
      store.description,
      store.floor,
      store.unit,
      store.nodeId,
    );
  }
  database
    .prepare(
      `INSERT OR IGNORE INTO stores
        (id, name, category, description, floor, unit, active, is_demo)
       VALUES (?, ?, ?, ?, ?, ?, 1, 1)`,
    )
    .run(
      "demo-store-fashion",
      "Loja de Moda Exemplo",
      "Vestuário",
      "Estabelecimento fictício para demonstração da plataforma.",
      "Piso 1",
      "Unidade 101",
    );

  database
    .prepare(
      `INSERT OR IGNORE INTO stores
        (id, name, category, description, floor, unit, active, is_demo)
       VALUES (?, ?, ?, ?, ?, ?, 1, 1)`,
    )
    .run(
      "demo-store-tech",
      "Loja de Tecnologia Exemplo",
      "Eletrônicos",
      "Estabelecimento fictício para demonstração da plataforma.",
      "Piso 2",
      "Unidade 202",
    );

    if (merchantPassword) {
      const existing = database
        .prepare<[string], { id: string; role: string }>(
          "SELECT id, role FROM users WHERE email = ? COLLATE NOCASE",
        )
        .get(merchantEmail);
      if (existing && existing.role !== "merchant" && existing.role !== "admin") {
        throw new Error("A conta configurada para demonstração não possui papel de lojista.");
      }

      const merchantId = existing?.id ?? randomUUID();
      if (!existing) {
        database
          .prepare(
            `INSERT INTO users (id, name, email, password_hash, role, created_at)
             VALUES (?, ?, ?, ?, 'merchant', ?)`,
          )
          .run(
            merchantId,
            "Lojista de demonstração",
            merchantEmail,
            hashPassword(merchantPassword),
            now.toISOString(),
          );
      }
      const ownership = database
        .prepare(
          `UPDATE stores SET owner_user_id = ?
           WHERE id = 'demo-store-fashion'
             AND (owner_user_id IS NULL OR owner_user_id = ?)`,
        )
        .run(merchantId, merchantId);
      if (ownership.changes === 0) {
        const store = database
          .prepare<[], { ownerUserId: string | null }>(
            "SELECT owner_user_id AS ownerUserId FROM stores WHERE id = 'demo-store-fashion'",
          )
          .get();
        if (store?.ownerUserId !== merchantId) {
          throw new Error("A loja de demonstração já está associada a outra conta.");
        }
      }
    }

  const insertProduct = database.prepare(
    `INSERT OR IGNORE INTO products
      (id, store_id, name, description, category, price_cents, availability, active, is_demo)
     VALUES (?, ?, ?, ?, ?, ?, 'unconfirmed', 1, 1)`,
  );
  insertProduct.run(
    "demo-product-shirt",
    "demo-store-fashion",
    "Camiseta de demonstração",
    "Produto fictício para demonstrar a pesquisa do catálogo.",
    "Vestuário",
    5990,
  );
  insertProduct.run(
    "demo-product-headphones",
    "demo-store-tech",
    "Fone de demonstração",
    "Produto fictício para demonstrar a pesquisa do catálogo.",
    "Eletrônicos",
    null,
  );

  database
    .prepare(
      `INSERT OR IGNORE INTO promotions
        (id, store_id, product_id, title, description, discount_percent,
         starts_at, ends_at, active, is_demo)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1)`,
    )
    .run(
      "demo-promotion-shirt",
      "demo-store-fashion",
      "demo-product-shirt",
      "Oferta de demonstração",
      "Oferta fictícia; preço e vigência devem ser confirmados com a loja.",
      10,
      startsAt,
      endsAt,
    );

  const insertNode = database.prepare(
    `INSERT OR IGNORE INTO map_nodes
      (id, name, floor, node_type, x, y, accessible, is_demo)
     VALUES (?, ?, ?, ?, ?, ?, 1, 1)`,
  );
  insertNode.run("demo-node-entrance", "Entrada de demonstração", "Piso 1", "entrance", 0, 0);
  insertNode.run("demo-node-store-fashion", "Loja de Moda Exemplo", "Piso 1", "store", 1, 0);
  insertNode.run("demo-node-restroom", "Banheiro de demonstração", "Piso 1", "restroom", 0, 1);
  database
    .prepare("UPDATE stores SET map_node_id = ? WHERE id = ?")
    .run("demo-node-store-fashion", "demo-store-fashion");
  database
    .prepare(
      `INSERT OR IGNORE INTO map_edges (from_node_id, to_node_id, distance, accessible)
       VALUES (?, ?, ?, 1)`,
    )
    .run("demo-node-entrance", "demo-node-store-fashion", 1);

  database
    .prepare(
      `INSERT OR IGNORE INTO services
        (id, name, description, floor, map_node_id, active, is_demo)
       VALUES (?, ?, ?, ?, ?, 1, 1)`,
    )
    .run(
      "demo-service-restroom",
      "Banheiro de demonstração",
      "Ponto fictício para demonstração da interface.",
      "Piso 1",
      "demo-node-restroom",
    );
});

seed();
database.close();
console.log(`Dados sintéticos de demonstração carregados em ${startsAt}.`);
