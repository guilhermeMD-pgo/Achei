import { existsSync } from "node:fs";
import path from "node:path";
import { demoCatalog, demoProductId } from "../lib/demo-catalog";
import { storeLogos } from "../lib/store-logos";

const root = process.cwd();
const has = (dir: string, id: string, exts: string[]) => exts.some((e) => existsSync(path.join(root, "public", dir, `${id}.${e}`)));

console.log("LOGOS (public/logos)");
for (const id of Object.keys(storeLogos)) console.log(`  ${has("logos", id, ["png", "svg", "webp", "jpg"]) ? "OK      " : "FALTANDO"}  ${id}.png`);
console.log("\nPRODUTOS (public/products)");
for (const [storeId, products] of Object.entries(demoCatalog)) {
  products.forEach((p, i) => {
    const id = demoProductId(storeId, i);
    console.log(`  ${has("products", id, ["jpg", "jpeg", "png", "webp"]) ? "OK      " : "FALTANDO"}  ${id}.jpg   <- ${p.name}`);
  });
}
