import { database } from "../lib/database";
import { migrateDatabase } from "../lib/db/migrate";

migrateDatabase(database);
database.close();
console.log("Migrações aplicadas com sucesso.");
