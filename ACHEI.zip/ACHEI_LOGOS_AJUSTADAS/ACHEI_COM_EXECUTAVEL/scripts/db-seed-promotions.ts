import { database } from "../lib/database";
import { migrateDatabase } from "../lib/db/migrate";
import { retireOldCatalog, seedDemoCatalog } from "../lib/demo-catalog";

migrateDatabase(database);
const startsAt = new Date().toISOString();
const endsAt = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString();
database.transaction(() => {
  retireOldCatalog(database);
  seedDemoCatalog(database, startsAt, endsAt);
})();
database.close();
console.log("Catálogo atualizado: 2 produtos e 2 promoções para cada uma das 10 lojas do mapa.");
