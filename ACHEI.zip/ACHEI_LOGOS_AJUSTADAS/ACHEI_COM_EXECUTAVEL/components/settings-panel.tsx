"use client";
import { useEffect, useState } from "react";
type Preferences={promotions:boolean;tokens:boolean;routeHints:boolean;compactMap:boolean};
const defaults:Preferences={promotions:true,tokens:true,routeHints:true,compactMap:false};
export function SettingsPanel(){
 const [prefs,setPrefs]=useState<Preferences>(defaults);const [saved,setSaved]=useState(false);
 useEffect(()=>{try{const raw=localStorage.getItem("achei-preferences");if(raw)setPrefs({...defaults,...JSON.parse(raw)})}catch{}},[]);
 function update(key:keyof Preferences,value:boolean){const next={...prefs,[key]:value};setPrefs(next);localStorage.setItem("achei-preferences",JSON.stringify(next));setSaved(true)}
 return <div className="settings-grid"><section className="account-card settings-section"><p className="eyebrow">EXPERIÊNCIA</p><h2>Preferências do Achei</h2><p>Escolha como deseja receber informações e utilizar o guia.</p>
 <label className="setting-row"><span><strong>Novas promoções</strong><small>Exibir avisos sobre campanhas e ofertas.</small></span><input type="checkbox" checked={prefs.promotions} onChange={e=>update("promotions",e.target.checked)}/></label>
 <label className="setting-row"><span><strong>Recompensas e tokens</strong><small>Mostrar avisos de campanhas que oferecem Achei Tokens.</small></span><input type="checkbox" checked={prefs.tokens} onChange={e=>update("tokens",e.target.checked)}/></label>
 <label className="setting-row"><span><strong>Dicas de rota</strong><small>Exibir orientações ao selecionar destinos no mapa.</small></span><input type="checkbox" checked={prefs.routeHints} onChange={e=>update("routeHints",e.target.checked)}/></label>
 <label className="setting-row"><span><strong>Mapa compacto</strong><small>Preferir uma visualização mais enxuta em telas menores.</small></span><input type="checkbox" checked={prefs.compactMap} onChange={e=>update("compactMap",e.target.checked)}/></label>
 {saved&&<p className="form-message" aria-live="polite">Preferências salvas neste dispositivo.</p>}</section>
 <section className="account-card settings-section"><p className="eyebrow">CONTA E PRIVACIDADE</p><h2>Seus dados</h2><p>Edite nome e e-mail no seu perfil. Suas lojas favoritas e seu saldo de tokens ficam associados à sua conta.</p><a className="primary-button" href="/account">Abrir meu perfil</a></section>
 <section className="account-card settings-section"><p className="eyebrow">ACESSIBILIDADE</p><h2>Ajuda e acessibilidade</h2><p>O mapa apresenta marcadores de banheiros, elevadores e escadas nos dois pavimentos. Como esta versão é demonstrativa, confirme a localização real dos serviços no shopping.</p></section></div>
}
