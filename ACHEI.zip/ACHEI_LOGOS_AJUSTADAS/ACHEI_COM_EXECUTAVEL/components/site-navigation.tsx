"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const navigation = [
  { href: "/", label: "Início", icon: "⌂" },
  { href: "/search", label: "Pesquisar", icon: "⌕" },
  { href: "/stores", label: "Lojas", icon: "▦" },
  { href: "/promotions", label: "Promoções", icon: "％" },
  { href: "/map", label: "Mapa", icon: "⌖" },
  { href: "/account", label: "Perfil", icon: "◎" },
  { href: "/settings", label: "Configurações", icon: "⚙" },
];

export function SiteNavigation() {
  const pathname = usePathname();
  return <aside className="sidebar">
    <Link aria-label="Achei, página inicial" className="brand" href="/">ACHEI<span>.</span></Link>
    <p className="sidebar-caption">GUIA DO SHOPPING</p>
    <nav aria-label="Navegação principal" className="primary-navigation">
      {navigation.map(item => { const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href); return <Link aria-current={active ? "page" : undefined} className={`navigation-link${active ? " active" : ""}`} href={item.href} key={item.href}><span aria-hidden="true" className="navigation-icon">{item.icon}</span><span>{item.label}</span></Link>; })}
    </nav>
    <p className="sidebar-note">Seu shopping em um só lugar.</p>
  </aside>;
}
