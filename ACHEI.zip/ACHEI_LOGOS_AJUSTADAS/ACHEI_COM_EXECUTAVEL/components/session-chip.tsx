"use client";
import { useEffect, useState } from "react";
export function SessionChip(){
 const [name,setName]=useState("");
 useEffect(()=>{let active=true;const load=()=>fetch("/api/auth/session",{cache:"no-store"}).then(r=>r.json()).then(d=>{if(active)setName(d.authenticated&&d.user?d.user.name:"")}).catch(()=>{});void load();const onFocus=()=>void load();window.addEventListener("focus",onFocus);window.addEventListener("achei:session-changed",onFocus);return()=>{active=false;window.removeEventListener("focus",onFocus);window.removeEventListener("achei:session-changed",onFocus)}},[]);
 return <span className={`visitor-chip${name?" signed-in":""}`}>{name?`Olá, ${name}`:"Visitante"}</span>;
}
