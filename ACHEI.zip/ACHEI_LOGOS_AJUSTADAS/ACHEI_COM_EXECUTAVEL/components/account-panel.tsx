"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useState } from "react";

type AccountUser = { id: string; name: string; email: string; role: "consumer" | "merchant" | "admin" };
type Mode = "login" | "register";

export function AccountPanel() {
  const [user, setUser] = useState<AccountUser | null>(null);
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [favorites, setFavorites] = useState<Array<{id:string; name:string; category:string}>>([]);
  const [tokenBalance, setTokenBalance] = useState(0);
  const [tokensEarned, setTokensEarned] = useState(0);
  const router = useRouter();

  async function loadSession() {
    const response = await fetch("/api/auth/session", { cache: "no-store" });
    const data = await response.json();
    if (data.authenticated && data.user) {
      setUser(data.user);
      setName(data.user.name);
      setEmail(data.user.email);
      const fav = await fetch("/api/favorites", { cache: "no-store" });
      if (fav.ok) { const data = await fav.json(); setFavorites(data.items ?? []); }
      const wallet = await fetch("/api/tokens", { cache: "no-store" });
      if (wallet.ok) { const data = await wallet.json(); setTokenBalance(data.balance ?? 0); setTokensEarned(data.lifetimeEarned ?? 0); }
    } else { setUser(null); setFavorites([]); }
  }

  useEffect(() => { void loadSession(); }, []);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setMessage("");
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const payload = mode === "login" ? { email, password } : { name, email, password };
      const response = await fetch(endpoint, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message ?? "Não foi possível entrar.");
      setPassword(""); await loadSession(); window.dispatchEvent(new Event("achei:session-changed")); setMessage("Acesso realizado com sucesso.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Ocorreu um erro."); }
    finally { setBusy(false); }
  }

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/account/profile", {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message ?? "Não foi possível salvar o perfil.");
      setUser(data.user); setEditing(false); window.dispatchEvent(new Event("achei:session-changed")); setMessage("Perfil atualizado com sucesso.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Ocorreu um erro."); }
    finally { setBusy(false); }
  }

  async function logout() {
    setBusy(true);
    try { await fetch("/api/auth/logout", { method: "POST" }); setUser(null); setPassword(""); window.dispatchEvent(new Event("achei:session-changed")); router.push("/"); router.refresh(); }
    finally { setBusy(false); }
  }

  if (user) return (
    <div className="profile-layout">
      <section className="account-card">
        <div className="account-card-heading"><div><p className="eyebrow">MEU PERFIL</p><h2>Olá, {user.name}</h2><p className="profile-email">{user.role === "consumer" ? "Consumidor" : user.role === "merchant" ? "Lojista" : "Administrador"}</p></div></div>
        {!editing ? <><div className="profile-actions"><button className="primary-button" onClick={() => setEditing(true)} type="button">Editar perfil</button><button className="secondary-button" onClick={logout} disabled={busy} type="button">Sair da conta</button></div>
          <div className="settings-links"><h3>Conta</h3><Link className="settings-link" href="/settings">Configurações <span>›</span></Link>{(user.role === "merchant" || user.role === "admin") && <Link className="settings-link" href="/merchant">Área do lojista <span>›</span></Link>}</div>
        </> : <form className="account-form" onSubmit={saveProfile}>
          <label>Nome completo<input autoComplete="name" maxLength={100} minLength={2} onChange={event => setName(event.target.value)} required value={name} /></label>
          <label>E-mail<input autoComplete="email" maxLength={254} onChange={event => setEmail(event.target.value)} required type="email" value={email} /></label>
          <div className="profile-actions"><button className="primary-button" disabled={busy} type="submit">{busy ? "Salvando..." : "Salvar alterações"}</button><button className="secondary-button" onClick={() => { setEditing(false); setName(user.name); setEmail(user.email); }} type="button">Cancelar</button></div>
        </form>}
        {message && <p aria-live="polite" className="form-message">{message}</p>}
      </section>
      <section className="account-card token-wallet"><p className="eyebrow">ACHEI RECOMPENSAS</p><h2>{tokenBalance} Achei Tokens</h2><p>Saldo de pontos da plataforma. Ganhe tokens ao participar de campanhas elegíveis e acompanhe seu histórico.</p><small>Total acumulado: {tokensEarned} tokens. Tokens de protótipo não têm conversão em dinheiro.</small></section>
      <section className="account-card favorites-card"><div className="section-heading"><p className="eyebrow">SUA LISTA</p><h2>Lojas favoritas</h2></div>
        {favorites.length ? <div className="favorite-list">{favorites.map(store => <Link href={`/stores/${encodeURIComponent(store.id)}`} className="favorite-item" key={store.id}><span><strong>{store.name}</strong><small>{store.category}</small></span><span>›</span></Link>)}</div> : <p className="page-description">Sua lista está vazia. Explore as lojas e toque no coração para salvar seus estabelecimentos favoritos.</p>}
        <Link className="text-link" href="/stores">Explorar lojas</Link>
        <p className="prototype-profile-note">Algumas campanhas exibidas no catálogo são conteúdo de protótipo e ainda aguardam confirmação das lojas.</p>
      </section>
    </div>
  );

  return (
    <section className="account-card">
      <div className="account-card-heading"><div><p className="eyebrow">ÁREA DO CONSUMIDOR</p><h2>{mode === "login" ? "Entre na sua conta" : "Crie sua conta"}</h2></div></div>
      <form className="account-form" onSubmit={submitAuth}>
        {mode === "register" && <label>Nome completo<input autoComplete="name" maxLength={100} minLength={2} onChange={event => setName(event.target.value)} required value={name} /></label>}
        <label>E-mail<input autoComplete="email" maxLength={254} onChange={event => setEmail(event.target.value)} required type="email" value={email} /></label>
        <label>Senha<input autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={8} maxLength={128} onChange={event => setPassword(event.target.value)} required type="password" value={password} /></label>
        {mode === "register" && <p className="field-hint">Use uma senha com pelo menos 8 caracteres.</p>}
        <button className="primary-button" disabled={busy} type="submit">{busy ? "Aguarde..." : mode === "login" ? "Entrar" : "Criar conta"}</button>
      </form>
      {message && <p aria-live="polite" className="form-message">{message}</p>}
      <button className="text-button" onClick={() => { setMode(mode === "login" ? "register" : "login"); setMessage(""); }} type="button">
        {mode === "login" ? "Ainda não tem conta? Cadastre-se" : "Já tem uma conta? Entrar"}
      </button>
    </section>
  );
}
