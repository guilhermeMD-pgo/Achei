type StatusPanelProps = {
  title: string;
  children: React.ReactNode;
  variant?: "empty" | "error" | "loading";
};

export function StatusPanel({
  title,
  children,
  variant = "empty",
}: StatusPanelProps) {
  return (
    <section
      aria-live={variant === "loading" ? "polite" : undefined}
      className={`status-panel status-${variant}`}
      role={variant === "error" ? "alert" : undefined}
    >
      <h2>{title}</h2>
      <p>{children}</p>
    </section>
  );
}
