import { StatusPanel } from "@/components/status-panel";

type SectionPlaceholderProps = {
  title: string;
  description: string;
  section: string;
};

export function SectionPlaceholder({
  title,
  description,
  section,
}: SectionPlaceholderProps) {
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">{section}</p>
        <h1>{title}</h1>
        <p className="page-description">{description}</p>
      </div>
      <StatusPanel title="Esta área está sendo preparada">
        Os dados e funcionalidades desta seção ainda não foram conectados.
        Nenhuma informação de lojas, preços ou disponibilidade é apresentada
        como oficial.
      </StatusPanel>
    </>
  );
}
