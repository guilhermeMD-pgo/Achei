"use client";
import { useEffect, useMemo, useState } from "react";
import { StoreLogo } from "@/components/store-logo";
import { mallMapStores } from "@/lib/mall-map-data";
import { computeRoutes, pathData, type MallRoute, type MapFloor } from "@/lib/mall-routes";

type Store = { id:string; name:string; category:string; description:string; floor:string; unit:string; mapNodeId:string; x:number; y:number; isDemo:boolean };
type Place = {id:string;label:string;kind:"toilet"|"elevator"|"stairs";floor:string;x:number;y:number;detail:string};
const floors=["Térreo","2º pavimento"];
const keptIds=new Set(mallMapStores.map(s=>s.id));
const facilities:Place[]=[
 {id:"wc-g",label:"Banheiros",kind:"toilet",floor:"Térreo",x:14,y:22,detail:"Banheiros e sanitários acessíveis"},
 {id:"lift-g",label:"Elevador",kind:"elevator",floor:"Térreo",x:84,y:22,detail:"Elevador para acesso ao 2º pavimento"},
 {id:"stairs-g",label:"Escadas",kind:"stairs",floor:"Térreo",x:16,y:79,detail:"Escadas de acesso ao 2º pavimento"},
 {id:"wc-2",label:"Banheiros",kind:"toilet",floor:"2º pavimento",x:14,y:22,detail:"Banheiros e sanitários acessíveis"},
 {id:"lift-2",label:"Elevador",kind:"elevator",floor:"2º pavimento",x:84,y:22,detail:"Elevador para acesso ao térreo"},
 {id:"stairs-2",label:"Escadas",kind:"stairs",floor:"2º pavimento",x:16,y:79,detail:"Escadas de acesso ao térreo"},
];
function FloorDrawing({floor,routes,highlighted}:{floor:string;routes:MallRoute[];highlighted:string|null}){
 const second=floor===floors[1];
 const wings=second?[[7,10,20,18],[31,8,18,20],[53,8,18,20],[75,10,18,18],[7,73,20,17],[31,75,18,16],[53,75,18,16],[75,73,18,17]]:[[7,10,18,18],[29,8,18,20],[51,8,18,20],[75,10,18,18],[7,34,18,17],[75,34,18,17],[7,57,18,17],[75,57,18,17],[7,77,18,14],[29,78,18,13],[51,78,18,13],[75,77,18,14]];
 return <svg className="map-architecture" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="mall-ground" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f2eee4"/><stop offset="1" stopColor="#d5d0c4"/></linearGradient><pattern id="mall-grid" width="2" height="2" patternUnits="userSpaceOnUse"><path d="M2 0H0V2" stroke="#b7b2a7" strokeWidth=".08" fill="none"/></pattern><filter id="mall-shadow-new"><feDropShadow dx="0" dy=".5" stdDeviation=".35" floodOpacity=".18"/></filter></defs>
 <rect x="2" y="3" width="96" height="94" rx="4" fill="url(#mall-ground)" stroke="#817b6d" strokeWidth=".8"/><rect x="4" y="5" width="92" height="90" fill="url(#mall-grid)"/>
 <path d="M4 29H96M4 51H96M4 73H96M27 5V95M50 5V95M73 5V95" stroke="#b0aa9e" strokeWidth="1.2" fill="none"/><rect x="28" y="29" width="44" height="44" rx="2" fill="#f8f6ef" stroke="#aaa394" strokeWidth=".8"/><rect x="34" y="35" width="32" height="32" rx="2" fill="#e2e5de" stroke="#aaa394" strokeWidth=".5"/><rect x="42" y="43" width="16" height="16" rx="2" fill="#cfd5cc" stroke="#aaa394" strokeWidth=".5"/>
 {wings.map(([x,y,w,h],i)=><g key={i} filter="url(#mall-shadow-new)"><rect x={x} y={y} width={w} height={h} rx="1.3" fill={i%2?"#c9c8c0":"#d8d5cb"} stroke="#858176" strokeWidth=".6"/><path d={`M${x+2} ${y+3}H${x+w-2}M${x+2} ${y+h-3}H${x+w-2}`} stroke="#fffdf6" strokeWidth=".6"/></g>)}
 <path d="M50 3V29M50 73V97M2 51H28M72 51H98" stroke="#fffdf8" strokeWidth="2.5"/><path d="M46 3H54V10H46ZM46 90H54V97H46Z" fill="#b6b0a3" stroke="#777166" strokeWidth=".5"/>{[...routes].reverse().map(r=><path key={r.id} d={pathData(r.points)} className={`map-route-path${highlighted&&highlighted!==r.id?" dim":""}${highlighted===r.id?" focus":""}`} style={{stroke:r.color}} vectorEffect="non-scaling-stroke"/>)}
 </svg>
}

function isFriday13(d:Date){return d.getDay()===5&&d.getDate()===13}
function BlackCat(){return <svg viewBox="0 0 40 40" aria-hidden="true" className="cat-svg"><path d="M8 36c-2-9 1-17 7-20l-2-9 6 5c2-.6 4-.6 6 0l6-5-2 9c6 3 9 11 7 20z" fill="#0c0c10"/><ellipse className="cat-eye" cx="16" cy="21" rx="2.1" ry="2.8" fill="#e8ff4a"/><ellipse className="cat-eye" cx="25" cy="21" rx="2.1" ry="2.8" fill="#e8ff4a"/><path d="M33 33c5-1 6-6 3-9" stroke="#0c0c10" strokeWidth="2.4" fill="none" strokeLinecap="round"/></svg>}
export function MallMap(){
 const [floor,setFloor]=useState(floors[0]);const [stores,setStores]=useState<Store[]>([]);const [selectedId,setSelectedId]=useState("");const [selectedPlace,setSelectedPlace]=useState<Place|null>(null);const [query,setQuery]=useState("");const [error,setError]=useState("");const [route,setRoute]=useState(false);const [highlighted,setHighlighted]=useState<string|null>(null);
 const [spooky,setSpooky]=useState(false);const [friday,setFriday]=useState(false);const [toast,setToast]=useState("");
 useEffect(()=>{setFriday(isFriday13(new Date()))},[]);
 useEffect(()=>{fetch("/api/map",{cache:"no-store"}).then(async r=>{if(!r.ok)throw new Error("Não foi possível carregar as lojas.");return r.json()}).then(d=>setStores((d.items??[]).filter((s:Store)=>keptIds.has(s.id)))).catch(e=>setError(e.message||"Falha ao carregar o mapa."))},[]);
 useEffect(()=>{const id=new URLSearchParams(window.location.search).get("store");if(id){const found=stores.find(s=>s.id===id);if(found){setSelectedId(id);setFloor(found.floor);setRoute(true)}}},[stores]);
 useEffect(()=>{if(!toast)return;const t=window.setTimeout(()=>setToast(""),4200);return()=>window.clearTimeout(t)},[toast]);
 const visible=useMemo(()=>stores.filter(s=>s.floor===floor&&(`${s.name} ${s.category}`).toLocaleLowerCase("pt-BR").includes(query.toLocaleLowerCase("pt-BR"))),[stores,floor,query]);
 const visibleFacilities=facilities.filter(p=>p.floor===floor);const selected=stores.find(s=>s.id===selectedId&&s.floor===floor);
 const routes=useMemo<MallRoute[]>(()=>selected?computeRoutes({x:selected.x,y:selected.y},selected.floor as MapFloor):[],[selected]);
 const shownRoutes=route?routes:[];
 const selectStore=(s:Store)=>{setSelectedId(s.id);setSelectedPlace(null);setRoute(true);setHighlighted(null)};
 const toggleSpooky=()=>{setSpooky(v=>{const next=!v;setToast(next?"🐈‍⬛ Sexta-feira 13! O gato preto cruzou o seu caminho… as luzes do shopping começaram a piscar. Clique nele de novo para quebrar o feitiço.":"🍀 Feitiço quebrado! Boas compras e muita sorte.");return next})};
 return <section className="new-map-layout"><div className="new-map-main"><div className="new-map-toolbar"><div className="floor-switch">{floors.map(f=><button key={f} className={`floor-button${floor===f?" active":""}`} aria-pressed={floor===f} onClick={()=>{setFloor(f);setSelectedId("");setSelectedPlace(null);setRoute(false);setHighlighted(null)}} type="button">{f}</button>)}</div><input aria-label="Buscar loja no mapa" placeholder="Buscar loja ou serviço..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
 <div className={`schematic-map ${floor===floors[1]?"food-floor":"ground-floor"}${spooky?" spooky":""}`} aria-label={`Mapa ilustrativo ampliado do ${floor}`}><FloorDrawing floor={floor} routes={shownRoutes} highlighted={highlighted}/>
 {visible.map(s=><button key={s.id} type="button" className={`map-store-pin${selectedId===s.id?" active":""}`} style={{left:`${s.x}%`,top:`${s.y}%`}} onClick={()=>selectStore(s)} aria-pressed={selectedId===s.id} title={s.name}><StoreLogo storeId={s.id} name={s.name} size="sm"/><span className="pin-label">{s.name}</span></button>)}
 {visibleFacilities.map(p=><button key={p.id} type="button" className={`map-facility-pin ${p.kind}${selectedPlace?.id===p.id?" active":""}`} style={{left:`${p.x}%`,top:`${p.y}%`}} onClick={()=>{setSelectedPlace(p);setSelectedId("");setRoute(false);setHighlighted(null)}} title={p.label}><span aria-hidden="true">{p.kind==="toilet"?"WC":p.kind==="elevator"?"↕":"⇅"}</span><small>{p.label}</small></button>)}
 <span className="map-entrance-label">{spooky?"ENTRADA · SEXTA 13":"ENTRADA PRINCIPAL"}</span><span className="map-compass">{spooky?"13":"N ↑"}</span>
 <button type="button" className={`map-cat${friday?" hint":""}${spooky?" awake":""}`} onClick={toggleSpooky} aria-pressed={spooky} aria-label="Gato preto escondido" title="Miau?"><BlackCat/></button>
 {spooky&&<><div className="spooky-fog" aria-hidden="true"/><span className="spooky-bat bat-1" aria-hidden="true">🦇</span><span className="spooky-bat bat-2" aria-hidden="true">🦇</span><span className="spooky-bat bat-3" aria-hidden="true">🦇</span></>}
 {toast&&<p className="map-toast" role="status">{toast}</p>}
 </div><div className="map-legend"><span><i className="legend-store"/>Lojas</span><span><i className="legend-facility"/>Serviços</span><span><i className="legend-route"/>Rotas (uma cor por ponto de partida)</span></div>{error&&<p className="form-error">{error}</p>}<p className="map-disclaimer">Shopping fictício de demonstração. Lojas, serviços e rotas são ilustrativos.</p></div>
 <aside className="map-details">{selected?<><p className="eyebrow">LOJA SELECIONADA</p><div className="map-detail-title"><StoreLogo storeId={selected.id} name={selected.name} size="lg"/><h2>{selected.name}</h2></div><p className="map-detail-category">{selected.category}</p><dl className="map-store-meta"><div><dt>Pavimento</dt><dd>{selected.floor}</dd></div><div><dt>Unidade</dt><dd>{selected.unit}</dd></div></dl><p>{selected.description}</p>
 <p className="eyebrow route-heading">TODAS AS ROTAS ({routes.length})</p>{route?<ul className="route-list">{routes.map(r=><li key={r.id}><button type="button" className={`route-item${highlighted===r.id?" active":""}`} onClick={()=>setHighlighted(h=>h===r.id?null:r.id)} aria-pressed={highlighted===r.id}><i style={{background:r.color}}/><span><strong>A partir de: {r.label}</strong><small>{r.shortest?"Rota mais curta":"Rota alternativa"}</small></span></button></li>)}</ul>:<p className="route-instruction">As rotas estão ocultas.</p>}
 <button className="primary-button" type="button" onClick={()=>{setRoute(true);setHighlighted(null)}}>Mostrar todas as rotas</button><button className="secondary-button" type="button" onClick={()=>setRoute(false)}>Ocultar rotas</button><p className="route-instruction">Toque em uma rota da lista para destacá-la no mapa.</p></>:selectedPlace?<><p className="eyebrow">SERVIÇO SELECIONADO</p><h2>{selectedPlace.label}</h2><p>{selectedPlace.detail}</p><p className="map-detail-category">{selectedPlace.floor}</p><button className="secondary-button" type="button" onClick={()=>setSelectedPlace(null)}>Fechar detalhes</button></>:<div className="map-select-prompt"><span className="map-select-icon">⌖</span><p className="eyebrow">MAPA INTERATIVO</p><h2>Escolha um destino</h2><p>Selecione uma loja para ver todas as rotas até ela, ou um banheiro, elevador ou escada para consultar o local.</p></div>}</aside></section>
}
