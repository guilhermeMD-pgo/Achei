"use client";
import { useState } from "react";
export function ClaimPromotion({promotionId}:{promotionId:string}) {
 const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
 async function claim(){setBusy(true);setMessage("");try{const response=await fetch("/api/tokens",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({promotionId})});const data=await response.json();if(!response.ok)throw new Error(data.error?.message??"Não foi possível participar.");setMessage(`Você ganhou ${data.earned} Achei Tokens! Saldo: ${data.balance}.`);}catch(e){setMessage(e instanceof Error?e.message:"Erro ao participar.");}finally{setBusy(false);}}
 return <div className="claim-promotion"><button className="primary-button" type="button" disabled={busy} onClick={claim}>{busy?"Processando...":"Participar e ganhar 10 Achei Tokens"}</button>{message&&<p aria-live="polite">{message}</p>}<small>Recompensa demonstrativa do protótipo; não representa dinheiro nem cashback sacável.</small></div>;
}
