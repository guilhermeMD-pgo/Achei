"use client";

import { useEffect, useState, type FormEvent } from "react";

type StoreData = {
  id: string;
  name: string;
  category: string;
  description: string;
  floor: string;
  unit: string;
  phone: string | null;
};

type ProductData = {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number | null;
  availability: "available" | "unconfirmed" | "unavailable";
  active: boolean;
};

type PromotionData = {
  id: string;
  productId: string | null;
  title: string;
  description: string;
  discountPercent: number | null;
  promotionalPrice: number | null;
  startsAt: string;
  endsAt: string;
  active: boolean;
};

type ApiPayload = {
  error?: { message?: string };
  store?: StoreData;
  items?: Array<ProductData | PromotionData>;
};

async function apiRequest(path: string, method = "GET", body?: unknown) {
  const response = await fetch(path, {
    method,
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const payload = (await response.json()) as ApiPayload;
  if (!response.ok) {
    throw new Error(payload.error?.message ?? "Não foi possível concluir a operação.");
  }
  return payload;
}

export function MerchantLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      await apiRequest("/api/auth/login", "POST", { email, password });
      window.location.reload();
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Não foi possível entrar.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="form-panel">
      <p className="eyebrow">ÁREA DO LOJISTA</p>
      <h1>Entrar</h1>
      <p className="page-description">
        Use uma conta de lojista fornecida pela administração do shopping.
      </p>
      <form className="form-grid" onSubmit={submit}>
        <label>
          E-mail
          <input
            autoComplete="username"
            onChange={(event) => setEmail(event.target.value)}
            required
            type="email"
            value={email}
          />
        </label>
        <label>
          Senha
          <input
            autoComplete="current-password"
            onChange={(event) => setPassword(event.target.value)}
            required
            type="password"
            value={password}
          />
        </label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="primary-button" disabled={busy} type="submit">
          {busy ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </section>
  );
}

export function MerchantDashboard({ name }: { name: string }) {
  const [store, setStore] = useState<StoreData | null>(null);
  const [products, setProducts] = useState<ProductData[]>([]);
  const [promotions, setPromotions] = useState<PromotionData[]>([]);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [productId, setProductId] = useState("");
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productCategory, setProductCategory] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [productAvailability, setProductAvailability] =
    useState<ProductData["availability"]>("unconfirmed");

  const [promotionId, setPromotionId] = useState("");
  const [promotionProductId, setPromotionProductId] = useState("");
  const [promotionTitle, setPromotionTitle] = useState("");
  const [promotionDescription, setPromotionDescription] = useState("");
  const [discountPercent, setDiscountPercent] = useState("");
  const [startsAt, setStartsAt] = useState("");
  const [endsAt, setEndsAt] = useState("");

  async function load() {
    setError("");
    try {
      const [storeData, productData, promotionData] = await Promise.all([
        apiRequest("/api/merchant/store"),
        apiRequest("/api/merchant/products"),
        apiRequest("/api/merchant/promotions"),
      ]);
      if (!storeData.store) throw new Error("Não foi possível carregar os dados da loja.");
      setStore(storeData.store);
      setProducts((productData.items ?? []) as ProductData[]);
      setPromotions((promotionData.items ?? []) as PromotionData[]);
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Não foi possível carregar a área do lojista.",
      );
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function submitStore(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!store) return;
    setBusy(true);
    setError("");
    setNotice("");
    const form = new FormData(event.currentTarget);
    try {
      const result = await apiRequest("/api/merchant/store", "PATCH", {
        name: form.get("name"),
        category: form.get("category"),
        description: form.get("description"),
        floor: form.get("floor"),
        unit: form.get("unit"),
        phone: form.get("phone"),
      });
      if (result.store) setStore(result.store);
      setNotice("Dados da loja atualizados.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Falha ao atualizar a loja.");
    } finally {
      setBusy(false);
    }
  }

  async function submitProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const wasEditing = Boolean(productId);
    setBusy(true);
    setError("");
    setNotice("");
    const payload = {
      name: productName,
      description: productDescription,
      category: productCategory,
      price: productPrice === "" ? null : Number(productPrice),
      availability: productAvailability,
    };
    try {
      await apiRequest(
        productId ? `/api/merchant/products/${encodeURIComponent(productId)}` : "/api/merchant/products",
        productId ? "PATCH" : "POST",
        payload,
      );
      resetProduct();
      await load();
      setNotice(wasEditing ? "Produto atualizado." : "Produto cadastrado.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Falha ao salvar o produto.");
    } finally {
      setBusy(false);
    }
  }

  async function submitPromotion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const wasEditing = Boolean(promotionId);
    setBusy(true);
    setError("");
    setNotice("");
    const payload = {
      productId: promotionProductId || null,
      title: promotionTitle,
      description: promotionDescription,
      discountPercent: discountPercent === "" ? null : Number(discountPercent),
      promotionalPrice: null,
      startsAt: startsAt ? new Date(startsAt).toISOString() : "",
      endsAt: endsAt ? new Date(endsAt).toISOString() : "",
    };
    try {
      await apiRequest(
        promotionId
          ? `/api/merchant/promotions/${encodeURIComponent(promotionId)}`
          : "/api/merchant/promotions",
        promotionId ? "PATCH" : "POST",
        payload,
      );
      resetPromotion();
      await load();
      setNotice(wasEditing ? "Promoção atualizada." : "Promoção cadastrada.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Falha ao salvar a promoção.");
    } finally {
      setBusy(false);
    }
  }

  function resetProduct() {
    setProductId("");
    setProductName("");
    setProductDescription("");
    setProductCategory("");
    setProductPrice("");
    setProductAvailability("unconfirmed");
  }

  function editProduct(product: ProductData) {
    setProductId(product.id);
    setProductName(product.name);
    setProductDescription(product.description);
    setProductCategory(product.category);
    setProductPrice(product.price === null ? "" : String(product.price));
    setProductAvailability(product.availability);
  }

  function resetPromotion() {
    setPromotionId("");
    setPromotionProductId("");
    setPromotionTitle("");
    setPromotionDescription("");
    setDiscountPercent("");
    setStartsAt("");
    setEndsAt("");
  }

  function editPromotion(promotion: PromotionData) {
    setPromotionId(promotion.id);
    setPromotionProductId(promotion.productId ?? "");
    setPromotionTitle(promotion.title);
    setPromotionDescription(promotion.description);
    setDiscountPercent(
      promotion.discountPercent === null ? "" : String(promotion.discountPercent),
    );
    setStartsAt(toLocalDateInput(promotion.startsAt));
    setEndsAt(toLocalDateInput(promotion.endsAt));
  }

  async function deactivate(path: string, item: string) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await apiRequest(`${path}/${encodeURIComponent(item)}`, "DELETE");
      await load();
      setNotice("Registro desativado.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Falha ao desativar registro.");
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    setBusy(true);
    setError("");
    try {
      await apiRequest("/api/auth/logout", "POST");
      window.location.assign("/merchant");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível encerrar a sessão.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="merchant-page">
      <div className="page-heading merchant-heading">
        <p className="eyebrow">GESTÃO DA LOJA</p>
        <h1>Olá, {name}</h1>
        {store && <p className="page-description">{store.name}</p>}
        <button className="secondary-button" disabled={busy} onClick={logout} type="button">
          Sair
        </button>
      </div>
      {error && <p className="form-error" role="alert">{error}</p>}
      {notice && <p className="form-success" role="status">{notice}</p>}
      {!store ? (
        <p role="status">Carregando dados da loja...</p>
      ) : (
        <>
          <section aria-labelledby="store-heading" className="form-panel">
            <h2 id="store-heading">Dados da loja</h2>
            <form className="form-grid" onSubmit={submitStore}>
              <label>Nome<input defaultValue={store.name} key={store.id + store.name} name="name" required /></label>
              <label>Categoria<input defaultValue={store.category} key={store.category} name="category" required /></label>
              <label>Descrição<textarea defaultValue={store.description} key={store.description} name="description" rows={3} /></label>
              <label>Piso<input defaultValue={store.floor} key={store.floor} name="floor" required /></label>
              <label>Unidade<input defaultValue={store.unit} key={store.unit} name="unit" required /></label>
              <label>Telefone<input defaultValue={store.phone ?? ""} key={store.phone ?? "no-phone"} name="phone" type="tel" /></label>
              <button className="primary-button" disabled={busy} type="submit">Salvar dados da loja</button>
            </form>
          </section>

          <section aria-labelledby="products-heading" className="merchant-section">
            <h2 id="products-heading">Produtos</h2>
            <form className="form-panel form-grid" onSubmit={submitProduct}>
              <h3>{productId ? "Editar produto" : "Novo produto"}</h3>
              <label>Nome<input onChange={(event) => setProductName(event.target.value)} required value={productName} /></label>
              <label>Categoria<input onChange={(event) => setProductCategory(event.target.value)} required value={productCategory} /></label>
              <label>Descrição<textarea onChange={(event) => setProductDescription(event.target.value)} value={productDescription} rows={2} /></label>
              <label>Preço em reais<input min="0" onChange={(event) => setProductPrice(event.target.value)} step="0.01" type="number" value={productPrice} /></label>
              <label>Disponibilidade
                <select onChange={(event) => setProductAvailability(event.target.value as ProductData["availability"])} value={productAvailability}>
                  <option value="unconfirmed">Não confirmada</option>
                  <option value="available">Informada como disponível</option>
                  <option value="unavailable">Informada como indisponível</option>
                </select>
              </label>
              <div className="form-actions">
                <button className="primary-button" disabled={busy} type="submit">{productId ? "Salvar produto" : "Cadastrar produto"}</button>
                {productId && <button className="secondary-button" onClick={resetProduct} type="button">Cancelar edição</button>}
              </div>
            </form>
            <div className="merchant-list">
              {products.map((product) => (
                <article className="merchant-item" key={product.id}>
                  <div><h3>{product.name}</h3><p>{product.category} · {product.active ? "Ativo" : "Inativo"}</p></div>
                  <div className="form-actions">
                    <button className="secondary-button" onClick={() => editProduct(product)} type="button">Editar</button>
                    {product.active && <button className="secondary-button" disabled={busy} onClick={() => void deactivate("/api/merchant/products", product.id)} type="button">Desativar</button>}
                  </div>
                </article>
              ))}
              {products.length === 0 && <p>Nenhum produto cadastrado.</p>}
            </div>
          </section>

          <section aria-labelledby="promotions-heading" className="merchant-section">
            <h2 id="promotions-heading">Promoções</h2>
            <form className="form-panel form-grid" onSubmit={submitPromotion}>
              <h3>{promotionId ? "Editar promoção" : "Nova promoção"}</h3>
              <label>Título<input onChange={(event) => setPromotionTitle(event.target.value)} required value={promotionTitle} /></label>
              <label>Descrição e condições<textarea onChange={(event) => setPromotionDescription(event.target.value)} required rows={3} value={promotionDescription} /></label>
              <label>Produto relacionado
                <select onChange={(event) => setPromotionProductId(event.target.value)} value={promotionProductId}>
                  <option value="">Sem produto específico</option>
                  {products.filter((product) => product.active).map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}
                </select>
              </label>
              <label>Desconto percentual<input max="100" min="0.01" onChange={(event) => setDiscountPercent(event.target.value)} step="0.01" type="number" value={discountPercent} /></label>
              <p className="field-help">Cadastre o desconto percentual e as condições da campanha. O Achei não exibirá preços nas promoções.</p>
              <label>Início<input onChange={(event) => setStartsAt(event.target.value)} required type="datetime-local" value={startsAt} /></label>
              <label>Fim<input onChange={(event) => setEndsAt(event.target.value)} required type="datetime-local" value={endsAt} /></label>
              <div className="form-actions">
                <button className="primary-button" disabled={busy} type="submit">{promotionId ? "Salvar promoção" : "Cadastrar promoção"}</button>
                {promotionId && <button className="secondary-button" onClick={resetPromotion} type="button">Cancelar edição</button>}
              </div>
            </form>
            <div className="merchant-list">
              {promotions.map((promotion) => (
                <article className="merchant-item" key={promotion.id}>
                  <div><h3>{promotion.title}</h3><p>{promotion.active ? "Ativa" : "Inativa"} · {new Date(promotion.startsAt).toLocaleDateString("pt-BR")} a {new Date(promotion.endsAt).toLocaleDateString("pt-BR")}</p></div>
                  <div className="form-actions">
                    <button className="secondary-button" onClick={() => editPromotion(promotion)} type="button">Editar</button>
                    {promotion.active && <button className="secondary-button" disabled={busy} onClick={() => void deactivate("/api/merchant/promotions", promotion.id)} type="button">Desativar</button>}
                  </div>
                </article>
              ))}
              {promotions.length === 0 && <p>Nenhuma promoção cadastrada.</p>}
            </div>
          </section>
          <p className="demo-notice">Confirme as condições e a disponibilidade diretamente com o estabelecimento.</p>
        </>
      )}
    </div>
  );
}

function toLocalDateInput(value: string) {
  const date = new Date(value);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 16);
}
