"use client";
import { useId, useState } from "react";
import { artFor, type ArtKind } from "@/lib/product-art";

function shade(hex: string, amount: number) {
  const n = parseInt(hex.slice(1), 16);
  const f = (c: number) => Math.max(0, Math.min(255, Math.round(amount >= 0 ? c + (255 - c) * amount : c * (1 + amount))));
  const r = f(n >> 16), gr = f((n >> 8) & 255), b = f(n & 255);
  return `#${((1 << 24) | (r << 16) | (gr << 8) | b).toString(16).slice(1)}`;
}

function Art({ kind, color: g }: { kind: ArtKind; color: string }) {
  const dark = "#00000033";
  switch (kind) {
    case "tshirt":
      return <><path d="M38 24 22 38l9 14 9-5v50h40V47l9 5 9-14-16-14c-4 8-12 12-22 12S42 32 38 24Z" fill={g}/><path d="M50 24c3 7 8 10 14 10s11-3 14-10" fill="none" stroke={dark} strokeWidth="3"/></>;
    case "shirt":
      return <><path d="M38 22 20 38l9 14 9-5v52h44V47l9 5 9-14-18-16-10 12-10-6-10 6Z" fill={g}/><path d="m50 22 10 12 10-12M60 34v66" stroke="#fff" strokeWidth="2.5" fill="none"/><circle cx="60" cy="48" r="1.8" fill="#fff"/><circle cx="60" cy="62" r="1.8" fill="#fff"/><circle cx="60" cy="76" r="1.8" fill="#fff"/></>;
    case "jacket":
      return <><path d="M38 22 20 36l6 54h20V46h28v44h20l6-54-18-14c-4 8-12 12-22 12S42 30 38 22Z" fill={g}/><path d="M60 34v56" stroke="#ffffff88" strokeWidth="2.5"/><rect x="30" y="64" width="14" height="12" rx="2" fill={dark}/><rect x="76" y="64" width="14" height="12" rx="2" fill={dark}/></>;
    case "dress":
      return <><path d="M48 18h8l4 10 4-10h8l-2 28 16 58H34l16-58Z" fill={g}/><path d="M46 48h28" stroke="#ffffff99" strokeWidth="3"/><circle cx="52" cy="76" r="3" fill="#ffffff88"/><circle cx="68" cy="88" r="3" fill="#ffffff88"/><circle cx="58" cy="96" r="3" fill="#ffffff88"/></>;
    case "sneaker":
      return <><path d="M16 74c0-8 6-10 12-10l12-24 14 8 8 10c12 2 26 8 30 16v8H16Z" fill={g} stroke="#0003" strokeWidth="2"/><rect x="14" y="82" width="92" height="9" rx="4.5" fill="#222"/><path d="m40 52 8 6M48 46l8 6" stroke="#0007" strokeWidth="2.5"/></>;
    case "bag":
      return <><path d="M44 44c0-20 32-20 32 0" fill="none" stroke={g} strokeWidth="6"/><rect x="26" y="44" width="68" height="52" rx="9" fill={g}/><rect x="26" y="56" width="68" height="6" fill={dark}/><circle cx="60" cy="66" r="5" fill="#ffffffaa"/></>;
    case "ball":
      return <><circle cx="60" cy="60" r="40" fill={g} stroke="#222" strokeWidth="3"/><path d="m60 40 18 13-7 21H49l-7-21Z" fill="#222"/><path d="M60 40V22M78 53l18-6M71 74l12 15M49 74 37 89M42 53 24 47" stroke="#222" strokeWidth="3"/></>;
    case "plate":
      return <><ellipse cx="60" cy="72" rx="48" ry="22" fill="#f4f1ea" stroke="#0002" strokeWidth="2"/><ellipse cx="60" cy="68" rx="32" ry="13" fill="#fff"/><path d="M34 62c8-16 36-22 52-4l-6 12c-14 4-32 4-46-2Z" fill={g}/><path d="M42 60c10-8 26-10 36-2" stroke="#ffffff55" strokeWidth="3" fill="none"/><circle cx="86" cy="70" r="6" fill="#7a9b3d"/></>;
    case "dessert":
      return <><path d="M30 54h60l-6 38H36Z" fill="#f4f1ea" stroke="#0002" strokeWidth="2"/><ellipse cx="60" cy="54" rx="30" ry="7" fill={g}/><circle cx="60" cy="40" r="14" fill="#f6e7c8"/><path d="M52 34c4-8 14-8 16 0" fill="none" stroke={g} strokeWidth="5" strokeLinecap="round"/></>;
    case "ticket":
      return <><path d="M16 36h88v16a8 8 0 0 0 0 16v16H16V68a8 8 0 0 0 0-16Z" fill={g}/><path d="M80 36v48" stroke="#ffffff88" strokeWidth="2.5" strokeDasharray="5 4"/><path d="m44 52 18 10-18 10Z" fill="#e8c14f"/><rect x="86" y="46" width="12" height="3" fill="#fff"/><rect x="86" y="55" width="12" height="3" fill="#fff"/></>;
    case "popcorn":
      return <><circle cx="44" cy="38" r="12" fill="#fff4cf"/><circle cx="62" cy="32" r="13" fill="#fff"/><circle cx="78" cy="40" r="12" fill="#fff4cf"/><circle cx="54" cy="46" r="11" fill="#fff"/><path d="M32 50h56l-8 48H40Z" fill={g}/><path d="M44 50 48 98M60 50v48M76 50l-4 48" stroke="#fff" strokeWidth="5"/></>;
    case "book":
      return <><rect x="30" y="18" width="62" height="84" rx="4" fill={g}/><rect x="30" y="18" width="10" height="84" fill={dark}/><rect x="48" y="34" width="34" height="5" rx="2" fill="#ffffffcc"/><rect x="48" y="46" width="26" height="4" rx="2" fill="#ffffff88"/><circle cx="64" cy="78" r="9" fill="#ffffff55"/></>;
    case "burger":
      return <><path d="M24 54c0-22 72-22 72 0Z" fill={g}/><circle cx="44" cy="44" r="1.8" fill="#fff"/><circle cx="60" cy="40" r="1.8" fill="#fff"/><circle cx="76" cy="44" r="1.8" fill="#fff"/><path d="M22 56h76l-6 8-8-6-8 6-8-6-8 6-8-6-8 6-8-6-6 6Z" fill="#7cb342"/><rect x="24" y="64" width="72" height="12" rx="6" fill="#5a3420"/><rect x="24" y="76" width="72" height="6" fill="#f2c94c"/><path d="M24 84h72c0 12-10 16-36 16S24 96 24 84Z" fill={g}/></>;
    case "icecream":
      return <><path d="m44 58 16 44 16-44Z" fill="#e0b27a"/><path d="m50 62 6 18M64 62l-4 18M70 62l-6 24" stroke="#b9854f" strokeWidth="2"/><circle cx="60" cy="46" r="20" fill={g}/><circle cx="48" cy="52" r="11" fill="#fff"/><circle cx="72" cy="52" r="11" fill="#f6d28b"/><circle cx="60" cy="26" r="6" fill="#d62a1f"/></>;
    case "juice":
      return <><path d="M38 34h44l-6 66H44Z" fill="#ffffffcc" stroke="#0003" strokeWidth="2"/><path d="M41 52h38l-4 48H45Z" fill={g}/><path d="M64 14 58 34" stroke="#2b8f6b" strokeWidth="5" strokeLinecap="round"/><circle cx="84" cy="36" r="13" fill="#f6c343"/><path d="M84 25v22M73 36h22" stroke="#fff" strokeWidth="1.8"/></>;
    case "sub":
      return <><path d="M14 56c0-20 92-20 92 0v6H14Z" fill="#d9a441"/><path d="M12 62h96c-6 8-12 4-18 8-6-4-12 4-18 0-6 4-12-4-18 0-6-4-12 4-18 0-6 4-12-1-24-8Z" fill={g}/><rect x="14" y="68" width="92" height="9" rx="4" fill="#e04b3a"/><rect x="14" y="76" width="92" height="7" rx="3" fill="#f2c94c"/><path d="M14 84h92v6c0 10-18 12-46 12s-46-2-46-12Z" fill="#d9a441"/></>;
  }
}

type Props = { productId: string; name: string; size?: "sm" | "md" | "lg" };

/** Foto do produto: usa public/products/<id>.jpg quando existir; senão, a ilustração. */
export function ProductImage({ productId, name, size = "md" }: Props) {
  const art = artFor(productId);
  const uid = useId().replace(/:/g, "");
  const sources = ["jpg", "webp", "png", "jpeg"].map((ext) => `/products/${encodeURIComponent(productId)}.${ext}`);
  const [attempt, setAttempt] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const fill = `url(#${uid}-fill)`;
  return (
    <span aria-label={`Imagem ilustrativa: ${name}`} className={`product-image product-image-${size}`} role="img">
      <svg aria-hidden="true" viewBox="0 0 120 120">
        <defs>
          <radialGradient id={`${uid}-spot`} cx="0.5" cy="0.42" r="0.6">
            <stop offset="0" style={{ stopColor: "var(--product-spot)" }} />
            <stop offset="1" style={{ stopColor: "var(--product-spot)", stopOpacity: 0 }} />
          </radialGradient>
          <linearGradient id={`${uid}-fill`} x1="0.1" y1="0" x2="0.9" y2="1">
            <stop offset="0" stopColor={shade(art.color, 0.35)} />
            <stop offset="0.55" stopColor={art.color} />
            <stop offset="1" stopColor={shade(art.color, -0.3)} />
          </linearGradient>
          <filter id={`${uid}-drop`} x="-20%" y="-20%" width="140%" height="150%">
            <feDropShadow dx="0" dy="3" stdDeviation="2.6" floodColor="#2b2210" floodOpacity="0.32" />
          </filter>
        </defs>
        <circle cx="60" cy="58" r="56" fill={`url(#${uid}-spot)`} />
        <ellipse cx="60" cy="106" rx="34" ry="5" style={{ fill: "var(--product-shadow)" }} />
        <g filter={`url(#${uid}-drop)`}>
          <Art kind={art.kind} color={fill} />
        </g>
      </svg>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {attempt < sources.length && (
        <img alt="" className={loaded ? "loaded" : ""} onError={() => setAttempt((n) => n + 1)} onLoad={() => setLoaded(true)} src={sources[attempt]} />
      )}
    </span>
  );
}
