"use client";
import { useEffect, useState } from "react";
export function ThemeToggle(){
 const [theme,setTheme]=useState<"dark"|"light">("dark"); const [animating,setAnimating]=useState(false);
 useEffect(()=>{const saved=localStorage.getItem("achei-theme");if(saved==="light"||saved==="dark"){setTheme(saved);document.documentElement.dataset.theme=saved;}},[]);
 function toggle(e:React.MouseEvent<HTMLButtonElement>){if(animating)return;const next=theme==="dark"?"light":"dark";const rect=e.currentTarget.getBoundingClientRect();const x=rect.left+rect.width/2;const y=rect.top+rect.height/2;const diameter=Math.ceil(Math.hypot(Math.max(x,window.innerWidth-x),Math.max(y,window.innerHeight-y))*2);const overlay=document.createElement("div");overlay.className="theme-reveal";overlay.style.left=`${x}px`;overlay.style.top=`${y}px`;overlay.style.width=`${diameter}px`;overlay.style.height=`${diameter}px`;overlay.style.background=next==="light"?"#f7f3e9":"#101010";document.body.appendChild(overlay);setAnimating(true);requestAnimationFrame(()=>overlay.classList.add("show"));window.setTimeout(()=>{document.documentElement.dataset.theme=next;localStorage.setItem("achei-theme",next);setTheme(next);overlay.remove();setAnimating(false);},620);}
 return <button className="theme-toggle" onClick={toggle} type="button" aria-label="Alternar tema" title="Alternar tema" disabled={animating}>{theme==="dark"?"☀":"☾"}<span>{theme==="dark"?"Tema claro":"Tema escuro"}</span></button>;
}
