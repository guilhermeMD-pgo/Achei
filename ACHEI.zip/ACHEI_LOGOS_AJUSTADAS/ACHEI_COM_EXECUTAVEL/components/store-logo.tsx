"use client";
import { useState } from "react";
import { logoFor } from "@/lib/store-logos";

type Props = { storeId: string; name: string; size?: "sm" | "md" | "lg" };

/** Logo da loja: usa public/logos/<id>.png/.svg/.webp/.jpg se existir; senão, a marca tipográfica ilustrativa. */
export function StoreLogo({ storeId, name, size = "md" }: Props) {
  const spec = logoFor(storeId, name);
  const candidates = [
    ...(spec.image ? [spec.image] : []),
    ...["png", "svg", "webp", "jpg"].map((ext) => `/logos/${encodeURIComponent(storeId)}.${ext}`),
  ];
  const [attempt, setAttempt] = useState(0);
  const showImage = attempt < candidates.length;
  return (
    <span
      aria-label={`Logo ${name}`}
      className={`store-logo store-logo-${size}${spec.round ? " store-logo-round" : ""}`}
      role="img"
      style={{ background: showImage ? "#ffffff" : spec.background, color: spec.color }}
    >
      {showImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img alt="" onError={() => setAttempt((n) => n + 1)} src={candidates[attempt]} />
      ) : (
        <span aria-hidden="true" className="store-logo-text" data-len={spec.text.length}>
          {spec.text}
        </span>
      )}
    </span>
  );
}
